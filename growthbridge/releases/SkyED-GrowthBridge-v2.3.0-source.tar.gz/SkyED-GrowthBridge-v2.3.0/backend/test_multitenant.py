#!/usr/bin/env python3
from __future__ import annotations

import importlib.util
import json
import tempfile
import threading
import urllib.error
import urllib.request
from pathlib import Path
from typing import Any

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("growthbridge_server", HERE / "server.py")
if spec is None or spec.loader is None:
    raise SystemExit("SERVER_IMPORT_GATE=FAIL")
server = importlib.util.module_from_spec(spec)
spec.loader.exec_module(server)


def request(base: str, method: str, path: str, payload: dict[str, Any] | None = None, token: str | None = None, expected: int = 200) -> dict[str, Any]:
    data = None if payload is None else json.dumps(payload).encode("utf-8")
    headers = {"Content-Type": "application/json"}
    if token:
        headers["Authorization"] = f"Bearer {token}"
    req = urllib.request.Request(base + path, data=data, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req, timeout=5) as resp:
            status = resp.status
            raw = resp.read().decode("utf-8")
    except urllib.error.HTTPError as exc:
        status = exc.code
        raw = exc.read().decode("utf-8")
    if status != expected:
        raise AssertionError(f"{method} {path}: expected={expected} actual={status} body={raw}")
    return json.loads(raw) if raw else {}


def main() -> None:
    with tempfile.TemporaryDirectory(prefix="growthbridge-v23-test-") as td:
        store = server.GrowthBridgeStore(Path(td) / "test.db")
        httpd = server.Server(("127.0.0.1", 0), store)
        thread = threading.Thread(target=httpd.serve_forever, daemon=True)
        thread.start()
        base = f"http://127.0.0.1:{httpd.server_address[1]}"
        try:
            health = request(base, "GET", "/api/v1/health")
            assert health["appVersion"] == "2.3.0"
            assert health["dataModel"] == "multi_institution_normalized"

            owner = request(base, "POST", "/api/v1/auth/register", {
                "clientRole": "teacher", "displayName": "Owner", "email": "owner@example.test", "password": "OwnerPassword123!"
            }, expected=201)
            owner_token = owner["token"]
            school = request(base, "POST", "/api/v1/teacher/institutions", {"name": "Integration School"}, owner_token, 201)
            institution_id = school["id"]
            school_code = school["code"]

            class_a = request(base, "POST", f"/api/v1/institutions/{institution_id}/classes", {"name": "Class A", "code": "A1"}, owner_token, 201)
            class_b = request(base, "POST", f"/api/v1/institutions/{institution_id}/classes", {"name": "Class B", "code": "B1"}, owner_token, 201)

            # Invalid class IDs must fail atomically and leave no phantom student.
            request(base, "POST", f"/api/v1/institutions/{institution_id}/students", {
                "preferredName": "Should Not Exist", "classIds": ["bad-class-id"]
            }, owner_token, 400)
            workspace = request(base, "GET", f"/api/v1/teacher/workspace/{institution_id}", token=owner_token)
            assert all(s["displayName"] != "Should Not Exist" for s in workspace["students"])

            student = request(base, "POST", f"/api/v1/institutions/{institution_id}/students", {
                "studentCode": "S001", "firstName": "Daniel", "chineseName": "丹尼", "classIds": [class_a["id"], class_b["id"]]
            }, owner_token, 201)
            student_id = student["id"]

            teacher2 = request(base, "POST", "/api/v1/auth/register", {
                "clientRole": "teacher", "displayName": "Teacher Two", "email": "teacher2@example.test", "password": "TeacherPassword123!"
            }, expected=201)
            teacher2_token = teacher2["token"]
            invite = request(base, "POST", f"/api/v1/institutions/{institution_id}/teacher-invitations", {
                "role": "teacher", "email": "teacher2@example.test", "classIds": [class_a["id"]]
            }, owner_token, 201)
            request(base, "POST", "/api/v1/teacher/invitations/accept", {"token": invite["token"]}, teacher2_token)
            teacher2_ws = request(base, "GET", f"/api/v1/teacher/workspace/{institution_id}", token=teacher2_token)
            assert [c["id"] for c in teacher2_ws["classes"]] == [class_a["id"]]
            assert teacher2_ws["canManage"] is False

            request(base, "POST", "/api/v1/evidence", {
                "institutionId": institution_id, "classId": class_b["id"], "studentId": student_id,
                "observation": "Forbidden evidence", "visibility": "teacher_only", "publishState": "draft"
            }, teacher2_token, 403)

            owner_evidence = request(base, "POST", "/api/v1/evidence", {
                "institutionId": institution_id, "classId": class_a["id"], "studentId": student_id,
                "observation": "Owner evidence", "visibility": "teacher_only", "publishState": "draft"
            }, owner_token, 201)
            request(base, "PATCH", f"/api/v1/evidence/{owner_evidence['id']}", {
                "visibility": "parent_visible", "publishState": "published"
            }, teacher2_token, 403)

            teacher2_evidence = request(base, "POST", "/api/v1/evidence", {
                "institutionId": institution_id, "classId": class_a["id"], "studentId": student_id,
                "observation": "Published teacher evidence", "interpretation": "Verified classroom observation.",
                "dimensions": ["confidence"], "visibility": "parent_visible", "publishState": "published"
            }, teacher2_token, 201)

            parent = request(base, "POST", "/api/v1/auth/register", {
                "clientRole": "parent", "displayName": "Parent", "email": "parent@example.test", "password": "ParentPassword123!"
            }, expected=201)
            parent_token = parent["token"]
            claim = request(base, "POST", f"/api/v1/students/{student_id}/claim-code", {}, owner_token, 201)
            request(base, "POST", "/api/v1/parent/claim-child", {"code": claim["code"]}, parent_token)
            children = request(base, "GET", "/api/v1/parent/children", token=parent_token)
            assert len(children["children"]) == 1 and children["children"][0]["id"] == student_id

            detail = request(base, "GET", f"/api/v1/parent/child/{student_id}", token=parent_token)
            assert len(detail["evidence"]) == 1
            assert detail["evidence"][0]["id"] == teacher2_evidence["id"]

            request(base, "POST", "/api/v1/class-sessions", {
                "institutionId": institution_id, "classId": class_a["id"], "date": "2026-10-15", "topic": "Integration",
                "rows": [{"studentId": student_id, "status": "present", "participation": 4, "confidence": 5, "homework": "done", "note": ""}]
            }, teacher2_token)
            detail2 = request(base, "GET", f"/api/v1/parent/child/{student_id}", token=parent_token)
            assert detail2["attendanceSummary"]["counts"]["present"] == 1

            teacher3 = request(base, "POST", "/api/v1/auth/register", {
                "clientRole": "teacher", "displayName": "Teacher Three", "email": "teacher3@example.test", "password": "TeacherPassword123!"
            }, expected=201)
            teacher3_token = teacher3["token"]
            join = request(base, "POST", "/api/v1/teacher/join-requests", {"schoolCode": school_code}, teacher3_token, 201)
            owner_ws = request(base, "GET", f"/api/v1/teacher/workspace/{institution_id}", token=owner_token)
            assert any(r["id"] == join["id"] for r in owner_ws["joinRequests"])
            request(base, "POST", f"/api/v1/institutions/{institution_id}/join-requests/{join['id']}/approve", {}, owner_token)
            teacher3_ws = request(base, "GET", f"/api/v1/teacher/workspace/{institution_id}", token=teacher3_token)
            assert teacher3_ws["classes"] == []

            # A teacher already in an institution must not be downgraded by accepting another invite.
            owner_invite = request(base, "POST", f"/api/v1/institutions/{institution_id}/teacher-invitations", {
                "role": "teacher", "email": "owner@example.test", "classIds": [class_a["id"]]
            }, owner_token, 201)
            request(base, "POST", "/api/v1/teacher/invitations/accept", {"token": owner_invite["token"]}, owner_token, 409)
            owner_ws_after = request(base, "GET", f"/api/v1/teacher/workspace/{institution_id}", token=owner_token)
            assert owner_ws_after["institution"]["role"] == "owner"

            print("BACKEND_MULTI_TENANT_INTEGRATION_GATE=PASS")
            print("CROSS_INSTITUTION_PARENT_MODEL_GATE=PASS")
            print("TEACHER_CLASS_SCOPE_GATE=PASS")
            print("STUDENT_CREATE_ATOMICITY_GATE=PASS")
            print("EVIDENCE_OWNERSHIP_GATE=PASS")
            print("MEMBERSHIP_DOWNGRADE_GUARD_GATE=PASS")
        finally:
            httpd.shutdown()
            httpd.server_close()
            thread.join(timeout=3)


if __name__ == "__main__":
    main()
