#!/usr/bin/env python3
from __future__ import annotations

import importlib.util
import json
import tempfile
import threading
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Any

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("growthbridge_server", HERE / "server.py")
if spec is None or spec.loader is None:
    raise SystemExit("SERVER_IMPORT_GATE=FAIL")
server = importlib.util.module_from_spec(spec)
spec.loader.exec_module(server)


def request(base: str, method: str, path: str, payload: dict[str, Any] | None = None, token: str | None = None, expected: int = 200) -> dict[str, Any]:
    data = None if payload is None else json.dumps(payload).encode("utf-8")
    headers = {"Content-Type": "application/json", "User-Agent": "GrowthBridgeOperationalTest/2.3"}
    if token:
        headers["Authorization"] = f"Bearer {token}"
    req = urllib.request.Request(base + path, data=data, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req, timeout=5) as resp:
            status = resp.status
            raw = resp.read().decode("utf-8")
    except urllib.error.HTTPError as exc:
        status = exc.code
        raw = exc.read().decode("utf-8")
    if status != expected:
        raise AssertionError(f"{method} {path}: expected={expected} actual={status} body={raw}")
    return json.loads(raw) if raw else {}


def main() -> None:
    with tempfile.TemporaryDirectory(prefix="growthbridge-v23-operational-") as td:
        db = Path(td) / "test.db"
        store = server.GrowthBridgeStore(db)
        httpd = server.Server(("127.0.0.1", 0), store)
        thread = threading.Thread(target=httpd.serve_forever, daemon=True)
        thread.start()
        base = f"http://127.0.0.1:{httpd.server_address[1]}"
        try:
            health = request(base, "GET", "/api/v1/health")
            assert health["appVersion"] == "2.3.0"

            owner = request(base, "POST", "/api/v1/auth/register", {
                "clientRole": "teacher", "displayName": "Owner", "email": "owner23@example.test", "password": "OwnerPassword123!"
            }, expected=201)
            owner_token = owner["token"]
            institution = request(base, "POST", "/api/v1/teacher/institutions", {"name": "Operational School"}, owner_token, 201)
            institution_id = institution["id"]
            klass = request(base, "POST", f"/api/v1/institutions/{institution_id}/classes", {
                "name": "Class 1", "code": "C1", "gradeLabel": "Grade 3", "termLabel": "2026 Autumn"
            }, owner_token, 201)
            class_id = klass["id"]
            student = request(base, "POST", f"/api/v1/institutions/{institution_id}/students", {
                "studentCode": "D001", "preferredName": "Daniel", "chineseName": "丹尼", "classIds": [class_id]
            }, owner_token, 201)
            student_id = student["id"]

            # Operational editing is additive/non-destructive.
            updated_class = request(base, "PATCH", f"/api/v1/institutions/{institution_id}/classes/{class_id}", {
                "name": "Class 1A", "gradeLabel": "Grade 3A", "termLabel": "2026 Autumn"
            }, owner_token)
            assert updated_class["name"] == "Class 1A"
            updated_student = request(base, "PATCH", f"/api/v1/institutions/{institution_id}/students/{student_id}", {
                "preferredName": "Daniel A.", "classIds": [class_id]
            }, owner_token)
            assert updated_student["displayName"] == "Daniel A."

            # Session history can be saved, listed, and reopened for correction.
            saved = request(base, "POST", "/api/v1/class-sessions", {
                "institutionId": institution_id, "classId": class_id, "date": "2026-10-15", "topic": "Operational lesson",
                "rows": [{"studentId": student_id, "status": "present", "participation": 4, "confidence": 5, "homework": "done", "note": "Good"}]
            }, owner_token)
            sessions = request(base, "GET", f"/api/v1/class-sessions?institutionId={urllib.parse.quote(institution_id)}&classId={urllib.parse.quote(class_id)}", token=owner_token)
            assert sessions["sessions"][0]["id"] == saved["id"]
            session_detail = request(base, "GET", f"/api/v1/class-sessions/{saved['id']}", token=owner_token)
            assert session_detail["rows"][0]["studentId"] == student_id
            assert session_detail["rows"][0]["confidence"] == 5

            # Parent account, child claim, milestone, and home action synchronize end-to-end.
            parent = request(base, "POST", "/api/v1/auth/register", {
                "clientRole": "parent", "displayName": "Parent", "email": "parent23@example.test", "password": "ParentPassword123!"
            }, expected=201)
            parent_token = parent["token"]
            claim = request(base, "POST", f"/api/v1/students/{student_id}/claim-code", {}, owner_token, 201)
            request(base, "POST", "/api/v1/parent/claim-child", {"code": claim["code"]}, parent_token)

            milestone = request(base, "POST", "/api/v1/evidence", {
                "institutionId": institution_id, "classId": class_id, "studentId": student_id, "date": "2026-10-15",
                "kind": "milestone", "observation": "First independent presentation", "interpretation": "Completed without prompting.",
                "dimensions": ["confidence", "independence"], "visibility": "parent_visible", "publishState": "published"
            }, owner_token, 201)
            action = request(base, "POST", "/api/v1/parent-actions", {
                "institutionId": institution_id, "classId": class_id, "studentId": student_id,
                "title": "Read together", "detail": "Read one short story and ask two questions.", "dueDate": "2026-10-20"
            }, owner_token, 201)
            detail = request(base, "GET", f"/api/v1/parent/child/{student_id}", token=parent_token)
            assert any(item["id"] == milestone["id"] for item in detail["milestones"])
            assert detail["growthSummary"]["confidence"]["count"] == 1
            assert any(item["id"] == action["id"] and item["status"] == "open" for item in detail["parentActions"])
            done = request(base, "PATCH", f"/api/v1/parent-actions/{action['id']}", {"status": "done"}, parent_token)
            assert done["status"] == "done"

            report = request(base, "GET", f"/api/v1/parent/child/{student_id}/report?period=month", token=parent_token)
            assert report["evidenceCount"] == 1
            assert report["attendance"]["sessionCount"] == 1
            assert report["dimensionEvidenceCounts"]["confidence"] == 1
            teacher_report = request(base, "GET", f"/api/v1/teacher/student/{student_id}/report?institutionId={institution_id}&period=month", token=owner_token)
            assert teacher_report["child"]["id"] == student_id

            # Revoked claim cannot be redeemed.
            extra_student = request(base, "POST", f"/api/v1/institutions/{institution_id}/students", {"preferredName": "Second Child", "classIds": [class_id]}, owner_token, 201)
            revoked_claim = request(base, "POST", f"/api/v1/students/{extra_student['id']}/claim-code", {}, owner_token, 201)
            request(base, "DELETE", f"/api/v1/students/{extra_student['id']}/claim-code/{revoked_claim['id']}", {}, owner_token)
            request(base, "POST", "/api/v1/parent/claim-child", {"code": revoked_claim["code"]}, parent_token, 400)

            # Teacher join rejection and invitation revocation are operationally enforceable.
            teacher = request(base, "POST", "/api/v1/auth/register", {
                "clientRole": "teacher", "displayName": "Teacher", "email": "teacher23@example.test", "password": "TeacherPassword123!"
            }, expected=201)
            teacher_token = teacher["token"]
            join = request(base, "POST", "/api/v1/teacher/join-requests", {"schoolCode": institution["code"]}, teacher_token, 201)
            request(base, "POST", f"/api/v1/institutions/{institution_id}/join-requests/{join['id']}/reject", {}, owner_token)
            owner_ws = request(base, "GET", f"/api/v1/teacher/workspace/{institution_id}", token=owner_token)
            assert all(item["id"] != join["id"] for item in owner_ws["joinRequests"])

            invite = request(base, "POST", f"/api/v1/institutions/{institution_id}/teacher-invitations", {
                "role": "teacher", "email": "teacher23@example.test", "classIds": [class_id]
            }, owner_token, 201)
            request(base, "DELETE", f"/api/v1/institutions/{institution_id}/teacher-invitations/{invite['id']}", {}, owner_token)
            request(base, "POST", "/api/v1/teacher/invitations/accept", {"token": invite["token"]}, teacher_token, 400)

            # Membership role/status policy.
            join2 = request(base, "POST", "/api/v1/teacher/join-requests", {"schoolCode": institution["code"]}, teacher_token, 201)
            request(base, "POST", f"/api/v1/institutions/{institution_id}/join-requests/{join2['id']}/approve", {}, owner_token)
            request(base, "PATCH", f"/api/v1/institutions/{institution_id}/members/{teacher['account']['id']}", {"role": "admin", "status": "active"}, owner_token)
            teacher_ws = request(base, "GET", f"/api/v1/teacher/workspace/{institution_id}", token=teacher_token)
            assert teacher_ws["institution"]["role"] == "admin"
            request(base, "PATCH", f"/api/v1/institutions/{institution_id}/members/{owner['account']['id']}", {"role": "teacher"}, owner_token, 409)

            # Session/device management.
            second_login = request(base, "POST", "/api/v1/auth/login", {
                "clientRole": "parent", "email": "parent23@example.test", "password": "ParentPassword123!"
            })
            sessions_payload = request(base, "GET", "/api/v1/auth/sessions", token=parent_token)
            assert len(sessions_payload["sessions"]) >= 2
            other = next(item for item in sessions_payload["sessions"] if not item["current"])
            request(base, "DELETE", f"/api/v1/auth/sessions/{other['id']}", {}, parent_token)
            request(base, "GET", "/api/v1/auth/me", token=second_login["token"], expected=401)

            # Audit viewer sees operational mutations.
            audit = request(base, "GET", f"/api/v1/institutions/{institution_id}/audit?limit=200", token=owner_token)
            actions = {item["action"] for item in audit["events"]}
            assert "update_class" in actions and "create_parent_action" in actions and "revoke_teacher_invite" in actions

            # Parent unlink is scoped and non-destructive.
            request(base, "DELETE", f"/api/v1/parent/children/{student_id}", {}, parent_token)
            request(base, "GET", f"/api/v1/parent/child/{student_id}", token=parent_token, expected=403)
            owner_ws_after = request(base, "GET", f"/api/v1/teacher/workspace/{institution_id}", token=owner_token)
            assert any(item["id"] == student_id for item in owner_ws_after["students"])

            print("SCHOOL_OPERATION_WORKFLOW_GATE=PASS")
            print("CLASS_ROSTER_WORKFLOW_GATE=PASS")
            print("SESSION_HISTORY_CORRECTION_GATE=PASS")
            print("PARENT_CHILD_LINK_WORKFLOW_GATE=PASS")
            print("PARENT_ACTION_SYNC_GATE=PASS")
            print("MILESTONE_REPORT_GATE=PASS")
            print("INVITATION_REVOCATION_GATE=PASS")
            print("JOIN_REQUEST_REJECTION_GATE=PASS")
            print("STAFF_ROLE_POLICY_GATE=PASS")
            print("MULTI_DEVICE_SESSION_GATE=PASS")
            print("AUDIT_VIEWER_GATE=PASS")
        finally:
            httpd.shutdown()
            httpd.server_close()
            thread.join(timeout=3)


if __name__ == "__main__":
    main()
