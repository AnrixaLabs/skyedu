#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import hmac
import json
import re
import secrets
import sqlite3
import threading
import time
import uuid
from datetime import date, datetime, timezone, timedelta
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any
from urllib.parse import parse_qs, urlparse

APP_VERSION = "2.3.0"
API_VERSION = "v1"
PASSWORD_ITERATIONS = 310_000
SESSION_TTL_SECONDS = 30 * 24 * 3600
TEACHER_INVITE_TTL_SECONDS = 14 * 24 * 3600
CHILD_CLAIM_TTL_SECONDS = 30 * 24 * 3600
MAX_BODY_BYTES = 1024 * 1024
MUTATION_RATE_LIMIT = 240
MUTATION_RATE_WINDOW_SECONDS = 60
LOGIN_FAILURE_LIMIT = 8
LOGIN_LOCK_SECONDS = 15 * 60

LOGIN_GUARD: dict[str, tuple[int, float]] = {}
LOGIN_GUARD_LOCK = threading.Lock()
MUTATION_GUARD: dict[str, list[float]] = {}
MUTATION_GUARD_LOCK = threading.Lock()


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def unix_now() -> int:
    return int(time.time())


def json_dumps(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, separators=(",", ":"))


def normalize_email(value: str) -> str:
    return value.strip().lower()


def clean_text(value: Any, max_len: int = 240) -> str:
    return str(value or "").strip()[:max_len]


def password_hash(password: str, salt: bytes | None = None) -> tuple[str, str]:
    if salt is None:
        salt = secrets.token_bytes(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, PASSWORD_ITERATIONS)
    return salt.hex(), digest.hex()


def password_verify(password: str, salt_hex: str, digest_hex: str) -> bool:
    try:
        salt = bytes.fromhex(salt_hex)
    except ValueError:
        return False
    _, current = password_hash(password, salt)
    return hmac.compare_digest(current, digest_hex)


def token_hash(token: str) -> str:
    return hashlib.sha256(token.encode("utf-8")).hexdigest()


def new_token(bytes_len: int = 32) -> str:
    return secrets.token_urlsafe(bytes_len)


def human_code(prefix: str, chars: int = 6) -> str:
    alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
    return prefix + "-" + "".join(secrets.choice(alphabet) for _ in range(chars))


def student_display(row: sqlite3.Row | dict[str, Any]) -> str:
    getter = row.__getitem__
    preferred = clean_text(getter("preferred_name") if isinstance(row, sqlite3.Row) else row.get("preferred_name"))
    chinese = clean_text(getter("chinese_name") if isinstance(row, sqlite3.Row) else row.get("chinese_name"))
    first = clean_text(getter("first_name") if isinstance(row, sqlite3.Row) else row.get("first_name"))
    last = clean_text(getter("last_name") if isinstance(row, sqlite3.Row) else row.get("last_name"))
    english = " ".join(x for x in [first, last] if x)
    return preferred or chinese or english or "Unnamed student"


def check_mutation_rate(ip: str) -> None:
    now = time.time()
    cutoff = now - MUTATION_RATE_WINDOW_SECONDS
    with MUTATION_GUARD_LOCK:
        entries = [value for value in MUTATION_GUARD.get(ip, []) if value >= cutoff]
        if len(entries) >= MUTATION_RATE_LIMIT:
            MUTATION_GUARD[ip] = entries
            raise ApiError(429, "RATE_LIMITED", "Too many write requests. Please try again shortly.")
        entries.append(now)
        MUTATION_GUARD[ip] = entries


class ApiError(Exception):
    def __init__(self, status: int, code: str, message: str):
        super().__init__(message)
        self.status = int(status)
        self.code = code
        self.message = message


class GrowthBridgeStore:
    def __init__(self, db_path: Path):
        self.db_path = db_path
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()
        self._init_db()

    def connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.db_path, timeout=30, isolation_level=None)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys=ON")
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA synchronous=NORMAL")
        conn.execute("PRAGMA busy_timeout=30000")
        return conn

    def _columns(self, conn: sqlite3.Connection, table: str) -> set[str]:
        return {row[1] for row in conn.execute(f"PRAGMA table_info({table})")}

    def _init_db(self) -> None:
        with self._lock, self.connect() as conn:
            conn.executescript(
                """
                CREATE TABLE IF NOT EXISTS meta (
                    key TEXT PRIMARY KEY,
                    value TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS accounts (
                    id TEXT PRIMARY KEY,
                    email TEXT UNIQUE NOT NULL,
                    display_name TEXT NOT NULL,
                    role TEXT NOT NULL CHECK(role IN ('parent','teacher')),
                    password_salt TEXT NOT NULL,
                    password_digest TEXT NOT NULL,
                    disabled INTEGER NOT NULL DEFAULT 0,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS sessions (
                    id TEXT PRIMARY KEY,
                    account_id TEXT NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
                    token_hash TEXT UNIQUE NOT NULL,
                    client_role TEXT NOT NULL CHECK(client_role IN ('parent','teacher')),
                    created_at TEXT NOT NULL,
                    last_seen_at TEXT NOT NULL,
                    expires_at INTEGER NOT NULL
                );
                CREATE INDEX IF NOT EXISTS idx_sessions_token ON sessions(token_hash);
                CREATE INDEX IF NOT EXISTS idx_sessions_account ON sessions(account_id);

                CREATE TABLE IF NOT EXISTS institutions (
                    id TEXT PRIMARY KEY,
                    name TEXT NOT NULL,
                    code TEXT UNIQUE NOT NULL,
                    status TEXT NOT NULL DEFAULT 'active' CHECK(status IN ('active','archived')),
                    created_by TEXT NOT NULL REFERENCES accounts(id),
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                );
                CREATE INDEX IF NOT EXISTS idx_institutions_code ON institutions(code);

                CREATE TABLE IF NOT EXISTS institution_memberships (
                    institution_id TEXT NOT NULL REFERENCES institutions(id) ON DELETE CASCADE,
                    account_id TEXT NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
                    role TEXT NOT NULL CHECK(role IN ('owner','admin','teacher')),
                    status TEXT NOT NULL DEFAULT 'active' CHECK(status IN ('active','pending','disabled')),
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    PRIMARY KEY(institution_id, account_id)
                );
                CREATE INDEX IF NOT EXISTS idx_membership_account ON institution_memberships(account_id,status);

                CREATE TABLE IF NOT EXISTS teacher_join_requests (
                    id TEXT PRIMARY KEY,
                    institution_id TEXT NOT NULL REFERENCES institutions(id) ON DELETE CASCADE,
                    teacher_account_id TEXT NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
                    status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','approved','rejected')),
                    created_at TEXT NOT NULL,
                    decided_at TEXT,
                    decided_by TEXT REFERENCES accounts(id),
                    UNIQUE(institution_id, teacher_account_id, status)
                );

                CREATE TABLE IF NOT EXISTS teacher_invitations (
                    id TEXT PRIMARY KEY,
                    institution_id TEXT NOT NULL REFERENCES institutions(id) ON DELETE CASCADE,
                    token_hash TEXT UNIQUE NOT NULL,
                    email TEXT,
                    membership_role TEXT NOT NULL CHECK(membership_role IN ('admin','teacher')),
                    class_ids_json TEXT NOT NULL DEFAULT '[]',
                    created_by TEXT NOT NULL REFERENCES accounts(id),
                    created_at TEXT NOT NULL,
                    expires_at INTEGER NOT NULL,
                    used_by TEXT REFERENCES accounts(id),
                    used_at TEXT
                );
                CREATE INDEX IF NOT EXISTS idx_teacher_invite_token ON teacher_invitations(token_hash);

                CREATE TABLE IF NOT EXISTS classes (
                    id TEXT PRIMARY KEY,
                    institution_id TEXT NOT NULL REFERENCES institutions(id) ON DELETE CASCADE,
                    name TEXT NOT NULL,
                    code TEXT NOT NULL,
                    grade_label TEXT NOT NULL DEFAULT '',
                    term_label TEXT NOT NULL DEFAULT '',
                    status TEXT NOT NULL DEFAULT 'active' CHECK(status IN ('active','archived')),
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    UNIQUE(institution_id, code)
                );
                CREATE INDEX IF NOT EXISTS idx_classes_institution ON classes(institution_id,status);

                CREATE TABLE IF NOT EXISTS students (
                    id TEXT PRIMARY KEY,
                    institution_id TEXT NOT NULL REFERENCES institutions(id) ON DELETE CASCADE,
                    student_code TEXT NOT NULL DEFAULT '',
                    first_name TEXT NOT NULL DEFAULT '',
                    last_name TEXT NOT NULL DEFAULT '',
                    preferred_name TEXT NOT NULL DEFAULT '',
                    chinese_name TEXT NOT NULL DEFAULT '',
                    status TEXT NOT NULL DEFAULT 'active' CHECK(status IN ('active','archived')),
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                );
                CREATE INDEX IF NOT EXISTS idx_students_institution ON students(institution_id,status);
                CREATE INDEX IF NOT EXISTS idx_students_code ON students(institution_id,student_code);

                CREATE TABLE IF NOT EXISTS class_students (
                    class_id TEXT NOT NULL REFERENCES classes(id) ON DELETE CASCADE,
                    student_id TEXT NOT NULL REFERENCES students(id) ON DELETE CASCADE,
                    created_at TEXT NOT NULL,
                    PRIMARY KEY(class_id, student_id)
                );
                CREATE INDEX IF NOT EXISTS idx_class_students_student ON class_students(student_id);

                CREATE TABLE IF NOT EXISTS teacher_class_assignments (
                    class_id TEXT NOT NULL REFERENCES classes(id) ON DELETE CASCADE,
                    teacher_account_id TEXT NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
                    assigned_by TEXT NOT NULL REFERENCES accounts(id),
                    created_at TEXT NOT NULL,
                    PRIMARY KEY(class_id, teacher_account_id)
                );
                CREATE INDEX IF NOT EXISTS idx_teacher_classes_teacher ON teacher_class_assignments(teacher_account_id);

                CREATE TABLE IF NOT EXISTS guardian_links_v2 (
                    parent_account_id TEXT NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
                    student_id TEXT NOT NULL REFERENCES students(id) ON DELETE CASCADE,
                    relationship TEXT NOT NULL DEFAULT 'guardian',
                    created_at TEXT NOT NULL,
                    PRIMARY KEY(parent_account_id, student_id)
                );
                CREATE INDEX IF NOT EXISTS idx_guardian_links_student ON guardian_links_v2(student_id);

                CREATE TABLE IF NOT EXISTS child_claims (
                    id TEXT PRIMARY KEY,
                    student_id TEXT NOT NULL REFERENCES students(id) ON DELETE CASCADE,
                    token_hash TEXT UNIQUE NOT NULL,
                    created_by TEXT NOT NULL REFERENCES accounts(id),
                    created_at TEXT NOT NULL,
                    expires_at INTEGER NOT NULL,
                    used_by TEXT REFERENCES accounts(id),
                    used_at TEXT
                );
                CREATE INDEX IF NOT EXISTS idx_child_claim_token ON child_claims(token_hash);

                CREATE TABLE IF NOT EXISTS growth_evidence (
                    id TEXT PRIMARY KEY,
                    institution_id TEXT NOT NULL REFERENCES institutions(id) ON DELETE CASCADE,
                    class_id TEXT REFERENCES classes(id) ON DELETE SET NULL,
                    student_id TEXT NOT NULL REFERENCES students(id) ON DELETE CASCADE,
                    teacher_account_id TEXT NOT NULL REFERENCES accounts(id),
                    evidence_date TEXT NOT NULL,
                    kind TEXT NOT NULL DEFAULT 'observation',
                    observation TEXT NOT NULL,
                    interpretation TEXT NOT NULL DEFAULT '',
                    dimensions_json TEXT NOT NULL DEFAULT '[]',
                    visibility TEXT NOT NULL DEFAULT 'teacher_only' CHECK(visibility IN ('teacher_only','parent_visible','report')),
                    publish_state TEXT NOT NULL DEFAULT 'draft' CHECK(publish_state IN ('draft','ready','published')),
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                );
                CREATE INDEX IF NOT EXISTS idx_evidence_student ON growth_evidence(student_id,evidence_date);
                CREATE INDEX IF NOT EXISTS idx_evidence_institution ON growth_evidence(institution_id,updated_at);

                CREATE TABLE IF NOT EXISTS class_sessions (
                    id TEXT PRIMARY KEY,
                    class_id TEXT NOT NULL REFERENCES classes(id) ON DELETE CASCADE,
                    session_date TEXT NOT NULL,
                    topic TEXT NOT NULL DEFAULT '',
                    created_by TEXT NOT NULL REFERENCES accounts(id),
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    UNIQUE(class_id, session_date)
                );
                CREATE INDEX IF NOT EXISTS idx_sessions_class_date ON class_sessions(class_id,session_date);

                CREATE TABLE IF NOT EXISTS attendance_entries (
                    session_id TEXT NOT NULL REFERENCES class_sessions(id) ON DELETE CASCADE,
                    student_id TEXT NOT NULL REFERENCES students(id) ON DELETE CASCADE,
                    status TEXT NOT NULL CHECK(status IN ('present','late','absent','excused')),
                    participation INTEGER NOT NULL DEFAULT 3 CHECK(participation BETWEEN 1 AND 5),
                    confidence INTEGER NOT NULL DEFAULT 3 CHECK(confidence BETWEEN 1 AND 5),
                    homework TEXT NOT NULL DEFAULT 'done' CHECK(homework IN ('done','partial','missing')),
                    note TEXT NOT NULL DEFAULT '',
                    updated_at TEXT NOT NULL,
                    PRIMARY KEY(session_id, student_id)
                );
                CREATE INDEX IF NOT EXISTS idx_attendance_student ON attendance_entries(student_id,updated_at);

                CREATE TABLE IF NOT EXISTS parent_actions (
                    id TEXT PRIMARY KEY,
                    institution_id TEXT NOT NULL REFERENCES institutions(id) ON DELETE CASCADE,
                    class_id TEXT REFERENCES classes(id) ON DELETE SET NULL,
                    student_id TEXT NOT NULL REFERENCES students(id) ON DELETE CASCADE,
                    teacher_account_id TEXT NOT NULL REFERENCES accounts(id),
                    title TEXT NOT NULL,
                    detail TEXT NOT NULL DEFAULT '',
                    due_date TEXT,
                    status TEXT NOT NULL DEFAULT 'open' CHECK(status IN ('open','done')),
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                );
                CREATE INDEX IF NOT EXISTS idx_parent_actions_student ON parent_actions(student_id,status,due_date);
                CREATE INDEX IF NOT EXISTS idx_parent_actions_institution ON parent_actions(institution_id,updated_at);

                CREATE TABLE IF NOT EXISTS audit_events_v2 (
                    id TEXT PRIMARY KEY,
                    account_id TEXT,
                    institution_id TEXT,
                    action TEXT NOT NULL,
                    object_type TEXT,
                    object_id TEXT,
                    detail_json TEXT NOT NULL DEFAULT '{}',
                    created_at TEXT NOT NULL
                );
                CREATE INDEX IF NOT EXISTS idx_audit_institution ON audit_events_v2(institution_id,created_at);
                """
            )
            # v2.1 sessions did not have client_role. Add it without destroying active accounts.
            session_columns = self._columns(conn, "sessions")
            if "client_role" not in session_columns:
                conn.execute("ALTER TABLE sessions ADD COLUMN client_role TEXT NOT NULL DEFAULT 'teacher'")
                conn.execute(
                    "UPDATE sessions SET client_role=(SELECT role FROM accounts WHERE accounts.id=sessions.account_id)"
                )
            session_columns = self._columns(conn, "sessions")
            if "ip_address" not in session_columns:
                conn.execute("ALTER TABLE sessions ADD COLUMN ip_address TEXT NOT NULL DEFAULT ''")
            if "user_agent" not in session_columns:
                conn.execute("ALTER TABLE sessions ADD COLUMN user_agent TEXT NOT NULL DEFAULT ''")
            invite_columns = self._columns(conn, "teacher_invitations")
            if "revoked_at" not in invite_columns:
                conn.execute("ALTER TABLE teacher_invitations ADD COLUMN revoked_at TEXT")
            if "revoked_by" not in invite_columns:
                conn.execute("ALTER TABLE teacher_invitations ADD COLUMN revoked_by TEXT")
            claim_columns = self._columns(conn, "child_claims")
            if "revoked_at" not in claim_columns:
                conn.execute("ALTER TABLE child_claims ADD COLUMN revoked_at TEXT")
            if "revoked_by" not in claim_columns:
                conn.execute("ALTER TABLE child_claims ADD COLUMN revoked_by TEXT")
            conn.execute("INSERT OR REPLACE INTO meta(key,value) VALUES('schema_version',?)", (APP_VERSION,))
            conn.execute("INSERT OR REPLACE INTO meta(key,value) VALUES('data_model','multi_institution_normalized')")

    def audit(self, conn: sqlite3.Connection, account_id: str | None, action: str, *, institution_id: str | None = None, object_type: str | None = None, object_id: str | None = None, detail: Any | None = None) -> None:
        conn.execute(
            "INSERT INTO audit_events_v2(id,account_id,institution_id,action,object_type,object_id,detail_json,created_at) VALUES(?,?,?,?,?,?,?,?)",
            (str(uuid.uuid4()), account_id, institution_id, action, object_type, object_id, json_dumps(detail or {}), utc_now()),
        )

    # ---------- Authentication ----------
    def status(self) -> dict[str, Any]:
        with self.connect() as conn:
            accounts = conn.execute("SELECT COUNT(*) FROM accounts WHERE disabled=0").fetchone()[0]
            institutions = conn.execute("SELECT COUNT(*) FROM institutions WHERE status='active'").fetchone()[0]
            return {
                "appVersion": APP_VERSION,
                "apiVersion": API_VERSION,
                "registrationOpen": True,
                "accountsCount": accounts,
                "institutionsCount": institutions,
                "dataModel": "multi_institution_normalized",
            }

    def _validate_account_input(self, display_name: str, email: str, password: str) -> tuple[str, str]:
        name = clean_text(display_name, 100)
        normalized = normalize_email(email)
        if not name:
            raise ApiError(400, "DISPLAY_NAME_REQUIRED", "Display name is required.")
        if "@" not in normalized or len(normalized) > 254:
            raise ApiError(400, "EMAIL_INVALID", "A valid email address is required.")
        if len(password) < 10:
            raise ApiError(400, "PASSWORD_TOO_SHORT", "Password must contain at least 10 characters.")
        return name, normalized


    def register(self, role: str, display_name: str, email: str, password: str, ip: str = "", user_agent: str = "") -> tuple[dict[str, Any], str]:
        if role not in {"parent", "teacher"}:
            raise ApiError(400, "CLIENT_ROLE_INVALID", "Client role is invalid.")
        name, normalized = self._validate_account_input(display_name, email, password)
        salt, digest = password_hash(password)
        account_id = str(uuid.uuid4())
        now = utc_now()
        with self._lock, self.connect() as conn:
            try:
                conn.execute(
                    "INSERT INTO accounts(id,email,display_name,role,password_salt,password_digest,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?)",
                    (account_id, normalized, name, role, salt, digest, now, now),
                )
            except sqlite3.IntegrityError as exc:
                raise ApiError(409, "EMAIL_EXISTS", "An account already exists for this email address.") from exc
            token = self._create_session(conn, account_id, role, ip=ip, user_agent=user_agent)
            self.audit(conn, account_id, "register_account", object_type="account", object_id=account_id, detail={"role": role})
            return {"id": account_id, "email": normalized, "displayName": name, "role": role}, token


    def _create_session(self, conn: sqlite3.Connection, account_id: str, client_role: str, *, ip: str = "", user_agent: str = "") -> str:
        token = new_token(32)
        now = utc_now()
        conn.execute(
            "INSERT INTO sessions(id,account_id,token_hash,client_role,created_at,last_seen_at,expires_at,ip_address,user_agent) VALUES(?,?,?,?,?,?,?,?,?)",
            (
                str(uuid.uuid4()), account_id, token_hash(token), client_role, now, now,
                unix_now() + SESSION_TTL_SECONDS, clean_text(ip, 120), clean_text(user_agent, 300),
            ),
        )
        return token

    def _check_login_guard(self, key: str) -> None:
        now = time.time()
        with LOGIN_GUARD_LOCK:
            failures, locked_until = LOGIN_GUARD.get(key, (0, 0.0))
            if locked_until > now:
                raise ApiError(429, "LOGIN_LOCKED", "Too many failed sign-in attempts. Please try again later.")
            if locked_until and locked_until <= now:
                LOGIN_GUARD.pop(key, None)

    def _record_login_failure(self, key: str) -> None:
        with LOGIN_GUARD_LOCK:
            failures, _ = LOGIN_GUARD.get(key, (0, 0.0))
            failures += 1
            LOGIN_GUARD[key] = (failures, time.time() + LOGIN_LOCK_SECONDS if failures >= LOGIN_FAILURE_LIMIT else 0.0)

    def _clear_login_guard(self, key: str) -> None:
        with LOGIN_GUARD_LOCK:
            LOGIN_GUARD.pop(key, None)


    def login(self, email: str, password: str, client_role: str, ip: str, user_agent: str = "") -> tuple[dict[str, Any], str]:
        if client_role not in {"parent", "teacher"}:
            raise ApiError(400, "CLIENT_ROLE_INVALID", "Client role is invalid.")
        normalized = normalize_email(email)
        key = f"{ip}|{normalized}"
        self._check_login_guard(key)
        with self._lock, self.connect() as conn:
            row = conn.execute("SELECT * FROM accounts WHERE email=?", (normalized,)).fetchone()
            valid = bool(row and not row["disabled"] and password_verify(password, row["password_salt"], row["password_digest"]))
            if not valid:
                self._record_login_failure(key)
                raise ApiError(401, "LOGIN_FAILED", "Email or password is incorrect.")
            if row["role"] != client_role:
                self._record_login_failure(key)
                raise ApiError(403, "ROLE_CLIENT_MISMATCH", "This account cannot sign in to this client.")
            self._clear_login_guard(key)
            token = self._create_session(conn, row["id"], client_role, ip=ip, user_agent=user_agent)
            account = self._account_payload(row)
            self.audit(conn, row["id"], "login", object_type="session", detail={"clientRole": client_role})
            return account, token

    def authenticate(self, bearer: str | None, required_role: str | None = None) -> dict[str, Any]:
        if not bearer:
            raise ApiError(401, "AUTH_REQUIRED", "Authentication is required.")
        hashed = token_hash(bearer)
        with self._lock, self.connect() as conn:
            row = conn.execute(
                "SELECT s.id AS session_id,s.expires_at,s.client_role,a.* FROM sessions s JOIN accounts a ON a.id=s.account_id WHERE s.token_hash=?",
                (hashed,),
            ).fetchone()
            if not row or row["expires_at"] <= unix_now() or row["disabled"]:
                if row:
                    conn.execute("DELETE FROM sessions WHERE id=?", (row["session_id"],))
                raise ApiError(401, "SESSION_INVALID", "Session is invalid or expired.")
            if row["client_role"] != row["role"]:
                raise ApiError(401, "SESSION_ROLE_INVALID", "Session role is invalid.")
            if required_role and row["role"] != required_role:
                raise ApiError(403, "ROLE_FORBIDDEN", "This operation is not available to this account role.")
            conn.execute("UPDATE sessions SET last_seen_at=? WHERE id=?", (utc_now(), row["session_id"]))
            payload = self._account_payload(row)
            payload["sessionId"] = row["session_id"]
            return payload

    def _account_payload(self, row: sqlite3.Row) -> dict[str, Any]:
        return {"id": row["id"], "email": row["email"], "displayName": row["display_name"], "role": row["role"]}

    def logout(self, bearer: str, account_id: str) -> None:
        with self._lock, self.connect() as conn:
            conn.execute("DELETE FROM sessions WHERE token_hash=? AND account_id=?", (token_hash(bearer), account_id))
            self.audit(conn, account_id, "logout")

    def change_password(self, account: dict[str, Any], current_password: str, new_password: str) -> None:
        if len(new_password) < 10:
            raise ApiError(400, "PASSWORD_TOO_SHORT", "Password must contain at least 10 characters.")
        with self._lock, self.connect() as conn:
            row = conn.execute("SELECT * FROM accounts WHERE id=?", (account["id"],)).fetchone()
            if not row or not password_verify(current_password, row["password_salt"], row["password_digest"]):
                raise ApiError(401, "CURRENT_PASSWORD_INVALID", "Current password is incorrect.")
            salt, digest = password_hash(new_password)
            conn.execute("UPDATE accounts SET password_salt=?,password_digest=?,updated_at=? WHERE id=?", (salt, digest, utc_now(), account["id"]))
            conn.execute("DELETE FROM sessions WHERE account_id=? AND id<>?", (account["id"], account.get("sessionId")))
            self.audit(conn, account["id"], "change_password", object_type="account", object_id=account["id"])


    def update_profile(self, account: dict[str, Any], display_name: str) -> dict[str, Any]:
        name = clean_text(display_name, 100)
        if not name:
            raise ApiError(400, "DISPLAY_NAME_REQUIRED", "Display name is required.")
        with self._lock, self.connect() as conn:
            now = utc_now()
            conn.execute("UPDATE accounts SET display_name=?,updated_at=? WHERE id=?", (name, now, account["id"]))
            self.audit(conn, account["id"], "update_profile", object_type="account", object_id=account["id"])
            row = conn.execute("SELECT * FROM accounts WHERE id=?", (account["id"],)).fetchone()
            return self._account_payload(row)

    def list_account_sessions(self, account: dict[str, Any], bearer: str) -> list[dict[str, Any]]:
        current_hash = token_hash(bearer)
        with self.connect() as conn:
            rows = conn.execute(
                "SELECT id,token_hash,client_role,created_at,last_seen_at,expires_at,ip_address,user_agent FROM sessions WHERE account_id=? ORDER BY last_seen_at DESC",
                (account["id"],),
            ).fetchall()
            return [
                {
                    "id": r["id"],
                    "clientRole": r["client_role"],
                    "createdAt": r["created_at"],
                    "lastSeenAt": r["last_seen_at"],
                    "expiresAt": r["expires_at"],
                    "ipAddress": r["ip_address"],
                    "userAgent": r["user_agent"],
                    "current": hmac.compare_digest(r["token_hash"], current_hash),
                }
                for r in rows
                if r["expires_at"] > unix_now()
            ]

    def revoke_account_session(self, account: dict[str, Any], session_id: str) -> dict[str, Any]:
        with self._lock, self.connect() as conn:
            row = conn.execute("SELECT id FROM sessions WHERE id=? AND account_id=?", (session_id, account["id"])).fetchone()
            if not row:
                raise ApiError(404, "SESSION_NOT_FOUND", "Session was not found.")
            conn.execute("DELETE FROM sessions WHERE id=? AND account_id=?", (session_id, account["id"]))
            self.audit(conn, account["id"], "revoke_session", object_type="session", object_id=session_id)
            return {"ok": True, "sessionId": session_id}

    # ---------- Institution access ----------
    def _membership(self, conn: sqlite3.Connection, account_id: str, institution_id: str, active_only: bool = True) -> sqlite3.Row | None:
        sql = "SELECT * FROM institution_memberships WHERE institution_id=? AND account_id=?"
        params: list[Any] = [institution_id, account_id]
        if active_only:
            sql += " AND status='active'"
        return conn.execute(sql, params).fetchone()

    def _require_membership(self, conn: sqlite3.Connection, account: dict[str, Any], institution_id: str, roles: set[str] | None = None) -> sqlite3.Row:
        if account["role"] != "teacher":
            raise ApiError(403, "TEACHER_REQUIRED", "Teacher account is required.")
        row = self._membership(conn, account["id"], institution_id)
        if not row:
            raise ApiError(403, "INSTITUTION_FORBIDDEN", "You do not have access to this institution.")
        if roles is not None and row["role"] not in roles:
            raise ApiError(403, "INSTITUTION_ROLE_FORBIDDEN", "Your institution role does not allow this operation.")
        return row

    def list_teacher_institutions(self, teacher: dict[str, Any]) -> list[dict[str, Any]]:
        with self.connect() as conn:
            rows = conn.execute(
                """
                SELECT i.id,i.name,i.code,i.status,m.role,m.status AS membership_status,
                       (SELECT COUNT(*) FROM classes c WHERE c.institution_id=i.id AND c.status='active') AS class_count,
                       (SELECT COUNT(*) FROM students s WHERE s.institution_id=i.id AND s.status='active') AS student_count
                FROM institution_memberships m JOIN institutions i ON i.id=m.institution_id
                WHERE m.account_id=? AND m.status='active' AND i.status='active'
                ORDER BY i.name COLLATE NOCASE
                """,
                (teacher["id"],),
            ).fetchall()
            return [{"id": r["id"], "name": r["name"], "code": r["code"], "role": r["role"], "classCount": r["class_count"], "studentCount": r["student_count"]} for r in rows]

    def create_institution(self, teacher: dict[str, Any], name: str) -> dict[str, Any]:
        name = clean_text(name, 120)
        if not name:
            raise ApiError(400, "INSTITUTION_NAME_REQUIRED", "Institution name is required.")
        institution_id = str(uuid.uuid4())
        now = utc_now()
        with self._lock, self.connect() as conn:
            conn.execute("BEGIN IMMEDIATE")
            code = human_code("SCH", 6)
            while conn.execute("SELECT 1 FROM institutions WHERE code=?", (code,)).fetchone():
                code = human_code("SCH", 6)
            conn.execute(
                "INSERT INTO institutions(id,name,code,status,created_by,created_at,updated_at) VALUES(?,?,?,'active',?,?,?)",
                (institution_id, name, code, teacher["id"], now, now),
            )
            conn.execute(
                "INSERT INTO institution_memberships(institution_id,account_id,role,status,created_at,updated_at) VALUES(?,?,'owner','active',?,?)",
                (institution_id, teacher["id"], now, now),
            )
            self.audit(conn, teacher["id"], "create_institution", institution_id=institution_id, object_type="institution", object_id=institution_id)
            conn.execute("COMMIT")
            return {"id": institution_id, "name": name, "code": code, "role": "owner", "classCount": 0, "studentCount": 0}

    def request_join(self, teacher: dict[str, Any], school_code: str) -> dict[str, Any]:
        code = clean_text(school_code, 32).upper()
        with self._lock, self.connect() as conn:
            institution = conn.execute("SELECT id,name,code FROM institutions WHERE code=? AND status='active'", (code,)).fetchone()
            if not institution:
                raise ApiError(404, "SCHOOL_CODE_NOT_FOUND", "Institution code was not found.")
            existing = self._membership(conn, teacher["id"], institution["id"], active_only=False)
            if existing and existing["status"] == "active":
                raise ApiError(409, "ALREADY_MEMBER", "You are already a member of this institution.")
            pending = conn.execute(
                "SELECT id FROM teacher_join_requests WHERE institution_id=? AND teacher_account_id=? AND status='pending'",
                (institution["id"], teacher["id"]),
            ).fetchone()
            if pending:
                return {"id": pending["id"], "institutionId": institution["id"], "institutionName": institution["name"], "status": "pending"}
            request_id = str(uuid.uuid4())
            conn.execute(
                "INSERT INTO teacher_join_requests(id,institution_id,teacher_account_id,status,created_at) VALUES(?,?,?,'pending',?)",
                (request_id, institution["id"], teacher["id"], utc_now()),
            )
            self.audit(conn, teacher["id"], "request_join", institution_id=institution["id"], object_type="join_request", object_id=request_id)
            return {"id": request_id, "institutionId": institution["id"], "institutionName": institution["name"], "status": "pending"}

    def create_teacher_invitation(self, admin: dict[str, Any], institution_id: str, role: str, email: str | None, class_ids: list[str]) -> dict[str, Any]:
        if role not in {"teacher", "admin"}:
            raise ApiError(400, "MEMBERSHIP_ROLE_INVALID", "Teacher invitation role is invalid.")
        with self._lock, self.connect() as conn:
            self._require_membership(conn, admin, institution_id, {"owner", "admin"})
            valid_classes = {r[0] for r in conn.execute("SELECT id FROM classes WHERE institution_id=? AND status='active'", (institution_id,))}
            if any(cid not in valid_classes for cid in class_ids):
                raise ApiError(400, "CLASS_SCOPE_INVALID", "One or more selected classes do not belong to this institution.")
            token = new_token(24)
            invite_id = str(uuid.uuid4())
            normalized = normalize_email(email) if email else None
            expires = unix_now() + TEACHER_INVITE_TTL_SECONDS
            conn.execute(
                "INSERT INTO teacher_invitations(id,institution_id,token_hash,email,membership_role,class_ids_json,created_by,created_at,expires_at) VALUES(?,?,?,?,?,?,?,?,?)",
                (invite_id, institution_id, token_hash(token), normalized, role, json_dumps(class_ids), admin["id"], utc_now(), expires),
            )
            self.audit(conn, admin["id"], "create_teacher_invite", institution_id=institution_id, object_type="teacher_invitation", object_id=invite_id, detail={"role": role, "classIds": class_ids})
            return {"id": invite_id, "token": token, "role": role, "email": normalized, "classIds": class_ids, "expiresAt": expires}

    def accept_teacher_invitation(self, teacher: dict[str, Any], token: str) -> dict[str, Any]:
        with self._lock, self.connect() as conn:
            conn.execute("BEGIN IMMEDIATE")
            invite = conn.execute("SELECT * FROM teacher_invitations WHERE token_hash=?", (token_hash(token),)).fetchone()
            if not invite or invite["used_at"] or invite["revoked_at"] or invite["expires_at"] <= unix_now():
                conn.execute("ROLLBACK")
                raise ApiError(400, "TEACHER_INVITE_INVALID", "Teacher invitation is invalid, expired, or already used.")
            if invite["email"] and invite["email"] != teacher["email"]:
                conn.execute("ROLLBACK")
                raise ApiError(403, "TEACHER_INVITE_EMAIL_MISMATCH", "Use the email address assigned to this invitation.")
            existing_membership = self._membership(conn, teacher["id"], invite["institution_id"], active_only=False)
            if existing_membership and existing_membership["status"] == "active":
                conn.execute("ROLLBACK")
                raise ApiError(409, "ALREADY_MEMBER", "This teacher is already an active member of the institution.")
            now = utc_now()
            conn.execute(
                """
                INSERT INTO institution_memberships(institution_id,account_id,role,status,created_at,updated_at)
                VALUES(?,?,?,'active',?,?)
                ON CONFLICT(institution_id,account_id) DO UPDATE SET role=excluded.role,status='active',updated_at=excluded.updated_at
                """,
                (invite["institution_id"], teacher["id"], invite["membership_role"], now, now),
            )
            for class_id in json.loads(invite["class_ids_json"]):
                valid = conn.execute("SELECT 1 FROM classes WHERE id=? AND institution_id=?", (class_id, invite["institution_id"])).fetchone()
                if valid:
                    conn.execute(
                        "INSERT OR IGNORE INTO teacher_class_assignments(class_id,teacher_account_id,assigned_by,created_at) VALUES(?,?,?,?)",
                        (class_id, teacher["id"], invite["created_by"], now),
                    )
            conn.execute("UPDATE teacher_invitations SET used_by=?,used_at=? WHERE id=?", (teacher["id"], now, invite["id"]))
            self.audit(conn, teacher["id"], "accept_teacher_invite", institution_id=invite["institution_id"], object_type="teacher_invitation", object_id=invite["id"])
            conn.execute("COMMIT")
            return {"institutionId": invite["institution_id"], "role": invite["membership_role"]}

    def approve_join_request(self, admin: dict[str, Any], institution_id: str, request_id: str) -> dict[str, Any]:
        with self._lock, self.connect() as conn:
            self._require_membership(conn, admin, institution_id, {"owner", "admin"})
            conn.execute("BEGIN IMMEDIATE")
            req = conn.execute("SELECT * FROM teacher_join_requests WHERE id=? AND institution_id=? AND status='pending'", (request_id, institution_id)).fetchone()
            if not req:
                conn.execute("ROLLBACK")
                raise ApiError(404, "JOIN_REQUEST_NOT_FOUND", "Pending teacher join request was not found.")
            now = utc_now()
            conn.execute(
                """
                INSERT INTO institution_memberships(institution_id,account_id,role,status,created_at,updated_at)
                VALUES(?,?,'teacher','active',?,?)
                ON CONFLICT(institution_id,account_id) DO UPDATE SET role='teacher',status='active',updated_at=excluded.updated_at
                """,
                (institution_id, req["teacher_account_id"], now, now),
            )
            conn.execute("UPDATE teacher_join_requests SET status='approved',decided_at=?,decided_by=? WHERE id=?", (now, admin["id"], request_id))
            self.audit(conn, admin["id"], "approve_join_request", institution_id=institution_id, object_type="join_request", object_id=request_id)
            conn.execute("COMMIT")
            return {"id": request_id, "status": "approved", "teacherAccountId": req["teacher_account_id"]}

    # ---------- Classes / students / staff ----------

    def update_institution(self, admin: dict[str, Any], institution_id: str, data: dict[str, Any]) -> dict[str, Any]:
        with self._lock, self.connect() as conn:
            membership = self._require_membership(conn, admin, institution_id, {"owner", "admin"})
            name = clean_text(data.get("name"), 120)
            if not name:
                raise ApiError(400, "INSTITUTION_NAME_REQUIRED", "Institution name is required.")
            now = utc_now()
            conn.execute("UPDATE institutions SET name=?,updated_at=? WHERE id=?", (name, now, institution_id))
            self.audit(conn, admin["id"], "update_institution", institution_id=institution_id, object_type="institution", object_id=institution_id, detail={"name": name})
            row = conn.execute("SELECT id,name,code FROM institutions WHERE id=?", (institution_id,)).fetchone()
            return {"id": row["id"], "name": row["name"], "code": row["code"], "role": membership["role"]}

    def reject_join_request(self, admin: dict[str, Any], institution_id: str, request_id: str) -> dict[str, Any]:
        with self._lock, self.connect() as conn:
            self._require_membership(conn, admin, institution_id, {"owner", "admin"})
            req = conn.execute(
                "SELECT * FROM teacher_join_requests WHERE id=? AND institution_id=? AND status='pending'",
                (request_id, institution_id),
            ).fetchone()
            if not req:
                raise ApiError(404, "JOIN_REQUEST_NOT_FOUND", "Pending teacher join request was not found.")
            now = utc_now()
            conn.execute("UPDATE teacher_join_requests SET status='rejected',decided_at=?,decided_by=? WHERE id=?", (now, admin["id"], request_id))
            self.audit(conn, admin["id"], "reject_join_request", institution_id=institution_id, object_type="join_request", object_id=request_id)
            return {"id": request_id, "status": "rejected", "teacherAccountId": req["teacher_account_id"]}

    def update_membership(self, admin: dict[str, Any], institution_id: str, account_id: str, data: dict[str, Any]) -> dict[str, Any]:
        with self._lock, self.connect() as conn:
            actor_membership = self._require_membership(conn, admin, institution_id, {"owner", "admin"})
            target = self._membership(conn, account_id, institution_id, active_only=False)
            if not target:
                raise ApiError(404, "MEMBERSHIP_NOT_FOUND", "Institution membership was not found.")
            if target["role"] == "owner":
                raise ApiError(409, "OWNER_ROLE_IMMUTABLE", "Ownership cannot be changed from staff management.")
            if account_id == admin["id"] and clean_text(data.get("status"), 20) == "disabled":
                raise ApiError(409, "SELF_DISABLE_FORBIDDEN", "You cannot disable your own institution membership.")
            if actor_membership["role"] != "owner" and target["role"] == "admin":
                raise ApiError(403, "OWNER_REQUIRED_FOR_ADMIN", "Only the institution owner can change an admin account.")
            role = clean_text(data.get("role", target["role"]), 20)
            status = clean_text(data.get("status", target["status"]), 20)
            if role not in {"admin", "teacher"}:
                raise ApiError(400, "MEMBERSHIP_ROLE_INVALID", "Membership role must be admin or teacher.")
            if status not in {"active", "disabled"}:
                raise ApiError(400, "MEMBERSHIP_STATUS_INVALID", "Membership status must be active or disabled.")
            if actor_membership["role"] != "owner" and role == "admin":
                raise ApiError(403, "OWNER_REQUIRED_FOR_ADMIN", "Only the institution owner can grant admin role.")
            now = utc_now()
            conn.execute(
                "UPDATE institution_memberships SET role=?,status=?,updated_at=? WHERE institution_id=? AND account_id=?",
                (role, status, now, institution_id, account_id),
            )
            self.audit(conn, admin["id"], "update_membership", institution_id=institution_id, object_type="membership", object_id=account_id, detail={"role": role, "status": status})
            return {"accountId": account_id, "role": role, "status": status}

    def revoke_teacher_invitation(self, admin: dict[str, Any], institution_id: str, invitation_id: str) -> dict[str, Any]:
        with self._lock, self.connect() as conn:
            self._require_membership(conn, admin, institution_id, {"owner", "admin"})
            row = conn.execute("SELECT id,used_at,revoked_at FROM teacher_invitations WHERE id=? AND institution_id=?", (invitation_id, institution_id)).fetchone()
            if not row:
                raise ApiError(404, "INVITATION_NOT_FOUND", "Teacher invitation was not found.")
            if row["used_at"]:
                raise ApiError(409, "INVITATION_ALREADY_USED", "Used invitations cannot be revoked.")
            if not row["revoked_at"]:
                now = utc_now()
                conn.execute("UPDATE teacher_invitations SET revoked_at=?,revoked_by=? WHERE id=?", (now, admin["id"], invitation_id))
                self.audit(conn, admin["id"], "revoke_teacher_invite", institution_id=institution_id, object_type="teacher_invitation", object_id=invitation_id)
            return {"ok": True, "id": invitation_id}

    def create_class(self, admin: dict[str, Any], institution_id: str, data: dict[str, Any]) -> dict[str, Any]:
        name = clean_text(data.get("name"), 120)
        if not name:
            raise ApiError(400, "CLASS_NAME_REQUIRED", "Class name is required.")
        grade = clean_text(data.get("gradeLabel"), 80)
        term = clean_text(data.get("termLabel"), 80)
        with self._lock, self.connect() as conn:
            self._require_membership(conn, admin, institution_id, {"owner", "admin"})
            code = clean_text(data.get("code"), 24).upper() or human_code("CLS", 5)
            if conn.execute("SELECT 1 FROM classes WHERE institution_id=? AND code=?", (institution_id, code)).fetchone():
                raise ApiError(409, "CLASS_CODE_EXISTS", "This class code is already used in the institution.")
            class_id = str(uuid.uuid4())
            now = utc_now()
            conn.execute(
                "INSERT INTO classes(id,institution_id,name,code,grade_label,term_label,status,created_at,updated_at) VALUES(?,?,?,?,?,?,'active',?,?)",
                (class_id, institution_id, name, code, grade, term, now, now),
            )
            self.audit(conn, admin["id"], "create_class", institution_id=institution_id, object_type="class", object_id=class_id)
            return self._class_payload(conn, class_id)

    def create_student(self, admin: dict[str, Any], institution_id: str, data: dict[str, Any]) -> dict[str, Any]:
        fields = {
            "student_code": clean_text(data.get("studentCode"), 64),
            "first_name": clean_text(data.get("firstName"), 80),
            "last_name": clean_text(data.get("lastName"), 80),
            "preferred_name": clean_text(data.get("preferredName"), 80),
            "chinese_name": clean_text(data.get("chineseName"), 80),
        }
        student_id = str(uuid.uuid4())
        now = utc_now()
        with self._lock, self.connect() as conn:
            self._require_membership(conn, admin, institution_id, {"owner", "admin"})
            class_ids = list(dict.fromkeys(str(x) for x in data.get("classIds", []) if isinstance(x, (str, int))))
            valid = {r[0] for r in conn.execute("SELECT id FROM classes WHERE institution_id=? AND status='active'", (institution_id,))}
            if any(cid not in valid for cid in class_ids):
                raise ApiError(400, "CLASS_SCOPE_INVALID", "One or more selected classes are invalid.")
            conn.execute("BEGIN IMMEDIATE")
            try:
                conn.execute(
                    "INSERT INTO students(id,institution_id,student_code,first_name,last_name,preferred_name,chinese_name,status,created_at,updated_at) VALUES(?,?,?,?,?,?,?,'active',?,?)",
                    (student_id, institution_id, fields["student_code"], fields["first_name"], fields["last_name"], fields["preferred_name"], fields["chinese_name"], now, now),
                )
                for cid in class_ids:
                    conn.execute("INSERT INTO class_students(class_id,student_id,created_at) VALUES(?,?,?)", (cid, student_id, now))
                self.audit(conn, admin["id"], "create_student", institution_id=institution_id, object_type="student", object_id=student_id, detail={"classIds": class_ids})
                conn.execute("COMMIT")
            except Exception:
                conn.execute("ROLLBACK")
                raise
            return self._student_payload(conn, student_id)


    def update_class(self, admin: dict[str, Any], institution_id: str, class_id: str, data: dict[str, Any]) -> dict[str, Any]:
        with self._lock, self.connect() as conn:
            self._require_membership(conn, admin, institution_id, {"owner", "admin"})
            row = conn.execute("SELECT * FROM classes WHERE id=? AND institution_id=?", (class_id, institution_id)).fetchone()
            if not row:
                raise ApiError(404, "CLASS_NOT_FOUND", "Class was not found.")
            name = clean_text(data.get("name", row["name"]), 120)
            code = clean_text(data.get("code", row["code"]), 40).upper()
            grade = clean_text(data.get("gradeLabel", row["grade_label"]), 80)
            term = clean_text(data.get("termLabel", row["term_label"]), 80)
            status = clean_text(data.get("status", row["status"]), 20)
            if not name:
                raise ApiError(400, "CLASS_NAME_REQUIRED", "Class name is required.")
            if not code:
                raise ApiError(400, "CLASS_CODE_REQUIRED", "Class code is required.")
            if status not in {"active", "archived"}:
                raise ApiError(400, "CLASS_STATUS_INVALID", "Class status is invalid.")
            try:
                conn.execute(
                    "UPDATE classes SET name=?,code=?,grade_label=?,term_label=?,status=?,updated_at=? WHERE id=? AND institution_id=?",
                    (name, code, grade, term, status, utc_now(), class_id, institution_id),
                )
            except sqlite3.IntegrityError as exc:
                raise ApiError(409, "CLASS_CODE_EXISTS", "Another class already uses this code.") from exc
            self.audit(conn, admin["id"], "update_class", institution_id=institution_id, object_type="class", object_id=class_id, detail={"status": status})
            return self._class_payload(conn, class_id)

    def update_student(self, admin: dict[str, Any], institution_id: str, student_id: str, data: dict[str, Any]) -> dict[str, Any]:
        with self._lock, self.connect() as conn:
            self._require_membership(conn, admin, institution_id, {"owner", "admin"})
            row = conn.execute("SELECT * FROM students WHERE id=? AND institution_id=?", (student_id, institution_id)).fetchone()
            if not row:
                raise ApiError(404, "STUDENT_NOT_FOUND", "Student was not found.")
            values = {
                "student_code": clean_text(data.get("studentCode", row["student_code"]), 64),
                "first_name": clean_text(data.get("firstName", row["first_name"]), 80),
                "last_name": clean_text(data.get("lastName", row["last_name"]), 80),
                "preferred_name": clean_text(data.get("preferredName", row["preferred_name"]), 80),
                "chinese_name": clean_text(data.get("chineseName", row["chinese_name"]), 80),
            }
            status = clean_text(data.get("status", row["status"]), 20)
            if status not in {"active", "archived"}:
                raise ApiError(400, "STUDENT_STATUS_INVALID", "Student status is invalid.")
            class_ids_raw = data.get("classIds")
            class_ids: list[str] | None = None
            if class_ids_raw is not None:
                if not isinstance(class_ids_raw, list):
                    raise ApiError(400, "CLASS_IDS_INVALID", "classIds must be an array.")
                class_ids = list(dict.fromkeys(clean_text(x, 80) for x in class_ids_raw if clean_text(x, 80)))
                valid = {r[0] for r in conn.execute("SELECT id FROM classes WHERE institution_id=? AND status='active'", (institution_id,))}
                if any(cid not in valid for cid in class_ids):
                    raise ApiError(400, "CLASS_SCOPE_INVALID", "One or more selected classes are invalid.")
            conn.execute("BEGIN IMMEDIATE")
            try:
                conn.execute(
                    "UPDATE students SET student_code=?,first_name=?,last_name=?,preferred_name=?,chinese_name=?,status=?,updated_at=? WHERE id=? AND institution_id=?",
                    (values["student_code"], values["first_name"], values["last_name"], values["preferred_name"], values["chinese_name"], status, utc_now(), student_id, institution_id),
                )
                if class_ids is not None:
                    conn.execute("DELETE FROM class_students WHERE student_id=? AND class_id IN (SELECT id FROM classes WHERE institution_id=?)", (student_id, institution_id))
                    for cid in class_ids:
                        conn.execute("INSERT INTO class_students(class_id,student_id,created_at) VALUES(?,?,?)", (cid, student_id, utc_now()))
                self.audit(conn, admin["id"], "update_student", institution_id=institution_id, object_type="student", object_id=student_id, detail={"status": status, "classIds": class_ids})
                conn.execute("COMMIT")
            except Exception:
                conn.execute("ROLLBACK")
                raise
            return self._student_payload(conn, student_id)

    def add_student_to_class(self, admin: dict[str, Any], institution_id: str, class_id: str, student_id: str) -> dict[str, Any]:
        with self._lock, self.connect() as conn:
            self._require_membership(conn, admin, institution_id, {"owner", "admin"})
            klass = conn.execute("SELECT 1 FROM classes WHERE id=? AND institution_id=? AND status='active'", (class_id, institution_id)).fetchone()
            student = conn.execute("SELECT 1 FROM students WHERE id=? AND institution_id=? AND status='active'", (student_id, institution_id)).fetchone()
            if not klass or not student:
                raise ApiError(404, "CLASS_OR_STUDENT_NOT_FOUND", "Class or student was not found in this institution.")
            conn.execute("INSERT OR IGNORE INTO class_students(class_id,student_id,created_at) VALUES(?,?,?)", (class_id, student_id, utc_now()))
            self.audit(conn, admin["id"], "add_student_to_class", institution_id=institution_id, object_type="class", object_id=class_id, detail={"studentId": student_id})
            return {"ok": True}

    def remove_student_from_class(self, admin: dict[str, Any], institution_id: str, class_id: str, student_id: str) -> dict[str, Any]:
        with self._lock, self.connect() as conn:
            self._require_membership(conn, admin, institution_id, {"owner", "admin"})
            conn.execute("DELETE FROM class_students WHERE class_id=? AND student_id=? AND class_id IN (SELECT id FROM classes WHERE institution_id=?)", (class_id, student_id, institution_id))
            self.audit(conn, admin["id"], "remove_student_from_class", institution_id=institution_id, object_type="class", object_id=class_id, detail={"studentId": student_id})
            return {"ok": True}

    def assign_teacher(self, admin: dict[str, Any], institution_id: str, class_id: str, teacher_account_id: str) -> dict[str, Any]:
        with self._lock, self.connect() as conn:
            self._require_membership(conn, admin, institution_id, {"owner", "admin"})
            membership = self._membership(conn, teacher_account_id, institution_id)
            if not membership or membership["role"] not in {"teacher", "admin", "owner"}:
                raise ApiError(400, "TEACHER_MEMBERSHIP_REQUIRED", "Teacher must be an active member of this institution.")
            if not conn.execute("SELECT 1 FROM classes WHERE id=? AND institution_id=? AND status='active'", (class_id, institution_id)).fetchone():
                raise ApiError(404, "CLASS_NOT_FOUND", "Class was not found.")
            conn.execute(
                "INSERT OR IGNORE INTO teacher_class_assignments(class_id,teacher_account_id,assigned_by,created_at) VALUES(?,?,?,?)",
                (class_id, teacher_account_id, admin["id"], utc_now()),
            )
            self.audit(conn, admin["id"], "assign_teacher", institution_id=institution_id, object_type="class", object_id=class_id, detail={"teacherAccountId": teacher_account_id})
            return {"ok": True}

    def unassign_teacher(self, admin: dict[str, Any], institution_id: str, class_id: str, teacher_account_id: str) -> dict[str, Any]:
        with self._lock, self.connect() as conn:
            self._require_membership(conn, admin, institution_id, {"owner", "admin"})
            conn.execute("DELETE FROM teacher_class_assignments WHERE class_id=? AND teacher_account_id=? AND class_id IN (SELECT id FROM classes WHERE institution_id=?)", (class_id, teacher_account_id, institution_id))
            self.audit(conn, admin["id"], "unassign_teacher", institution_id=institution_id, object_type="class", object_id=class_id, detail={"teacherAccountId": teacher_account_id})
            return {"ok": True}

    def _class_payload(self, conn: sqlite3.Connection, class_id: str) -> dict[str, Any]:
        row = conn.execute("SELECT * FROM classes WHERE id=?", (class_id,)).fetchone()
        if not row:
            raise ApiError(404, "CLASS_NOT_FOUND", "Class was not found.")
        return {
            "id": row["id"], "institutionId": row["institution_id"], "name": row["name"], "code": row["code"],
            "gradeLabel": row["grade_label"], "termLabel": row["term_label"], "status": row["status"],
            "studentIds": [r[0] for r in conn.execute("SELECT student_id FROM class_students WHERE class_id=? ORDER BY student_id", (class_id,))],
            "teacherIds": [r[0] for r in conn.execute("SELECT teacher_account_id FROM teacher_class_assignments WHERE class_id=? ORDER BY teacher_account_id", (class_id,))],
        }

    def _student_payload(self, conn: sqlite3.Connection, student_id: str) -> dict[str, Any]:
        row = conn.execute("SELECT * FROM students WHERE id=?", (student_id,)).fetchone()
        if not row:
            raise ApiError(404, "STUDENT_NOT_FOUND", "Student was not found.")
        institution = conn.execute("SELECT name,code FROM institutions WHERE id=?", (row["institution_id"],)).fetchone()
        classes = conn.execute(
            "SELECT c.id,c.name,c.code,c.grade_label,c.term_label FROM class_students cs JOIN classes c ON c.id=cs.class_id WHERE cs.student_id=? AND c.status='active' ORDER BY c.name",
            (student_id,),
        ).fetchall()
        return {
            "id": row["id"], "institutionId": row["institution_id"], "institutionName": institution["name"] if institution else "",
            "institutionCode": institution["code"] if institution else "", "studentCode": row["student_code"],
            "firstName": row["first_name"], "lastName": row["last_name"], "preferredName": row["preferred_name"], "chineseName": row["chinese_name"],
            "displayName": student_display(row), "status": row["status"],
            "guardianCount": conn.execute("SELECT COUNT(*) FROM guardian_links_v2 WHERE student_id=?", (student_id,)).fetchone()[0],
            "classes": [{"id": c["id"], "name": c["name"], "code": c["code"], "gradeLabel": c["grade_label"], "termLabel": c["term_label"]} for c in classes],
        }


    def teacher_workspace(self, teacher: dict[str, Any], institution_id: str) -> dict[str, Any]:
        with self.connect() as conn:
            membership = self._require_membership(conn, teacher, institution_id)
            institution = conn.execute("SELECT id,name,code,status FROM institutions WHERE id=?", (institution_id,)).fetchone()
            if not institution:
                raise ApiError(404, "INSTITUTION_NOT_FOUND", "Institution was not found.")
            elevated = membership["role"] in {"owner", "admin"}
            if elevated:
                class_rows = conn.execute("SELECT id FROM classes WHERE institution_id=? AND status='active' ORDER BY name", (institution_id,)).fetchall()
                student_rows = conn.execute("SELECT id FROM students WHERE institution_id=? AND status='active' ORDER BY chinese_name,preferred_name,first_name,last_name", (institution_id,)).fetchall()
            else:
                class_rows = conn.execute(
                    "SELECT c.id FROM teacher_class_assignments t JOIN classes c ON c.id=t.class_id WHERE t.teacher_account_id=? AND c.institution_id=? AND c.status='active' ORDER BY c.name",
                    (teacher["id"], institution_id),
                ).fetchall()
                student_rows = conn.execute(
                    """
                    SELECT DISTINCT s.id FROM teacher_class_assignments t
                    JOIN class_students cs ON cs.class_id=t.class_id
                    JOIN students s ON s.id=cs.student_id
                    JOIN classes c ON c.id=t.class_id
                    WHERE t.teacher_account_id=? AND c.institution_id=? AND s.status='active' AND c.status='active'
                    ORDER BY s.chinese_name,s.preferred_name,s.first_name,s.last_name
                    """,
                    (teacher["id"], institution_id),
                ).fetchall()
            classes = [self._class_payload(conn, r["id"]) for r in class_rows]
            students = [self._student_payload(conn, r["id"]) for r in student_rows]
            staff: list[dict[str, Any]] = []
            join_requests: list[dict[str, Any]] = []
            invitations: list[dict[str, Any]] = []
            child_claims: list[dict[str, Any]] = []
            if elevated:
                staff_rows = conn.execute(
                    """
                    SELECT a.id,a.email,a.display_name,m.role,m.status FROM institution_memberships m
                    JOIN accounts a ON a.id=m.account_id WHERE m.institution_id=? ORDER BY m.role,a.display_name COLLATE NOCASE
                    """,
                    (institution_id,),
                ).fetchall()
                for r in staff_rows:
                    class_ids = [x[0] for x in conn.execute(
                        "SELECT class_id FROM teacher_class_assignments WHERE teacher_account_id=? AND class_id IN (SELECT id FROM classes WHERE institution_id=?)",
                        (r["id"], institution_id),
                    )]
                    staff.append({"id": r["id"], "email": r["email"], "displayName": r["display_name"], "role": r["role"], "status": r["status"], "classIds": class_ids})
                for r in conn.execute(
                    """
                    SELECT j.id,j.teacher_account_id,j.created_at,a.display_name,a.email FROM teacher_join_requests j
                    JOIN accounts a ON a.id=j.teacher_account_id
                    WHERE j.institution_id=? AND j.status='pending' ORDER BY j.created_at
                    """,
                    (institution_id,),
                ):
                    join_requests.append({"id": r["id"], "teacherAccountId": r["teacher_account_id"], "displayName": r["display_name"], "email": r["email"], "createdAt": r["created_at"]})
                for r in conn.execute(
                    "SELECT id,email,membership_role,class_ids_json,created_at,expires_at,used_at,revoked_at FROM teacher_invitations WHERE institution_id=? ORDER BY created_at DESC LIMIT 100",
                    (institution_id,),
                ):
                    invitations.append({
                        "id": r["id"], "email": r["email"], "role": r["membership_role"], "classIds": json.loads(r["class_ids_json"]),
                        "createdAt": r["created_at"], "expiresAt": r["expires_at"], "usedAt": r["used_at"], "revokedAt": r["revoked_at"],
                    })
                for r in conn.execute(
                    """
                    SELECT cc.id,cc.student_id,cc.created_at,cc.expires_at,cc.used_at,cc.revoked_at
                    FROM child_claims cc JOIN students s ON s.id=cc.student_id
                    WHERE s.institution_id=? ORDER BY cc.created_at DESC LIMIT 200
                    """,
                    (institution_id,),
                ):
                    child_claims.append({
                        "id": r["id"], "studentId": r["student_id"], "createdAt": r["created_at"],
                        "expiresAt": r["expires_at"], "usedAt": r["used_at"], "revokedAt": r["revoked_at"],
                    })
            evidence = self._teacher_evidence(conn, teacher, institution_id, classes, elevated)
            sessions = self._session_summaries(conn, teacher, institution_id, None, limit=100)
            actions = self._teacher_parent_actions(conn, teacher, institution_id, classes, elevated)
            return {
                "revision": self._revision(conn),
                "institution": {"id": institution["id"], "name": institution["name"], "code": institution["code"], "role": membership["role"]},
                "canManage": elevated,
                "classes": classes,
                "students": students,
                "staff": staff,
                "joinRequests": join_requests,
                "invitations": invitations,
                "childClaims": child_claims,
                "evidence": evidence,
                "sessions": sessions,
                "parentActions": actions,
            }

    def _teacher_evidence(self, conn: sqlite3.Connection, teacher: dict[str, Any], institution_id: str, classes: list[dict[str, Any]], elevated: bool) -> list[dict[str, Any]]:
        if elevated:
            rows = conn.execute("SELECT * FROM growth_evidence WHERE institution_id=? ORDER BY evidence_date DESC,updated_at DESC LIMIT 500", (institution_id,)).fetchall()
        else:
            allowed_class_ids = {c["id"] for c in classes}
            if not allowed_class_ids:
                return []
            marks = ",".join("?" for _ in allowed_class_ids)
            rows = conn.execute(f"SELECT * FROM growth_evidence WHERE institution_id=? AND class_id IN ({marks}) ORDER BY evidence_date DESC,updated_at DESC LIMIT 500", (institution_id, *allowed_class_ids)).fetchall()
        return [self._evidence_payload(conn, r) for r in rows]

    def _revision(self, conn: sqlite3.Connection) -> str:
        pieces = []
        for table, field in [
            ("institutions", "updated_at"), ("institution_memberships", "updated_at"), ("classes", "updated_at"),
            ("students", "updated_at"), ("growth_evidence", "updated_at"), ("class_sessions", "updated_at"),
            ("attendance_entries", "updated_at"), ("parent_actions", "updated_at")
        ]:
            row = conn.execute(f"SELECT COALESCE(MAX({field}),'') FROM {table}").fetchone()
            pieces.append(row[0] or "")
        return hashlib.sha256("|".join(pieces).encode("utf-8")).hexdigest()[:16]

    # ---------- Parent child linking ----------
    def create_child_claim(self, admin: dict[str, Any], student_id: str) -> dict[str, Any]:
        with self._lock, self.connect() as conn:
            student = conn.execute("SELECT * FROM students WHERE id=? AND status='active'", (student_id,)).fetchone()
            if not student:
                raise ApiError(404, "STUDENT_NOT_FOUND", "Student was not found.")
            self._require_membership(conn, admin, student["institution_id"], {"owner", "admin"})
            token = human_code("KID", 8)
            while conn.execute("SELECT 1 FROM child_claims WHERE token_hash=?", (token_hash(token),)).fetchone():
                token = human_code("KID", 8)
            claim_id = str(uuid.uuid4())
            expires = unix_now() + CHILD_CLAIM_TTL_SECONDS
            conn.execute(
                "INSERT INTO child_claims(id,student_id,token_hash,created_by,created_at,expires_at) VALUES(?,?,?,?,?,?)",
                (claim_id, student_id, token_hash(token), admin["id"], utc_now(), expires),
            )
            self.audit(conn, admin["id"], "create_child_claim", institution_id=student["institution_id"], object_type="child_claim", object_id=claim_id, detail={"studentId": student_id})
            return {"id": claim_id, "code": token, "studentId": student_id, "expiresAt": expires}

    def claim_child(self, parent: dict[str, Any], code: str) -> dict[str, Any]:
        normalized = clean_text(code, 40).upper()
        with self._lock, self.connect() as conn:
            conn.execute("BEGIN IMMEDIATE")
            claim = conn.execute("SELECT * FROM child_claims WHERE token_hash=?", (token_hash(normalized),)).fetchone()
            if not claim or claim["used_at"] or claim["revoked_at"] or claim["expires_at"] <= unix_now():
                conn.execute("ROLLBACK")
                raise ApiError(400, "CHILD_CODE_INVALID", "Child link code is invalid, expired, or already used.")
            student = conn.execute("SELECT * FROM students WHERE id=? AND status='active'", (claim["student_id"],)).fetchone()
            if not student:
                conn.execute("ROLLBACK")
                raise ApiError(404, "STUDENT_NOT_FOUND", "Student linked to this code is unavailable.")
            now = utc_now()
            conn.execute("INSERT OR IGNORE INTO guardian_links_v2(parent_account_id,student_id,relationship,created_at) VALUES(?,?,'guardian',?)", (parent["id"], student["id"], now))
            conn.execute("UPDATE child_claims SET used_by=?,used_at=? WHERE id=?", (parent["id"], now, claim["id"]))
            self.audit(conn, parent["id"], "claim_child", institution_id=student["institution_id"], object_type="student", object_id=student["id"])
            conn.execute("COMMIT")
            return self._student_payload(conn, student["id"])


    def revoke_child_claim(self, admin: dict[str, Any], student_id: str, claim_id: str) -> dict[str, Any]:
        with self._lock, self.connect() as conn:
            student = conn.execute("SELECT * FROM students WHERE id=?", (student_id,)).fetchone()
            if not student:
                raise ApiError(404, "STUDENT_NOT_FOUND", "Student was not found.")
            self._require_membership(conn, admin, student["institution_id"], {"owner", "admin"})
            claim = conn.execute("SELECT * FROM child_claims WHERE id=? AND student_id=?", (claim_id, student_id)).fetchone()
            if not claim:
                raise ApiError(404, "CHILD_CLAIM_NOT_FOUND", "Child claim was not found.")
            if claim["used_at"]:
                raise ApiError(409, "CHILD_CLAIM_ALREADY_USED", "Used child claim codes cannot be revoked.")
            if not claim["revoked_at"]:
                now = utc_now()
                conn.execute("UPDATE child_claims SET revoked_at=?,revoked_by=? WHERE id=?", (now, admin["id"], claim_id))
                self.audit(conn, admin["id"], "revoke_child_claim", institution_id=student["institution_id"], object_type="child_claim", object_id=claim_id, detail={"studentId": student_id})
            return {"ok": True, "id": claim_id}

    def unlink_child(self, parent: dict[str, Any], student_id: str) -> dict[str, Any]:
        with self._lock, self.connect() as conn:
            row = conn.execute("SELECT 1 FROM guardian_links_v2 WHERE parent_account_id=? AND student_id=?", (parent["id"], student_id)).fetchone()
            if not row:
                raise ApiError(404, "CHILD_LINK_NOT_FOUND", "This child is not linked to your account.")
            institution = conn.execute("SELECT institution_id FROM students WHERE id=?", (student_id,)).fetchone()
            conn.execute("DELETE FROM guardian_links_v2 WHERE parent_account_id=? AND student_id=?", (parent["id"], student_id))
            self.audit(conn, parent["id"], "unlink_child", institution_id=institution["institution_id"] if institution else None, object_type="student", object_id=student_id)
            return {"ok": True}

    def parent_children(self, parent: dict[str, Any]) -> dict[str, Any]:
        with self.connect() as conn:
            rows = conn.execute(
                "SELECT s.id FROM guardian_links_v2 g JOIN students s ON s.id=g.student_id WHERE g.parent_account_id=? AND s.status='active' ORDER BY s.chinese_name,s.preferred_name,s.first_name,s.last_name",
                (parent["id"],),
            ).fetchall()
            return {"revision": self._revision(conn), "children": [self._student_payload(conn, r["id"]) for r in rows]}


    def parent_child_detail(self, parent: dict[str, Any], student_id: str) -> dict[str, Any]:
        with self.connect() as conn:
            allowed = conn.execute("SELECT 1 FROM guardian_links_v2 WHERE parent_account_id=? AND student_id=?", (parent["id"], student_id)).fetchone()
            if not allowed:
                raise ApiError(403, "CHILD_SCOPE_FORBIDDEN", "This child is not linked to your parent account.")
            child = self._student_payload(conn, student_id)
            evidence_rows = conn.execute(
                "SELECT * FROM growth_evidence WHERE student_id=? AND publish_state='published' AND visibility IN ('parent_visible','report') ORDER BY evidence_date DESC,updated_at DESC LIMIT 200",
                (student_id,),
            ).fetchall()
            attendance_rows = conn.execute(
                """
                SELECT cs.id AS session_id,cs.session_date,c.id AS class_id,c.name AS class_name,cs.topic,
                       a.status,a.participation,a.confidence,a.homework,a.note
                FROM attendance_entries a JOIN class_sessions cs ON cs.id=a.session_id JOIN classes c ON c.id=cs.class_id
                WHERE a.student_id=? ORDER BY cs.session_date DESC LIMIT 200
                """,
                (student_id,),
            ).fetchall()
            counts = {"present": 0, "late": 0, "absent": 0, "excused": 0}
            attendance = []
            for r in attendance_rows:
                counts[r["status"]] = counts.get(r["status"], 0) + 1
                attendance.append({
                    "sessionId": r["session_id"], "date": r["session_date"], "classId": r["class_id"],
                    "className": r["class_name"], "topic": r["topic"], "status": r["status"],
                    "participation": r["participation"], "confidence": r["confidence"],
                    "homework": r["homework"], "note": r["note"],
                })
            total_counted = counts["present"] + counts["late"] + counts["absent"]
            attendance_rate = round(((counts["present"] + counts["late"]) / total_counted) * 100, 1) if total_counted else None
            evidence_payload = [self._evidence_payload(conn, r) for r in evidence_rows]
            dimensions = {key: {"count": 0, "latestDate": None} for key in ["language", "knowledge", "participation", "confidence", "habits", "independence"]}
            for item in evidence_payload:
                for key in item["dimensions"]:
                    if key in dimensions:
                        dimensions[key]["count"] += 1
                        latest = dimensions[key]["latestDate"]
                        if latest is None or item["date"] > latest:
                            dimensions[key]["latestDate"] = item["date"]
            actions = self._parent_actions_for_student(conn, student_id)
            return {
                "revision": self._revision(conn),
                "child": child,
                "evidence": evidence_payload,
                "milestones": [item for item in evidence_payload if item["kind"] == "milestone"],
                "growthSummary": dimensions,
                "parentActions": actions,
                "attendance": attendance,
                "attendanceSummary": {"counts": counts, "rate": attendance_rate},
            }

    def _teacher_can_access_class(self, conn: sqlite3.Connection, teacher: dict[str, Any], institution_id: str, class_id: str) -> bool:
        membership = self._membership(conn, teacher["id"], institution_id)
        if not membership:
            return False
        if membership["role"] in {"owner", "admin"}:
            return bool(conn.execute("SELECT 1 FROM classes WHERE id=? AND institution_id=? AND status='active'", (class_id, institution_id)).fetchone())
        return bool(conn.execute(
            "SELECT 1 FROM teacher_class_assignments t JOIN classes c ON c.id=t.class_id WHERE t.teacher_account_id=? AND t.class_id=? AND c.institution_id=? AND c.status='active'",
            (teacher["id"], class_id, institution_id),
        ).fetchone())


    def add_evidence(self, teacher: dict[str, Any], data: dict[str, Any]) -> dict[str, Any]:
        institution_id = clean_text(data.get("institutionId"), 80)
        class_id = clean_text(data.get("classId"), 80)
        student_id = clean_text(data.get("studentId"), 80)
        observation = clean_text(data.get("observation"), 4000)
        interpretation = clean_text(data.get("interpretation"), 4000)
        if not observation:
            raise ApiError(400, "OBSERVATION_REQUIRED", "Observation is required.")
        evidence_date = clean_text(data.get("date"), 20) or date.today().isoformat()
        try:
            datetime.strptime(evidence_date, "%Y-%m-%d")
        except ValueError as exc:
            raise ApiError(400, "DATE_INVALID", "Evidence date must use YYYY-MM-DD.") from exc
        kind = clean_text(data.get("kind"), 30) or "observation"
        if kind not in {"observation", "assessment", "attendance", "homework", "milestone"}:
            raise ApiError(400, "EVIDENCE_KIND_INVALID", "Evidence kind is invalid.")
        visibility = clean_text(data.get("visibility"), 40) or "teacher_only"
        if visibility not in {"teacher_only", "parent_visible", "report"}:
            raise ApiError(400, "VISIBILITY_INVALID", "Visibility is invalid.")
        publish_state = clean_text(data.get("publishState"), 40) or "draft"
        if publish_state not in {"draft", "ready", "published"}:
            raise ApiError(400, "PUBLISH_STATE_INVALID", "Publish state is invalid.")
        allowed_dimensions = {"language", "knowledge", "participation", "confidence", "habits", "independence"}
        dimensions = list(dict.fromkeys(str(x) for x in data.get("dimensions", []) if str(x) in allowed_dimensions))
        with self._lock, self.connect() as conn:
            if not self._teacher_can_access_class(conn, teacher, institution_id, class_id):
                raise ApiError(403, "CLASS_ACCESS_FORBIDDEN", "You do not have access to this class.")
            if not conn.execute("SELECT 1 FROM class_students WHERE class_id=? AND student_id=?", (class_id, student_id)).fetchone():
                raise ApiError(400, "STUDENT_NOT_IN_CLASS", "Student is not enrolled in the selected class.")
            evidence_id = str(uuid.uuid4())
            now = utc_now()
            conn.execute(
                "INSERT INTO growth_evidence(id,institution_id,class_id,student_id,teacher_account_id,evidence_date,kind,observation,interpretation,dimensions_json,visibility,publish_state,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                (evidence_id, institution_id, class_id, student_id, teacher["id"], evidence_date, kind, observation, interpretation, json_dumps(dimensions), visibility, publish_state, now, now),
            )
            self.audit(conn, teacher["id"], "add_evidence", institution_id=institution_id, object_type="evidence", object_id=evidence_id, detail={"classId": class_id, "studentId": student_id, "kind": kind})
            row = conn.execute("SELECT * FROM growth_evidence WHERE id=?", (evidence_id,)).fetchone()
            return self._evidence_payload(conn, row)


    def update_evidence(self, teacher: dict[str, Any], evidence_id: str, data: dict[str, Any]) -> dict[str, Any]:
        with self._lock, self.connect() as conn:
            row = conn.execute("SELECT * FROM growth_evidence WHERE id=?", (evidence_id,)).fetchone()
            if not row:
                raise ApiError(404, "EVIDENCE_NOT_FOUND", "Evidence record was not found.")
            if not self._teacher_can_access_class(conn, teacher, row["institution_id"], row["class_id"]):
                raise ApiError(403, "EVIDENCE_FORBIDDEN", "You do not have access to this evidence record.")
            membership = self._membership(conn, teacher["id"], row["institution_id"])
            if membership and membership["role"] == "teacher" and row["teacher_account_id"] != teacher["id"]:
                raise ApiError(403, "EVIDENCE_OWNER_REQUIRED", "Teachers can edit only evidence they created. Institution owners/admins can manage institution evidence.")
            visibility = clean_text(data.get("visibility", row["visibility"]), 40)
            publish_state = clean_text(data.get("publishState", row["publish_state"]), 40)
            kind = clean_text(data.get("kind", row["kind"]), 30)
            evidence_date = clean_text(data.get("date", row["evidence_date"]), 20)
            observation = clean_text(data.get("observation", row["observation"]), 4000)
            interpretation = clean_text(data.get("interpretation", row["interpretation"]), 4000)
            allowed_dimensions = {"language", "knowledge", "participation", "confidence", "habits", "independence"}
            dimensions_raw = data.get("dimensions", json.loads(row["dimensions_json"]))
            if not isinstance(dimensions_raw, list):
                raise ApiError(400, "DIMENSIONS_INVALID", "Dimensions must be an array.")
            dimensions = list(dict.fromkeys(str(x) for x in dimensions_raw if str(x) in allowed_dimensions))
            if visibility not in {"teacher_only", "parent_visible", "report"}:
                raise ApiError(400, "VISIBILITY_INVALID", "Visibility is invalid.")
            if publish_state not in {"draft", "ready", "published"}:
                raise ApiError(400, "PUBLISH_STATE_INVALID", "Publish state is invalid.")
            if kind not in {"observation", "assessment", "attendance", "homework", "milestone"}:
                raise ApiError(400, "EVIDENCE_KIND_INVALID", "Evidence kind is invalid.")
            try:
                datetime.strptime(evidence_date, "%Y-%m-%d")
            except ValueError as exc:
                raise ApiError(400, "DATE_INVALID", "Evidence date must use YYYY-MM-DD.") from exc
            if not observation:
                raise ApiError(400, "OBSERVATION_REQUIRED", "Observation is required.")
            now = utc_now()
            conn.execute(
                "UPDATE growth_evidence SET evidence_date=?,kind=?,observation=?,interpretation=?,dimensions_json=?,visibility=?,publish_state=?,updated_at=? WHERE id=?",
                (evidence_date, kind, observation, interpretation, json_dumps(dimensions), visibility, publish_state, now, evidence_id),
            )
            self.audit(conn, teacher["id"], "update_evidence", institution_id=row["institution_id"], object_type="evidence", object_id=evidence_id, detail={"visibility": visibility, "publishState": publish_state, "kind": kind})
            updated = conn.execute("SELECT * FROM growth_evidence WHERE id=?", (evidence_id,)).fetchone()
            return self._evidence_payload(conn, updated)

    def _evidence_payload(self, conn: sqlite3.Connection, row: sqlite3.Row) -> dict[str, Any]:
        teacher = conn.execute("SELECT display_name FROM accounts WHERE id=?", (row["teacher_account_id"],)).fetchone()
        klass = conn.execute("SELECT name FROM classes WHERE id=?", (row["class_id"],)).fetchone() if row["class_id"] else None
        return {
            "id": row["id"], "institutionId": row["institution_id"], "classId": row["class_id"], "className": klass["name"] if klass else "",
            "studentId": row["student_id"], "teacherId": row["teacher_account_id"], "teacherName": teacher["display_name"] if teacher else "Teacher",
            "date": row["evidence_date"], "kind": row["kind"], "observation": row["observation"], "interpretation": row["interpretation"],
            "dimensions": json.loads(row["dimensions_json"]), "visibility": row["visibility"], "publishState": row["publish_state"], "updatedAt": row["updated_at"],
        }


    def _session_summaries(self, conn: sqlite3.Connection, teacher: dict[str, Any], institution_id: str, class_id: str | None, limit: int = 100) -> list[dict[str, Any]]:
        membership = self._require_membership(conn, teacher, institution_id)
        elevated = membership["role"] in {"owner", "admin"}
        params: list[Any] = [institution_id]
        access_sql = ""
        if not elevated:
            access_sql = " AND c.id IN (SELECT class_id FROM teacher_class_assignments WHERE teacher_account_id=?)"
            params.append(teacher["id"])
        if class_id:
            access_sql += " AND c.id=?"
            params.append(class_id)
        params.append(max(1, min(int(limit), 200)))
        rows = conn.execute(
            f"""
            SELECT cs.id,cs.class_id,c.name AS class_name,cs.session_date,cs.topic,cs.updated_at,
                   COUNT(a.student_id) AS row_count,
                   SUM(CASE WHEN a.status='present' THEN 1 ELSE 0 END) AS present_count,
                   SUM(CASE WHEN a.status='late' THEN 1 ELSE 0 END) AS late_count,
                   SUM(CASE WHEN a.status='absent' THEN 1 ELSE 0 END) AS absent_count,
                   SUM(CASE WHEN a.status='excused' THEN 1 ELSE 0 END) AS excused_count
            FROM class_sessions cs JOIN classes c ON c.id=cs.class_id
            LEFT JOIN attendance_entries a ON a.session_id=cs.id
            WHERE c.institution_id=? {access_sql}
            GROUP BY cs.id,c.name
            ORDER BY cs.session_date DESC,cs.updated_at DESC LIMIT ?
            """,
            params,
        ).fetchall()
        return [
            {
                "id": r["id"], "classId": r["class_id"], "className": r["class_name"], "date": r["session_date"],
                "topic": r["topic"], "updatedAt": r["updated_at"], "rowCount": r["row_count"],
                "counts": {
                    "present": r["present_count"] or 0, "late": r["late_count"] or 0,
                    "absent": r["absent_count"] or 0, "excused": r["excused_count"] or 0,
                },
            }
            for r in rows
        ]

    def list_class_sessions(self, teacher: dict[str, Any], institution_id: str, class_id: str | None = None, limit: int = 100) -> list[dict[str, Any]]:
        with self.connect() as conn:
            return self._session_summaries(conn, teacher, institution_id, class_id, limit)

    def class_session_detail(self, teacher: dict[str, Any], session_id: str) -> dict[str, Any]:
        with self.connect() as conn:
            session = conn.execute(
                "SELECT cs.*,c.institution_id,c.name AS class_name FROM class_sessions cs JOIN classes c ON c.id=cs.class_id WHERE cs.id=?",
                (session_id,),
            ).fetchone()
            if not session:
                raise ApiError(404, "CLASS_SESSION_NOT_FOUND", "Class session was not found.")
            if not self._teacher_can_access_class(conn, teacher, session["institution_id"], session["class_id"]):
                raise ApiError(403, "CLASS_ACCESS_FORBIDDEN", "You do not have access to this class.")
            rows = conn.execute(
                """
                SELECT s.id AS student_id,s.student_code,s.first_name,s.last_name,s.preferred_name,s.chinese_name,
                       a.status,a.participation,a.confidence,a.homework,a.note
                FROM class_students cs
                JOIN students s ON s.id=cs.student_id
                LEFT JOIN attendance_entries a ON a.session_id=? AND a.student_id=s.id
                WHERE cs.class_id=? AND s.status='active'
                ORDER BY s.chinese_name,s.preferred_name,s.first_name,s.last_name
                """,
                (session_id, session["class_id"]),
            ).fetchall()
            return {
                "id": session["id"], "institutionId": session["institution_id"], "classId": session["class_id"],
                "className": session["class_name"], "date": session["session_date"], "topic": session["topic"],
                "rows": [
                    {
                        "studentId": r["student_id"], "displayName": student_display(r),
                        "status": r["status"] or "present",
                        "participation": r["participation"] if r["participation"] is not None else 3,
                        "confidence": r["confidence"] if r["confidence"] is not None else 3,
                        "homework": r["homework"] or "done", "note": r["note"] or "",
                    }
                    for r in rows
                ],
            }

    def _parent_action_payload(self, conn: sqlite3.Connection, row: sqlite3.Row) -> dict[str, Any]:
        teacher = conn.execute("SELECT display_name FROM accounts WHERE id=?", (row["teacher_account_id"],)).fetchone()
        klass = conn.execute("SELECT name FROM classes WHERE id=?", (row["class_id"],)).fetchone() if row["class_id"] else None
        return {
            "id": row["id"], "institutionId": row["institution_id"], "classId": row["class_id"],
            "className": klass["name"] if klass else "", "studentId": row["student_id"],
            "teacherId": row["teacher_account_id"], "teacherName": teacher["display_name"] if teacher else "Teacher",
            "title": row["title"], "detail": row["detail"], "dueDate": row["due_date"],
            "status": row["status"], "createdAt": row["created_at"], "updatedAt": row["updated_at"],
        }

    def _parent_actions_for_student(self, conn: sqlite3.Connection, student_id: str) -> list[dict[str, Any]]:
        rows = conn.execute(
            "SELECT * FROM parent_actions WHERE student_id=? ORDER BY CASE status WHEN 'open' THEN 0 ELSE 1 END,due_date IS NULL,due_date,updated_at DESC LIMIT 200",
            (student_id,),
        ).fetchall()
        return [self._parent_action_payload(conn, r) for r in rows]

    def _teacher_parent_actions(self, conn: sqlite3.Connection, teacher: dict[str, Any], institution_id: str, classes: list[dict[str, Any]], elevated: bool) -> list[dict[str, Any]]:
        if elevated:
            rows = conn.execute("SELECT * FROM parent_actions WHERE institution_id=? ORDER BY updated_at DESC LIMIT 300", (institution_id,)).fetchall()
        else:
            allowed = {c["id"] for c in classes}
            if not allowed:
                return []
            marks = ",".join("?" for _ in allowed)
            rows = conn.execute(
                f"SELECT * FROM parent_actions WHERE institution_id=? AND class_id IN ({marks}) ORDER BY updated_at DESC LIMIT 300",
                (institution_id, *allowed),
            ).fetchall()
        return [self._parent_action_payload(conn, r) for r in rows]

    def add_parent_action(self, teacher: dict[str, Any], data: dict[str, Any]) -> dict[str, Any]:
        institution_id = clean_text(data.get("institutionId"), 80)
        class_id = clean_text(data.get("classId"), 80)
        student_id = clean_text(data.get("studentId"), 80)
        title = clean_text(data.get("title"), 240)
        detail = clean_text(data.get("detail"), 2000)
        due_date = clean_text(data.get("dueDate"), 20) or None
        if not title:
            raise ApiError(400, "ACTION_TITLE_REQUIRED", "Parent action title is required.")
        if due_date:
            try:
                datetime.strptime(due_date, "%Y-%m-%d")
            except ValueError as exc:
                raise ApiError(400, "DATE_INVALID", "Due date must use YYYY-MM-DD.") from exc
        with self._lock, self.connect() as conn:
            if not self._teacher_can_access_class(conn, teacher, institution_id, class_id):
                raise ApiError(403, "CLASS_ACCESS_FORBIDDEN", "You do not have access to this class.")
            if not conn.execute("SELECT 1 FROM class_students WHERE class_id=? AND student_id=?", (class_id, student_id)).fetchone():
                raise ApiError(400, "STUDENT_NOT_IN_CLASS", "Student is not enrolled in the selected class.")
            action_id = str(uuid.uuid4())
            now = utc_now()
            conn.execute(
                "INSERT INTO parent_actions(id,institution_id,class_id,student_id,teacher_account_id,title,detail,due_date,status,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,'open',?,?)",
                (action_id, institution_id, class_id, student_id, teacher["id"], title, detail, due_date, now, now),
            )
            self.audit(conn, teacher["id"], "create_parent_action", institution_id=institution_id, object_type="parent_action", object_id=action_id, detail={"studentId": student_id})
            row = conn.execute("SELECT * FROM parent_actions WHERE id=?", (action_id,)).fetchone()
            return self._parent_action_payload(conn, row)

    def update_parent_action(self, account: dict[str, Any], action_id: str, data: dict[str, Any]) -> dict[str, Any]:
        with self._lock, self.connect() as conn:
            row = conn.execute("SELECT * FROM parent_actions WHERE id=?", (action_id,)).fetchone()
            if not row:
                raise ApiError(404, "PARENT_ACTION_NOT_FOUND", "Parent action was not found.")
            if account["role"] == "parent":
                allowed = conn.execute("SELECT 1 FROM guardian_links_v2 WHERE parent_account_id=? AND student_id=?", (account["id"], row["student_id"])).fetchone()
                if not allowed:
                    raise ApiError(403, "CHILD_SCOPE_FORBIDDEN", "This action does not belong to a linked child.")
                status = clean_text(data.get("status"), 20)
                if status not in {"open", "done"}:
                    raise ApiError(400, "ACTION_STATUS_INVALID", "Parent can update only the action status.")
                conn.execute("UPDATE parent_actions SET status=?,updated_at=? WHERE id=?", (status, utc_now(), action_id))
                self.audit(conn, account["id"], "update_parent_action_status", institution_id=row["institution_id"], object_type="parent_action", object_id=action_id, detail={"status": status})
            else:
                if not self._teacher_can_access_class(conn, account, row["institution_id"], row["class_id"]):
                    raise ApiError(403, "CLASS_ACCESS_FORBIDDEN", "You do not have access to this action.")
                membership = self._membership(conn, account["id"], row["institution_id"])
                if membership and membership["role"] == "teacher" and row["teacher_account_id"] != account["id"]:
                    raise ApiError(403, "ACTION_OWNER_REQUIRED", "Teachers can edit only actions they created.")
                title = clean_text(data.get("title", row["title"]), 240)
                detail = clean_text(data.get("detail", row["detail"]), 2000)
                due_date = clean_text(data.get("dueDate", row["due_date"]), 20) or None
                status = clean_text(data.get("status", row["status"]), 20)
                if not title:
                    raise ApiError(400, "ACTION_TITLE_REQUIRED", "Parent action title is required.")
                if status not in {"open", "done"}:
                    raise ApiError(400, "ACTION_STATUS_INVALID", "Parent action status is invalid.")
                if due_date:
                    try:
                        datetime.strptime(due_date, "%Y-%m-%d")
                    except ValueError as exc:
                        raise ApiError(400, "DATE_INVALID", "Due date must use YYYY-MM-DD.") from exc
                conn.execute("UPDATE parent_actions SET title=?,detail=?,due_date=?,status=?,updated_at=? WHERE id=?", (title, detail, due_date, status, utc_now(), action_id))
                self.audit(conn, account["id"], "update_parent_action", institution_id=row["institution_id"], object_type="parent_action", object_id=action_id)
            updated = conn.execute("SELECT * FROM parent_actions WHERE id=?", (action_id,)).fetchone()
            return self._parent_action_payload(conn, updated)

    def list_audit_events(self, admin: dict[str, Any], institution_id: str, limit: int = 100) -> list[dict[str, Any]]:
        with self.connect() as conn:
            self._require_membership(conn, admin, institution_id, {"owner", "admin"})
            rows = conn.execute(
                """
                SELECT e.*,a.display_name FROM audit_events_v2 e
                LEFT JOIN accounts a ON a.id=e.account_id
                WHERE e.institution_id=? ORDER BY e.created_at DESC LIMIT ?
                """,
                (institution_id, max(1, min(int(limit), 200))),
            ).fetchall()
            return [
                {
                    "id": r["id"], "accountId": r["account_id"], "actorName": r["display_name"] or "System",
                    "action": r["action"], "objectType": r["object_type"], "objectId": r["object_id"],
                    "detail": json.loads(r["detail_json"] or "{}"), "createdAt": r["created_at"],
                }
                for r in rows
            ]

    def _report_filter(self, period: str) -> tuple[str, list[Any], str]:
        today = date.today()
        if period == "week":
            cutoff = (today - timedelta(days=6)).isoformat()
            return " AND evidence_date>=?", [cutoff], "last_7_calendar_days"
        if period == "month":
            cutoff = today.replace(day=1).isoformat()
            return " AND evidence_date>=?", [cutoff], "current_calendar_month"
        if period in {"term", "all"}:
            return "", [], "current_active_class_membership" if period == "term" else "all_available_history"
        raise ApiError(400, "REPORT_PERIOD_INVALID", "Report period must be week, month, term, or all.")

    def _build_student_report(self, conn: sqlite3.Connection, student_id: str, period: str) -> dict[str, Any]:
        child = self._student_payload(conn, student_id)
        evidence_filter, evidence_args, methodology = self._report_filter(period)
        class_ids = [c["id"] for c in child["classes"]]
        class_clause = ""
        class_args: list[Any] = []
        if period == "term":
            if not class_ids:
                class_clause = " AND 1=0"
            else:
                marks = ",".join("?" for _ in class_ids)
                class_clause = f" AND class_id IN ({marks})"
                class_args = class_ids
        evidence_rows = conn.execute(
            f"""
            SELECT * FROM growth_evidence
            WHERE student_id=? AND publish_state='published' AND visibility IN ('parent_visible','report')
            {evidence_filter}{class_clause}
            ORDER BY evidence_date DESC,updated_at DESC
            """,
            (student_id, *evidence_args, *class_args),
        ).fetchall()
        attendance_where = ""
        attendance_args: list[Any] = []
        if period == "week":
            attendance_where = " AND cs.session_date>=?"
            attendance_args = [(date.today() - timedelta(days=6)).isoformat()]
        elif period == "month":
            attendance_where = " AND cs.session_date>=?"
            attendance_args = [date.today().replace(day=1).isoformat()]
        elif period == "term":
            if not class_ids:
                attendance_where = " AND 1=0"
            else:
                marks = ",".join("?" for _ in class_ids)
                attendance_where = f" AND cs.class_id IN ({marks})"
                attendance_args = class_ids
        attendance_rows = conn.execute(
            f"""
            SELECT cs.session_date,a.status,a.participation,a.confidence,a.homework
            FROM attendance_entries a JOIN class_sessions cs ON cs.id=a.session_id
            WHERE a.student_id=? {attendance_where}
            ORDER BY cs.session_date DESC
            """,
            (student_id, *attendance_args),
        ).fetchall()
        counts = {"present": 0, "late": 0, "absent": 0, "excused": 0}
        participation: list[int] = []
        confidence: list[int] = []
        homework = {"done": 0, "partial": 0, "missing": 0}
        for r in attendance_rows:
            counts[r["status"]] += 1
            participation.append(r["participation"])
            confidence.append(r["confidence"])
            homework[r["homework"]] += 1
        counted = counts["present"] + counts["late"] + counts["absent"]
        dimensions = {key: 0 for key in ["language", "knowledge", "participation", "confidence", "habits", "independence"]}
        evidence = [self._evidence_payload(conn, r) for r in evidence_rows]
        for item in evidence:
            for key in item["dimensions"]:
                if key in dimensions:
                    dimensions[key] += 1
        return {
            "period": period, "methodology": methodology, "generatedAt": utc_now(), "child": child,
            "evidenceCount": len(evidence), "milestones": [item for item in evidence if item["kind"] == "milestone"],
            "recentEvidence": evidence[:12], "dimensionEvidenceCounts": dimensions,
            "attendance": {
                "sessionCount": len(attendance_rows), "counts": counts,
                "rate": round(((counts["present"] + counts["late"]) / counted) * 100, 1) if counted else None,
                "averageParticipation": round(sum(participation) / len(participation), 1) if participation else None,
                "averageConfidence": round(sum(confidence) / len(confidence), 1) if confidence else None,
                "homework": homework,
            },
            "parentActions": self._parent_actions_for_student(conn, student_id),
        }

    def parent_child_report(self, parent: dict[str, Any], student_id: str, period: str) -> dict[str, Any]:
        with self.connect() as conn:
            if not conn.execute("SELECT 1 FROM guardian_links_v2 WHERE parent_account_id=? AND student_id=?", (parent["id"], student_id)).fetchone():
                raise ApiError(403, "CHILD_SCOPE_FORBIDDEN", "This child is not linked to your parent account.")
            return self._build_student_report(conn, student_id, period)

    def teacher_student_report(self, teacher: dict[str, Any], institution_id: str, student_id: str, period: str) -> dict[str, Any]:
        with self.connect() as conn:
            student = conn.execute("SELECT institution_id FROM students WHERE id=? AND status='active'", (student_id,)).fetchone()
            if not student or student["institution_id"] != institution_id:
                raise ApiError(404, "STUDENT_NOT_FOUND", "Student was not found in this institution.")
            membership = self._require_membership(conn, teacher, institution_id)
            if membership["role"] not in {"owner", "admin"}:
                accessible = conn.execute(
                    "SELECT 1 FROM class_students cs JOIN teacher_class_assignments t ON t.class_id=cs.class_id WHERE cs.student_id=? AND t.teacher_account_id=? LIMIT 1",
                    (student_id, teacher["id"]),
                ).fetchone()
                if not accessible:
                    raise ApiError(403, "STUDENT_SCOPE_FORBIDDEN", "Student is outside your assigned classes.")
            return self._build_student_report(conn, student_id, period)

    def save_class_session(self, teacher: dict[str, Any], data: dict[str, Any]) -> dict[str, Any]:
        institution_id = clean_text(data.get("institutionId"), 80)
        class_id = clean_text(data.get("classId"), 80)
        session_date = clean_text(data.get("date"), 20)
        topic = clean_text(data.get("topic"), 240)
        try:
            datetime.strptime(session_date, "%Y-%m-%d")
        except ValueError as exc:
            raise ApiError(400, "DATE_INVALID", "Session date must use YYYY-MM-DD.") from exc
        rows = data.get("rows", [])
        if not isinstance(rows, list):
            raise ApiError(400, "ROWS_INVALID", "Session rows must be an array.")
        with self._lock, self.connect() as conn:
            if not self._teacher_can_access_class(conn, teacher, institution_id, class_id):
                raise ApiError(403, "CLASS_ACCESS_FORBIDDEN", "You do not have access to this class.")
            enrolled = {r[0] for r in conn.execute("SELECT student_id FROM class_students WHERE class_id=?", (class_id,))}
            conn.execute("BEGIN IMMEDIATE")
            existing = conn.execute("SELECT id FROM class_sessions WHERE class_id=? AND session_date=?", (class_id, session_date)).fetchone()
            session_id = existing["id"] if existing else str(uuid.uuid4())
            now = utc_now()
            if existing:
                conn.execute("UPDATE class_sessions SET topic=?,updated_at=? WHERE id=?", (topic, now, session_id))
            else:
                conn.execute("INSERT INTO class_sessions(id,class_id,session_date,topic,created_by,created_at,updated_at) VALUES(?,?,?,?,?,?,?)", (session_id, class_id, session_date, topic, teacher["id"], now, now))
            saved = 0
            for item in rows:
                sid = clean_text(item.get("studentId"), 80)
                if sid not in enrolled:
                    conn.execute("ROLLBACK")
                    raise ApiError(400, "STUDENT_NOT_IN_CLASS", "One or more attendance rows contain a student outside this class.")
                status = clean_text(item.get("status"), 20) or "present"
                if status not in {"present", "late", "absent", "excused"}:
                    conn.execute("ROLLBACK")
                    raise ApiError(400, "ATTENDANCE_INVALID", "Attendance status is invalid.")
                try:
                    participation = int(item.get("participation", 3))
                    confidence = int(item.get("confidence", 3))
                except (TypeError, ValueError) as exc:
                    conn.execute("ROLLBACK")
                    raise ApiError(400, "RATING_INVALID", "Ratings must be numbers from 1 to 5.") from exc
                if not (1 <= participation <= 5 and 1 <= confidence <= 5):
                    conn.execute("ROLLBACK")
                    raise ApiError(400, "RATING_INVALID", "Ratings must be between 1 and 5.")
                homework = clean_text(item.get("homework"), 20) or "done"
                if homework not in {"done", "partial", "missing"}:
                    conn.execute("ROLLBACK")
                    raise ApiError(400, "HOMEWORK_INVALID", "Homework status is invalid.")
                note = clean_text(item.get("note"), 1000)
                conn.execute(
                    """
                    INSERT INTO attendance_entries(session_id,student_id,status,participation,confidence,homework,note,updated_at)
                    VALUES(?,?,?,?,?,?,?,?)
                    ON CONFLICT(session_id,student_id) DO UPDATE SET status=excluded.status,participation=excluded.participation,confidence=excluded.confidence,homework=excluded.homework,note=excluded.note,updated_at=excluded.updated_at
                    """,
                    (session_id, sid, status, participation, confidence, homework, note, now),
                )
                saved += 1
            self.audit(conn, teacher["id"], "save_class_session", institution_id=institution_id, object_type="class_session", object_id=session_id, detail={"classId": class_id, "rows": saved})
            conn.execute("COMMIT")
            return {"id": session_id, "classId": class_id, "date": session_date, "rowsSaved": saved}


class Handler(BaseHTTPRequestHandler):
    server_version = "SkyEDGrowthBridge/2.3"

    @property
    def store(self) -> GrowthBridgeStore:
        return self.server.store  # type: ignore[attr-defined]

    def log_message(self, fmt: str, *args: Any) -> None:
        print(f"{self.client_address[0]} - {fmt % args}", flush=True)

    def _json(self, status: int, payload: Any, headers: dict[str, str] | None = None) -> None:
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("X-SkyED-GrowthBridge-API", APP_VERSION)
        if headers:
            for key, value in headers.items():
                self.send_header(key, value)
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(body)

    def _read_json(self) -> dict[str, Any]:
        try:
            length = int(self.headers.get("Content-Length", "0"))
        except ValueError as exc:
            raise ApiError(400, "CONTENT_LENGTH_INVALID", "Invalid Content-Length.") from exc
        if length <= 0:
            return {}
        if length > MAX_BODY_BYTES:
            raise ApiError(413, "BODY_TOO_LARGE", "Request body is too large.")
        raw = self.rfile.read(length)
        try:
            value = json.loads(raw.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise ApiError(400, "JSON_INVALID", "Request body must be valid JSON.") from exc
        if not isinstance(value, dict):
            raise ApiError(400, "JSON_OBJECT_REQUIRED", "Request body must be a JSON object.")
        return value

    def _bearer(self) -> str | None:
        auth = self.headers.get("Authorization", "")
        return auth[7:].strip() if auth.startswith("Bearer ") else None

    def _user_agent(self) -> str:
        return clean_text(self.headers.get("User-Agent", ""), 300)

    def _route(self) -> tuple[str, list[str], dict[str, list[str]]]:
        parsed = urlparse(self.path)
        parts = [p for p in parsed.path.split("/") if p]
        return parsed.path, parts, parse_qs(parsed.query)

    def do_GET(self) -> None:
        self._handle(self._do_get)

    def do_POST(self) -> None:
        self._handle(self._do_post)

    def do_PATCH(self) -> None:
        self._handle(self._do_patch)

    def do_DELETE(self) -> None:
        self._handle(self._do_delete)

    def do_HEAD(self) -> None:
        self._handle(self._do_get)

    def _handle(self, fn) -> None:
        try:
            if self.command in {"POST", "PATCH", "DELETE"}:
                check_mutation_rate(self.client_address[0])
            fn()
        except ApiError as exc:
            self._json(exc.status, {"error": {"code": exc.code, "message": exc.message}})
        except BrokenPipeError:
            pass
        except Exception as exc:
            print(f"UNHANDLED={type(exc).__name__}:{exc}", flush=True)
            self._json(500, {"error": {"code": "INTERNAL_ERROR", "message": "Internal server error."}})


    def _do_get(self) -> None:
        path, parts, query = self._route()
        if path == "/api/v1/health":
            self._json(200, {"ok": True, "appVersion": APP_VERSION, "apiVersion": API_VERSION, "dataModel": "multi_institution_normalized"})
            return
        if path == "/api/v1/auth/status":
            self._json(200, self.store.status())
            return
        if path == "/api/v1/auth/me":
            self._json(200, {"account": self.store.authenticate(self._bearer())})
            return
        if path == "/api/v1/auth/sessions":
            bearer = self._bearer() or ""
            account = self.store.authenticate(bearer)
            self._json(200, {"sessions": self.store.list_account_sessions(account, bearer)})
            return
        if path == "/api/v1/teacher/institutions":
            teacher = self.store.authenticate(self._bearer(), "teacher")
            self._json(200, {"institutions": self.store.list_teacher_institutions(teacher)})
            return
        if len(parts) == 5 and parts[:4] == ["api", "v1", "teacher", "workspace"]:
            teacher = self.store.authenticate(self._bearer(), "teacher")
            self._json(200, self.store.teacher_workspace(teacher, parts[4]))
            return
        if path == "/api/v1/class-sessions":
            teacher = self.store.authenticate(self._bearer(), "teacher")
            institution_id = clean_text((query.get("institutionId") or [""])[0], 80)
            class_id = clean_text((query.get("classId") or [""])[0], 80) or None
            try:
                limit = int((query.get("limit") or ["100"])[0])
            except ValueError:
                limit = 100
            self._json(200, {"sessions": self.store.list_class_sessions(teacher, institution_id, class_id, limit)})
            return
        if len(parts) == 4 and parts[:3] == ["api", "v1", "class-sessions"]:
            teacher = self.store.authenticate(self._bearer(), "teacher")
            self._json(200, self.store.class_session_detail(teacher, parts[3]))
            return
        if len(parts) == 5 and parts[:3] == ["api", "v1", "institutions"] and parts[4] == "audit":
            admin = self.store.authenticate(self._bearer(), "teacher")
            try:
                limit = int((query.get("limit") or ["100"])[0])
            except ValueError:
                limit = 100
            self._json(200, {"events": self.store.list_audit_events(admin, parts[3], limit)})
            return
        if path == "/api/v1/parent/children":
            parent = self.store.authenticate(self._bearer(), "parent")
            self._json(200, self.store.parent_children(parent))
            return
        if len(parts) == 5 and parts[:4] == ["api", "v1", "parent", "child"]:
            parent = self.store.authenticate(self._bearer(), "parent")
            self._json(200, self.store.parent_child_detail(parent, parts[4]))
            return
        if len(parts) == 6 and parts[:4] == ["api", "v1", "parent", "child"] and parts[5] == "report":
            parent = self.store.authenticate(self._bearer(), "parent")
            period = clean_text((query.get("period") or ["month"])[0], 20)
            self._json(200, self.store.parent_child_report(parent, parts[4], period))
            return
        if len(parts) == 6 and parts[:4] == ["api", "v1", "teacher", "student"] and parts[5] == "report":
            teacher = self.store.authenticate(self._bearer(), "teacher")
            institution_id = clean_text((query.get("institutionId") or [""])[0], 80)
            period = clean_text((query.get("period") or ["month"])[0], 20)
            self._json(200, self.store.teacher_student_report(teacher, institution_id, parts[4], period))
            return
        raise ApiError(404, "NOT_FOUND", "API endpoint was not found.")


    def _do_post(self) -> None:
        path, parts, _ = self._route()
        data = self._read_json()
        if path == "/api/v1/auth/register":
            account, token = self.store.register(
                str(data.get("clientRole", "")), str(data.get("displayName", "")),
                str(data.get("email", "")), str(data.get("password", "")),
                self.client_address[0], self._user_agent(),
            )
            self._json(201, {"account": account, "token": token})
            return
        if path == "/api/v1/auth/login":
            account, token = self.store.login(
                str(data.get("email", "")), str(data.get("password", "")),
                str(data.get("clientRole", "")), self.client_address[0], self._user_agent(),
            )
            self._json(200, {"account": account, "token": token})
            return
        if path == "/api/v1/auth/logout":
            bearer = self._bearer()
            account = self.store.authenticate(bearer)
            self.store.logout(bearer or "", account["id"])
            self._json(200, {"ok": True})
            return
        if path == "/api/v1/auth/change-password":
            account = self.store.authenticate(self._bearer())
            self.store.change_password(account, str(data.get("currentPassword", "")), str(data.get("newPassword", "")))
            self._json(200, {"ok": True})
            return
        if path == "/api/v1/teacher/institutions":
            teacher = self.store.authenticate(self._bearer(), "teacher")
            self._json(201, self.store.create_institution(teacher, str(data.get("name", ""))))
            return
        if path == "/api/v1/teacher/join-requests":
            teacher = self.store.authenticate(self._bearer(), "teacher")
            self._json(201, self.store.request_join(teacher, str(data.get("schoolCode", ""))))
            return
        if path == "/api/v1/teacher/invitations/accept":
            teacher = self.store.authenticate(self._bearer(), "teacher")
            self._json(200, self.store.accept_teacher_invitation(teacher, str(data.get("token", ""))))
            return
        if len(parts) == 5 and parts[:3] == ["api", "v1", "institutions"] and parts[4] == "classes":
            admin = self.store.authenticate(self._bearer(), "teacher")
            self._json(201, self.store.create_class(admin, parts[3], data))
            return
        if len(parts) == 5 and parts[:3] == ["api", "v1", "institutions"] and parts[4] == "students":
            admin = self.store.authenticate(self._bearer(), "teacher")
            self._json(201, self.store.create_student(admin, parts[3], data))
            return
        if len(parts) == 5 and parts[:3] == ["api", "v1", "institutions"] and parts[4] == "teacher-invitations":
            admin = self.store.authenticate(self._bearer(), "teacher")
            role = str(data.get("role", "teacher"))
            email = str(data.get("email", "")).strip() or None
            class_ids = [str(x) for x in data.get("classIds", []) if isinstance(x, (str, int))]
            self._json(201, self.store.create_teacher_invitation(admin, parts[3], role, email, class_ids))
            return
        if len(parts) == 7 and parts[:3] == ["api", "v1", "institutions"] and parts[4] == "join-requests" and parts[6] == "approve":
            admin = self.store.authenticate(self._bearer(), "teacher")
            self._json(200, self.store.approve_join_request(admin, parts[3], parts[5]))
            return
        if len(parts) == 7 and parts[:3] == ["api", "v1", "institutions"] and parts[4] == "join-requests" and parts[6] == "reject":
            admin = self.store.authenticate(self._bearer(), "teacher")
            self._json(200, self.store.reject_join_request(admin, parts[3], parts[5]))
            return
        if len(parts) == 7 and parts[:3] == ["api", "v1", "institutions"] and parts[4] == "classes" and parts[6] == "students":
            admin = self.store.authenticate(self._bearer(), "teacher")
            self._json(200, self.store.add_student_to_class(admin, parts[3], parts[5], str(data.get("studentId", ""))))
            return
        if len(parts) == 5 and parts[:3] == ["api", "v1", "institutions"] and parts[4] == "teacher-assignments":
            admin = self.store.authenticate(self._bearer(), "teacher")
            self._json(200, self.store.assign_teacher(admin, parts[3], str(data.get("classId", "")), str(data.get("teacherAccountId", ""))))
            return
        if len(parts) == 5 and parts[:3] == ["api", "v1", "students"] and parts[4] == "claim-code":
            admin = self.store.authenticate(self._bearer(), "teacher")
            self._json(201, self.store.create_child_claim(admin, parts[3]))
            return
        if path == "/api/v1/parent/claim-child":
            parent = self.store.authenticate(self._bearer(), "parent")
            self._json(200, self.store.claim_child(parent, str(data.get("code", ""))))
            return
        if path == "/api/v1/evidence":
            teacher = self.store.authenticate(self._bearer(), "teacher")
            self._json(201, self.store.add_evidence(teacher, data))
            return
        if path == "/api/v1/parent-actions":
            teacher = self.store.authenticate(self._bearer(), "teacher")
            self._json(201, self.store.add_parent_action(teacher, data))
            return
        if path == "/api/v1/class-sessions":
            teacher = self.store.authenticate(self._bearer(), "teacher")
            self._json(200, self.store.save_class_session(teacher, data))
            return
        raise ApiError(404, "NOT_FOUND", "API endpoint was not found.")


    def _do_patch(self) -> None:
        _, parts, _ = self._route()
        data = self._read_json()
        if len(parts) == 4 and parts[:3] == ["api", "v1", "auth"] and parts[3] == "profile":
            account = self.store.authenticate(self._bearer())
            self._json(200, {"account": self.store.update_profile(account, str(data.get("displayName", "")))})
            return
        if len(parts) == 4 and parts[:3] == ["api", "v1", "evidence"]:
            teacher = self.store.authenticate(self._bearer(), "teacher")
            self._json(200, self.store.update_evidence(teacher, parts[3], data))
            return
        if len(parts) == 4 and parts[:3] == ["api", "v1", "parent-actions"]:
            account = self.store.authenticate(self._bearer())
            self._json(200, self.store.update_parent_action(account, parts[3], data))
            return
        if len(parts) == 4 and parts[:3] == ["api", "v1", "institutions"]:
            admin = self.store.authenticate(self._bearer(), "teacher")
            self._json(200, self.store.update_institution(admin, parts[3], data))
            return
        if len(parts) == 6 and parts[:3] == ["api", "v1", "institutions"] and parts[4] == "classes":
            admin = self.store.authenticate(self._bearer(), "teacher")
            self._json(200, self.store.update_class(admin, parts[3], parts[5], data))
            return
        if len(parts) == 6 and parts[:3] == ["api", "v1", "institutions"] and parts[4] == "students":
            admin = self.store.authenticate(self._bearer(), "teacher")
            self._json(200, self.store.update_student(admin, parts[3], parts[5], data))
            return
        if len(parts) == 6 and parts[:3] == ["api", "v1", "institutions"] and parts[4] == "members":
            admin = self.store.authenticate(self._bearer(), "teacher")
            self._json(200, self.store.update_membership(admin, parts[3], parts[5], data))
            return
        raise ApiError(404, "NOT_FOUND", "API endpoint was not found.")


    def _do_delete(self) -> None:
        _, parts, _ = self._route()
        data = self._read_json()
        if len(parts) == 5 and parts[:3] == ["api", "v1", "auth"] and parts[3] == "sessions":
            account = self.store.authenticate(self._bearer())
            self._json(200, self.store.revoke_account_session(account, parts[4]))
            return
        if len(parts) == 8 and parts[:3] == ["api", "v1", "institutions"] and parts[4] == "classes" and parts[6] == "students":
            admin = self.store.authenticate(self._bearer(), "teacher")
            self._json(200, self.store.remove_student_from_class(admin, parts[3], parts[5], parts[7]))
            return
        if len(parts) == 5 and parts[:3] == ["api", "v1", "institutions"] and parts[4] == "teacher-assignments":
            admin = self.store.authenticate(self._bearer(), "teacher")
            self._json(200, self.store.unassign_teacher(admin, parts[3], str(data.get("classId", "")), str(data.get("teacherAccountId", ""))))
            return
        if len(parts) == 6 and parts[:3] == ["api", "v1", "institutions"] and parts[4] == "teacher-invitations":
            admin = self.store.authenticate(self._bearer(), "teacher")
            self._json(200, self.store.revoke_teacher_invitation(admin, parts[3], parts[5]))
            return
        if len(parts) == 6 and parts[:3] == ["api", "v1", "students"] and parts[4] == "claim-code":
            admin = self.store.authenticate(self._bearer(), "teacher")
            self._json(200, self.store.revoke_child_claim(admin, parts[3], parts[5]))
            return
        if len(parts) == 5 and parts[:3] == ["api", "v1", "parent"] and parts[3] == "children":
            parent = self.store.authenticate(self._bearer(), "parent")
            self._json(200, self.store.unlink_child(parent, parts[4]))
            return
        raise ApiError(404, "NOT_FOUND", "API endpoint was not found.")

class Server(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True

    def __init__(self, address: tuple[str, int], store: GrowthBridgeStore):
        super().__init__(address, Handler)
        self.store = store


def main() -> None:
    parser = argparse.ArgumentParser(description="SkyED GrowthBridge operational multi-institution synchronized API")
    parser.add_argument("--db", required=True)
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=3221)
    args = parser.parse_args()
    store = GrowthBridgeStore(Path(args.db).resolve())
    server = Server((args.host, args.port), store)
    print(f"SKYED_GROWTHBRIDGE_API={APP_VERSION}", flush=True)
    print("DATA_MODEL=multi_institution_normalized", flush=True)
    print(f"LISTEN={args.host}:{args.port}", flush=True)
    print(f"DB={Path(args.db).resolve()}", flush=True)
    server.serve_forever()


if __name__ == "__main__":
    main()
