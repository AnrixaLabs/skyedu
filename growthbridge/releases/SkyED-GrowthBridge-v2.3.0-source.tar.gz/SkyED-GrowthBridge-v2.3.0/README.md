# SkyED GrowthBridge 2.3 · 家校成长台

**Release:** 2.3.0 — Operational Product Release  
**Production target:** `https://growth.skyed.org`  
**Parent client:** `/parent/`  
**Teacher client:** `/teacher/`  
**API:** `/api/v1/`

GrowthBridge is the family-facing growth communication platform for schools, teachers and parents. Version 2.3 preserves the v2.2 multi-institution architecture and turns it into an operational daily-use product.

## Product boundary

GrowthBridge remains independent from ClassFlow. It does not read or mutate `/opt/classflow` or the ClassFlow database. The main SkyED site at `/var/www/skyed.org` is also protected by the deployment controller. Any future cross-product integration must use stable IDs and APIs rather than direct database coupling.

## Operational model

- A global teacher account can belong to one or more institutions.
- Institution memberships are `owner`, `admin`, or `teacher`.
- Owners/admins manage staff, classes, students, invitations, guardian claim codes, and audit records.
- Ordinary teachers access only explicitly assigned classes and their students.
- A global parent account can link children from multiple institutions.
- Parent-child relationships are established by one-time institution-issued claim codes.
- Parent clients receive only linked-child data and published parent-visible/report evidence.
- Parent and Teacher PWAs use the same authoritative `/api/v1/` backend and persistent database.

## v2.3 operational additions

Teacher client:

- institution switching and institution rename;
- class create/edit/archive and roster management;
- student create/edit/archive and multi-class enrollment;
- guardian claim-code generation/history/revocation;
- class session history, reopen/correction, attendance and classroom metrics;
- evidence editing, milestone evidence, publish workflow, parent actions, and teacher report preview;
- join request approval/rejection;
- teacher invitation creation/revocation and optional class pre-assignment;
- staff role/status management and class-access matrix;
- institution audit trail.

Parent client:

- cross-institution child linking and switching;
- published growth evidence and milestone timeline;
- source-backed growth-dimension evidence counts;
- attendance and classroom history;
- parent actions with completion state synchronized back to the backend;
- week/month/term/all reports;
- child unlinking without deleting the institution student record;
- display-name/password management;
- multi-device session listing and remote session revocation.

Operations/security:

- additive database migration only;
- SQLite WAL persistence for the current single-ECS topology;
- database backup + `PRAGMA integrity_check` before promotion;
- post-migration integrity and core-row preservation gates;
- server-side role/scope enforcement;
- mutation rate limiting;
- hashed passwords and session/invitation/claim secrets;
- immutable releases and atomic activation;
- Parent/Teacher PWA service-worker update handling;
- API responses are never service-worker cached.

## Data authority

The backend is authoritative. Client-side UI state is not permission authority and no browser-computed financial/academic total is treated as a system fact.

Growth reports deliberately avoid fabricated scores. They summarize traceable evidence counts, milestones, attendance, participation/confidence averages from recorded sessions, homework states, and parent actions.

## Current persistence

Production database:

`/opt/skyed-growthbridge/data/growthbridge.db`

SQLite WAL is intentional for the current single API-service ECS deployment. PostgreSQL is the scale gate before multi-server API deployment or materially larger concurrency; v2.3 does not introduce a needless database rewrite.

## Build

```bash
npm install
npm run build
```

Backend validation:

```bash
python3 backend/test_multitenant.py
python3 backend/test_operational.py
```

Production deployment is performed with the self-extracting PowerShell controller generated for this release. Do not manually overwrite the active release directory.
