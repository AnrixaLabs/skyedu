import { useMemo, useState, type FormEvent } from 'react';
import { ArrowRight, Building2, GraduationCap, KeyRound, Languages, LockKeyhole, ShieldCheck, Sparkles, UserRound, UsersRound } from 'lucide-react';
import type { Locale, Role } from '../types/domain';

export function ClientChooser({ locale, onLocaleToggle }: { locale: Locale; onLocaleToggle: () => void }) {
  return (
    <div className="entry-screen">
      <div className="entry-language"><button type="button" onClick={onLocaleToggle}><Languages size={17} />{locale === 'zh' ? 'EN' : '中文'}</button></div>
      <div className="entry-panel">
        <div className="entry-brand"><div className="entry-logo"><Sparkles size={25} /></div><div><strong>SkyED GrowthBridge</strong><span>{locale === 'zh' ? '家校成长台' : 'Home–School Growth Platform'}</span></div></div>
        <div className="entry-copy">
          <span className="eyebrow">{locale === 'zh' ? '多学校 · 多班级 · 多家庭' : 'Multi-school · multi-class · multi-family'}</span>
          <h1>{locale === 'zh' ? '学校端与家长端独立使用，共享同一可信数据源。' : 'Separate school and parent clients, one trusted data source.'}</h1>
          <p>{locale === 'zh' ? '教师可创建或加入学校、管理班级和学生；家长可关联来自不同学校的孩子，并分别查看学校发布的成长与课堂记录。' : 'Teachers can create or join institutions and manage classes and students. Parents can link children from different institutions and follow each child independently.'}</p>
        </div>
        <div className="client-choice-grid">
          <a className="client-choice-card parent-choice" href="/parent/">
            <div className="client-choice-icon"><UserRound size={25} /></div>
            <div><span>{locale === 'zh' ? '家长端' : 'Parent Client'}</span><strong>{locale === 'zh' ? '关联并查看孩子' : 'Link and follow your children'}</strong><p>{locale === 'zh' ? '一个账号可关联不同学校的多个孩子。' : 'One account can link multiple children across institutions.'}</p></div>
            <ArrowRight size={20} />
          </a>
          <a className="client-choice-card teacher-choice" href="/teacher/">
            <div className="client-choice-icon"><GraduationCap size={25} /></div>
            <div><span>{locale === 'zh' ? '教师端' : 'Teacher Client'}</span><strong>{locale === 'zh' ? '创建学校或加入团队' : 'Create an institution or join a team'}</strong><p>{locale === 'zh' ? '班级权限由学校管理员分配，教师仅访问授权班级。' : 'Class access is assigned by the institution; teachers only see authorized classes.'}</p></div>
            <ArrowRight size={20} />
          </a>
        </div>
        <div className="entry-security"><ShieldCheck size={16} /><span>{locale === 'zh' ? '账号、学校、班级、学生与家长关系均由服务器端校验。' : 'Accounts, institutions, classes, students and parent links are enforced server-side.'}</span></div>
      </div>
    </div>
  );
}

export function AuthScreen({
  role,
  locale,
  invitationToken,
  busy,
  error,
  onLocaleToggle,
  onLogin,
  onRegister,
}: {
  role: Role;
  locale: Locale;
  invitationToken: string | null;
  busy: boolean;
  error: string | null;
  onLocaleToggle: () => void;
  onLogin: (email: string, password: string) => Promise<void>;
  onRegister: (displayName: string, email: string, password: string) => Promise<void>;
}) {
  const [mode, setMode] = useState<'login' | 'register'>(invitationToken ? 'register' : 'login');
  const [displayName, setDisplayName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const copy = useMemo(() => ({
    zh: {
      parent: '家长端', teacher: '教师端',
      welcome: role === 'parent' ? '一个账号，分别追踪不同学校的孩子' : '建立学校、班级与教师权限体系',
      login: '登录', register: '注册', name: '姓名 / 显示名称', email: '邮箱', password: '密码（至少10位）',
      loginHelp: role === 'parent' ? '登录后使用学校提供的孩子关联码添加孩子。' : '登录后可创建学校、申请加入学校或接受教师邀请。',
      registerHelp: role === 'parent' ? '家长可自行注册；孩子必须使用学校生成的安全关联码添加。' : '教师可自行注册；班级访问必须由学校授权。',
      inviteHelp: '此链接包含教师邀请。注册或登录后将自动尝试加入对应学校。', back: '返回客户端选择',
    },
    en: {
      parent: 'Parent Client', teacher: 'Teacher Client',
      welcome: role === 'parent' ? 'One account, children from different institutions' : 'Build institution, class and teacher access',
      login: 'Sign in', register: 'Create account', name: 'Name / display name', email: 'Email', password: 'Password (10+ characters)',
      loginHelp: role === 'parent' ? 'After sign-in, add children using secure link codes issued by their institutions.' : 'After sign-in, create an institution, request to join one, or accept a teacher invitation.',
      registerHelp: role === 'parent' ? 'Parents self-register. Children can only be linked with institution-issued claim codes.' : 'Teachers self-register. Class access must still be granted by the institution.',
      inviteHelp: 'This link contains a teacher invitation. After registration or sign-in, GrowthBridge will try to join the assigned institution.', back: 'Back to client choice',
    },
  }[locale]), [locale, role]);

  const submit = async (event: FormEvent) => {
    event.preventDefault();
    if (mode === 'register') return onRegister(displayName, email, password);
    return onLogin(email, password);
  };

  return (
    <div className={`auth-screen ${role}`}>
      <div className="auth-toolbar"><a href="/">← {copy.back}</a><button type="button" onClick={onLocaleToggle}><Languages size={16} />{locale === 'zh' ? 'EN' : '中文'}</button></div>
      <div className="auth-layout">
        <section className="auth-brand-panel">
          <div className="entry-brand"><div className="entry-logo"><Sparkles size={23} /></div><div><strong>SkyED GrowthBridge</strong><span>{locale === 'zh' ? '家校成长台' : 'Home–School Growth Platform'}</span></div></div>
          <div className="auth-role-mark">{role === 'parent' ? <UserRound size={28} /> : <Building2 size={28} />}</div>
          <span className="eyebrow">{role === 'parent' ? copy.parent : copy.teacher}</span>
          <h1>{copy.welcome}</h1>
          <p>{invitationToken ? copy.inviteHelp : mode === 'register' ? copy.registerHelp : copy.loginHelp}</p>
          <div className="auth-trust"><LockKeyhole size={17} /><span>{locale === 'zh' ? '独立客户端 · 服务端权限 · 多设备同步' : 'Separate client · server authorization · multi-device sync'}</span></div>
        </section>
        <section className="auth-card">
          <div className="auth-tabs">
            <button type="button" className={mode === 'login' ? 'active' : ''} onClick={() => setMode('login')}>{copy.login}</button>
            <button type="button" className={mode === 'register' ? 'active' : ''} onClick={() => setMode('register')}>{copy.register}</button>
          </div>
          <div className="auth-card-head"><KeyRound size={20} /><div><span>{role === 'parent' ? copy.parent : copy.teacher}</span><h2>{mode === 'register' ? copy.register : copy.login}</h2></div></div>
          <form onSubmit={submit}>
            {mode === 'register' ? <label><span>{copy.name}</span><input autoComplete="name" value={displayName} onChange={(e) => setDisplayName(e.target.value)} required /></label> : null}
            <label><span>{copy.email}</span><input type="email" autoComplete="email" value={email} onChange={(e) => setEmail(e.target.value)} required /></label>
            <label><span>{copy.password}</span><input type="password" autoComplete={mode === 'register' ? 'new-password' : 'current-password'} value={password} onChange={(e) => setPassword(e.target.value)} minLength={10} required /></label>
            {error ? <div className="auth-error">{error}</div> : null}
            <button className="primary-button auth-submit" type="submit" disabled={busy}>{busy ? (locale === 'zh' ? '处理中…' : 'Working…') : mode === 'register' ? copy.register : copy.login}<ArrowRight size={17} /></button>
          </form>
        </section>
      </div>
    </div>
  );
}

export function ConnectionError({ locale, detail, onRetry }: { locale: Locale; detail: string; onRetry: () => void }) {
  return <div className="connection-state"><div className="entry-logo"><Sparkles size={22} /></div><h2>{locale === 'zh' ? '暂时无法连接 GrowthBridge' : 'GrowthBridge is temporarily unavailable'}</h2><p>{detail}</p><button type="button" className="primary-button" onClick={onRetry}>{locale === 'zh' ? '重试' : 'Retry'}</button></div>;
}
