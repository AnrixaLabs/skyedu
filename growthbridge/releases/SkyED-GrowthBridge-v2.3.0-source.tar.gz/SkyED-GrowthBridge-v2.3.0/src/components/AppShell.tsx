import type { ReactNode } from 'react';
import {
  BarChart3,
  BookOpenCheck,
  Building2,
  ClipboardList,
  GraduationCap,
  Home,
  Languages,
  LogOut,
  School,
  Sparkles,
  UserRound,
  UsersRound,
} from 'lucide-react';
import type { Locale, Role } from '../types/domain';
import type { AccountIdentity } from '../lib/api';

export type ParentPage = 'home' | 'growth' | 'classroom' | 'reports' | 'profile';
export type TeacherPage = 'home' | 'classes' | 'students' | 'session' | 'evidence' | 'staff';

export function AppShell({
  children,
  locale,
  role,
  identity,
  parentPage,
  teacherPage,
  contextTitle,
  contextSubtitle,
  canSwitchContext,
  onContextSwitch,
  onLocaleToggle,
  onParentNavigate,
  onTeacherNavigate,
  onLogout,
}: {
  children: ReactNode;
  locale: Locale;
  role: Role;
  identity: AccountIdentity;
  parentPage: ParentPage;
  teacherPage: TeacherPage;
  contextTitle?: string;
  contextSubtitle?: string;
  canSwitchContext?: boolean;
  onContextSwitch?: () => void;
  onLocaleToggle: () => void;
  onParentNavigate: (page: ParentPage) => void;
  onTeacherNavigate: (page: TeacherPage) => void;
  onLogout: () => void;
}) {
  const parentNav: Array<{ page: ParentPage; icon: typeof Home; zh: string; en: string }> = [
    { page: 'home', icon: Home, zh: '首页', en: 'Home' },
    { page: 'growth', icon: Sparkles, zh: '成长', en: 'Growth' },
    { page: 'classroom', icon: BookOpenCheck, zh: '课堂', en: 'Classroom' },
    { page: 'reports', icon: BarChart3, zh: '报告', en: 'Reports' },
    { page: 'profile', icon: UserRound, zh: '我的', en: 'Me' },
  ];
  const teacherNav: Array<{ page: TeacherPage; icon: typeof Home; zh: string; en: string }> = [
    { page: 'home', icon: School, zh: '学校', en: 'Institution' },
    { page: 'classes', icon: GraduationCap, zh: '班级', en: 'Classes' },
    { page: 'students', icon: UsersRound, zh: '学生', en: 'Students' },
    { page: 'session', icon: ClipboardList, zh: '课堂', en: 'Session' },
    { page: 'evidence', icon: Sparkles, zh: '成长', en: 'Growth' },
    { page: 'staff', icon: Building2, zh: '管理', en: 'Admin' },
  ];
  const nav = role === 'parent' ? parentNav : teacherNav;

  return (
    <div className={`app-shell client-${role}`}>
      <aside className="sidebar">
        <div className="brand-block">
          <div className="brand-mark"><Sparkles size={19} /></div>
          <div><strong>SkyED GrowthBridge</strong><span>{locale === 'zh' ? '家校成长台' : 'Home–School Growth Platform'}</span></div>
        </div>

        <div className={`client-badge ${role}`}>
          {role === 'parent' ? <UserRound size={15} /> : <UsersRound size={15} />}
          <span>{role === 'parent' ? (locale === 'zh' ? '家长端' : 'Parent Client') : (locale === 'zh' ? '教师端' : 'Teacher Client')}</span>
        </div>

        <button className="student-rail-card" type="button" onClick={canSwitchContext ? onContextSwitch : undefined} disabled={!canSwitchContext}>
          <div className="teacher-avatar">{contextTitle?.trim().slice(0, 1).toUpperCase() || identity.displayName.trim().slice(0, 1).toUpperCase() || '?'}</div>
          <span><strong>{contextTitle || identity.displayName}</strong><small>{contextSubtitle || identity.email}</small></span>
          {canSwitchContext ? <span className="rail-switch">↔</span> : null}
        </button>

        <nav className="side-nav">
          {nav.map((item) => {
            const active = role === 'parent' ? parentPage === item.page : teacherPage === item.page;
            const Icon = item.icon;
            return (
              <button
                key={item.page}
                type="button"
                className={active ? 'active' : ''}
                onClick={() => role === 'parent' ? onParentNavigate(item.page as ParentPage) : onTeacherNavigate(item.page as TeacherPage)}
              >
                <Icon size={18} /><span>{locale === 'zh' ? item.zh : item.en}</span>
              </button>
            );
          })}
        </nav>

        <div className="sidebar-footer">
          <div className="account-mini"><strong>{identity.displayName}</strong><span>{identity.email}</span></div>
          <button type="button" onClick={onLocaleToggle}><Languages size={17} />{locale === 'zh' ? 'English' : '中文'}</button>
          <button type="button" onClick={onLogout}><LogOut size={17} />{locale === 'zh' ? '退出登录' : 'Sign out'}</button>
        </div>
      </aside>

      <main className="main-stage">
        <header className="mobile-header">
          <div className="brand-block compact"><div className="brand-mark"><Sparkles size={17} /></div><div><strong>SkyED GrowthBridge</strong><span>{role === 'parent' ? (locale === 'zh' ? '家长端' : 'Parent') : (locale === 'zh' ? '教师端' : 'Teacher')}</span></div></div>
          <div className="mobile-header-actions"><button type="button" onClick={onLocaleToggle}><Languages size={17} /></button><button type="button" onClick={onLogout}><LogOut size={17} /></button></div>
        </header>
        <div className="page-canvas">{children}</div>
      </main>

      <nav className={`bottom-nav ${role === 'teacher' ? 'teacher-six' : 'parent-five'}`}>
        {nav.map((item) => {
          const active = role === 'parent' ? parentPage === item.page : teacherPage === item.page;
          const Icon = item.icon;
          return <button key={item.page} type="button" className={active ? 'active' : ''} onClick={() => role === 'parent' ? onParentNavigate(item.page as ParentPage) : onTeacherNavigate(item.page as TeacherPage)}><Icon size={20} /><span>{locale === 'zh' ? item.zh : item.en}</span></button>;
        })}
      </nav>
    </div>
  );
}
