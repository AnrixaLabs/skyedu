import { useEffect, useState, type FormEvent, type ReactNode } from 'react';
import {
  Activity,
  BarChart3,
  Building2,
  Check,
  CheckCircle2,
  ChevronRight,
  ClipboardList,
  Copy,
  FileText,
  GraduationCap,
  History,
  KeyRound,
  Link2,
  ListChecks,
  LockKeyhole,
  Milestone,
  Pencil,
  Plus,
  RefreshCw,
  Save,
  School,
  Search,
  ShieldCheck,
  Sparkles,
  Trash2,
  UserCheck,
  UserRound,
  UsersRound,
  X,
} from 'lucide-react';
import type { AttendanceStatus, EvidenceKind, GrowthDimensionKey, Locale, PublishState, Visibility } from '../types/domain';
import {
  api,
  type AccountIdentity,
  type AccountSession,
  type AttendanceInput,
  type AuditEvent,
  type ClassSummary,
  type EvidenceRecord,
  type InstitutionSummary,
  type ParentChildDetail,
  type ReportPeriod,
  type SessionDetail,
  type StudentReport,
  type StudentSummary,
  type TeacherWorkspace,
} from '../lib/api';

const t = (locale: Locale, zh: string, en: string) => locale === 'zh' ? zh : en;
const today = () => new Date().toISOString().slice(0, 10);
const timestamp = (value: string | number | null) => {
  if (!value) return '—';
  const date = typeof value === 'number' ? new Date(value * 1000) : new Date(value);
  return Number.isNaN(date.getTime()) ? String(value) : date.toLocaleString();
};
const activeClaim = (claim: { usedAt: string | null; revokedAt: string | null; expiresAt: number }) => !claim.usedAt && !claim.revokedAt && claim.expiresAt * 1000 > Date.now();
const statusLabel = (locale: Locale, status: AttendanceStatus) => ({
  present: t(locale, '出席', 'Present'),
  late: t(locale, '迟到', 'Late'),
  absent: t(locale, '缺席', 'Absent'),
  excused: t(locale, '请假', 'Excused'),
}[status]);
const dimensionLabels: Record<GrowthDimensionKey, { zh: string; en: string }> = {
  language: { zh: '语言', en: 'Language' },
  knowledge: { zh: '知识', en: 'Knowledge' },
  participation: { zh: '参与', en: 'Participation' },
  confidence: { zh: '自信', en: 'Confidence' },
  habits: { zh: '习惯', en: 'Habits' },
  independence: { zh: '独立性', en: 'Independence' },
};
const evidenceKinds: EvidenceKind[] = ['observation', 'assessment', 'attendance', 'homework', 'milestone'];
const dimensions = Object.keys(dimensionLabels) as GrowthDimensionKey[];

function Stat({ label, value, hint }: { label: string; value: string | number; hint?: string }) {
  return <div className="metric-card"><span>{label}</span><strong>{value}</strong>{hint ? <small>{hint}</small> : null}</div>;
}

function EmptyState({ title, detail }: { title: string; detail: string }) {
  return <div className="workspace-empty"><Sparkles size={26} /><h3>{title}</h3><p>{detail}</p></div>;
}

function Feedback({ text, danger = false }: { text: string; danger?: boolean }) {
  return text ? <div className={danger ? 'operation-feedback danger' : 'operation-feedback'}>{text}</div> : null;
}

function PageHeading({ eyebrow, title, detail, action }: { eyebrow: string; title: string; detail: string; action?: ReactNode }) {
  return <div className="page-heading split"><div><span className="eyebrow">{eyebrow}</span><h1>{title}</h1><p>{detail}</p></div>{action}</div>;
}

function InstitutionPicker({ locale, institutions, activeId, onSelect }: { locale: Locale; institutions: InstitutionSummary[]; activeId: string; onSelect: (id: string) => void }) {
  if (institutions.length <= 1) return null;
  return <label className="context-select"><span>{t(locale, '当前机构', 'Current institution')}</span><select value={activeId} onChange={(e) => onSelect(e.target.value)}>{institutions.map((item) => <option key={item.id} value={item.id}>{item.name} · {item.code}</option>)}</select></label>;
}

export function TeacherOnboarding({
  locale,
  pendingInvite,
  onCreateInstitution,
  onRequestJoin,
  onAcceptInvitation,
}: {
  locale: Locale;
  pendingInvite: string | null;
  onCreateInstitution: (name: string) => Promise<void>;
  onRequestJoin: (code: string) => Promise<string>;
  onAcceptInvitation: (token: string) => Promise<void>;
}) {
  const [schoolName, setSchoolName] = useState('');
  const [schoolCode, setSchoolCode] = useState('');
  const [invite, setInvite] = useState(pendingInvite ?? '');
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState('');
  const run = async (fn: () => Promise<void | string>) => {
    setBusy(true); setMessage('');
    try { const result = await fn(); setMessage(typeof result === 'string' ? result : t(locale, '完成。', 'Completed.')); }
    catch (error) { setMessage(error instanceof Error ? error.message : String(error)); }
    finally { setBusy(false); }
  };
  return <div className="workspace-stack">
    <PageHeading eyebrow={t(locale, '教师端 · 开始', 'Teacher client · Get started')} title={t(locale, '进入你的学校工作区', 'Enter your institution workspace')} detail={t(locale, '创建机构、使用学校代码申请加入，或接受管理员发出的教师邀请。', 'Create an institution, request access with a school code, or accept a teacher invitation.')} />
    <div className="onboarding-grid">
      <section className="workspace-card"><div className="card-icon blue"><Building2 /></div><h3>{t(locale, '创建机构', 'Create institution')}</h3><p>{t(locale, '创建者自动成为机构 Owner。', 'The creator becomes the institution owner.')}</p><input value={schoolName} onChange={(e) => setSchoolName(e.target.value)} placeholder={t(locale, '机构名称', 'Institution name')} /><button className="primary-button" type="button" disabled={busy || !schoolName.trim()} onClick={() => void run(() => onCreateInstitution(schoolName.trim()))}><Plus size={16} />{t(locale, '创建', 'Create')}</button></section>
      <section className="workspace-card"><div className="card-icon mint"><School /></div><h3>{t(locale, '申请加入', 'Request to join')}</h3><p>{t(locale, '输入机构管理员提供的学校代码。', 'Enter the institution code provided by an administrator.')}</p><input value={schoolCode} onChange={(e) => setSchoolCode(e.target.value.toUpperCase())} placeholder="SCH-XXXXXXXX" /><button className="primary-button" type="button" disabled={busy || !schoolCode.trim()} onClick={() => void run(() => onRequestJoin(schoolCode.trim()))}><UserCheck size={16} />{t(locale, '发送申请', 'Send request')}</button></section>
      <section className="workspace-card"><div className="card-icon gold"><KeyRound /></div><h3>{t(locale, '接受邀请', 'Accept invitation')}</h3><p>{t(locale, '邀请可同时预分配班级。', 'An invitation can include class assignments.')}</p><input value={invite} onChange={(e) => setInvite(e.target.value)} placeholder={t(locale, '邀请令牌', 'Invitation token')} /><button className="primary-button" type="button" disabled={busy || !invite.trim()} onClick={() => void run(() => onAcceptInvitation(invite.trim()))}><Check size={16} />{t(locale, '接受', 'Accept')}</button></section>
    </div>
    <Feedback text={message} />
  </div>;
}

export function InstitutionHome({
  locale, token, workspace, institutions, onSelectInstitution, onRefresh,
}: {
  locale: Locale; token: string; workspace: TeacherWorkspace; institutions: InstitutionSummary[]; onSelectInstitution: (id: string) => void; onRefresh: () => Promise<void>;
}) {
  const [name, setName] = useState(workspace.institution.name);
  const [message, setMessage] = useState('');
  useEffect(() => setName(workspace.institution.name), [workspace.institution.name]);
  const draftCount = workspace.evidence.filter((e) => e.publishState === 'draft').length;
  const readyCount = workspace.evidence.filter((e) => e.publishState === 'ready').length;
  const openActions = workspace.parentActions.filter((a) => a.status === 'open').length;
  const recentSessions = workspace.sessions.slice(0, 6);
  const saveName = async () => {
    setMessage('');
    try { await api.updateInstitution(token, workspace.institution.id, name.trim()); await onRefresh(); setMessage(t(locale, '机构名称已更新。', 'Institution name updated.')); }
    catch (e) { setMessage(e instanceof Error ? e.message : String(e)); }
  };
  return <div className="workspace-stack">
    <PageHeading
      eyebrow={t(locale, '机构工作区', 'Institution workspace')}
      title={workspace.institution.name}
      detail={`${workspace.institution.code} · ${workspace.institution.role}`}
      action={<InstitutionPicker locale={locale} institutions={institutions} activeId={workspace.institution.id} onSelect={onSelectInstitution} />}
    />
    <div className="metric-grid four">
      <Stat label={t(locale, '班级', 'Classes')} value={workspace.classes.length} hint={t(locale, '当前可访问', 'Currently accessible')} />
      <Stat label={t(locale, '学生', 'Students')} value={workspace.students.length} hint={t(locale, '当前权限范围', 'Within your scope')} />
      <Stat label={t(locale, '待处理', 'Pending')} value={workspace.joinRequests.length + readyCount} hint={t(locale, '加入申请 + 待发布', 'Join requests + ready evidence')} />
      <Stat label={t(locale, '家庭行动', 'Parent actions')} value={openActions} hint={t(locale, '未完成', 'Open')} />
    </div>
    <div className="workspace-grid two">
      <section className="workspace-card">
        <div className="section-title"><Activity size={19} /><div><h3>{t(locale, '运营状态', 'Operational status')}</h3><p>{t(locale, '真实数据库中的当前工作状态。', 'Current state from the live institution database.')}</p></div></div>
        <div className="compact-list">
          <div><span><strong>{t(locale, '成长草稿', 'Evidence drafts')}</strong><small>{t(locale, '尚未对家长发布', 'Not published to parents')}</small></span><b>{draftCount}</b></div>
          <div><span><strong>{t(locale, '待发布成长记录', 'Ready to publish')}</strong><small>{t(locale, '教师已完成，等待发布', 'Prepared and awaiting publication')}</small></span><b>{readyCount}</b></div>
          <div><span><strong>{t(locale, '最近课堂记录', 'Saved class sessions')}</strong><small>{t(locale, '最近100条范围内', 'Within latest 100')}</small></span><b>{workspace.sessions.length}</b></div>
          <div><span><strong>{t(locale, '学校人员', 'Staff')}</strong><small>{workspace.canManage ? t(locale, '可管理', 'Management enabled') : t(locale, '仅查看自己的权限范围', 'Scoped teacher access')}</small></span><b>{workspace.canManage ? workspace.staff.length : '—'}</b></div>
        </div>
      </section>
      <section className="workspace-card">
        <div className="section-title"><History size={19} /><div><h3>{t(locale, '最近课堂', 'Recent sessions')}</h3><p>{t(locale, '快速确认近期录入是否完整。', 'Quickly confirm recent classroom entry activity.')}</p></div></div>
        <div className="compact-list">{recentSessions.map((session) => <div key={session.id}><span><strong>{session.date} · {session.className}</strong><small>{session.topic || t(locale, '未填写主题', 'No topic')} · {session.rowCount} {t(locale, '名学生', 'students')}</small></span><small>{statusLabel(locale, 'present')} {session.counts.present}</small></div>)}{recentSessions.length === 0 ? <small>{t(locale, '还没有课堂记录。', 'No sessions yet.')}</small> : null}</div>
      </section>
    </div>
    {workspace.canManage ? <section className="workspace-card operational-setting-card"><div className="section-title"><Pencil size={19} /><div><h3>{t(locale, '机构基本信息', 'Institution settings')}</h3><p>{t(locale, '机构代码保持稳定；名称可由 Owner/Admin 更新。', 'Institution code remains stable; owners/admins may update the name.')}</p></div></div><div className="inline-add"><input value={name} onChange={(e) => setName(e.target.value)} /><button type="button" className="primary-button" disabled={!name.trim() || name.trim() === workspace.institution.name} onClick={() => void saveName()}><Save size={15} />{t(locale, '保存名称', 'Save name')}</button></div><Feedback text={message} /></section> : null}
  </div>;
}

export function ClassesView({ locale, token, workspace, onRefresh }: { locale: Locale; token: string; workspace: TeacherWorkspace; onRefresh: () => Promise<void> }) {
  const [search, setSearch] = useState('');
  const [selectedId, setSelectedId] = useState(workspace.classes[0]?.id ?? '');
  const selected = workspace.classes.find((item) => item.id === selectedId) ?? workspace.classes[0] ?? null;
  const [form, setForm] = useState({ name: '', code: '', gradeLabel: '', termLabel: '' });
  const [edit, setEdit] = useState({ name: '', code: '', gradeLabel: '', termLabel: '' });
  const [message, setMessage] = useState('');
  useEffect(() => {
    if (!selected && workspace.classes[0]) setSelectedId(workspace.classes[0].id);
    if (selected) setEdit({ name: selected.name, code: selected.code, gradeLabel: selected.gradeLabel, termLabel: selected.termLabel });
  }, [selected?.id, workspace.classes]);
  const filtered = workspace.classes.filter((c) => `${c.name} ${c.code} ${c.gradeLabel}`.toLowerCase().includes(search.toLowerCase()));
  const roster = selected ? workspace.students.filter((s) => selected.studentIds.includes(s.id)) : [];
  const available = selected ? workspace.students.filter((s) => !selected.studentIds.includes(s.id)) : [];
  const run = async (fn: () => Promise<unknown>, ok: string) => { setMessage(''); try { await fn(); await onRefresh(); setMessage(ok); } catch (e) { setMessage(e instanceof Error ? e.message : String(e)); } };
  const create = async (e: FormEvent) => { e.preventDefault(); if (!form.name.trim()) return; await run(() => api.createClass(token, workspace.institution.id, form), t(locale, '班级已创建。', 'Class created.')); setForm({ name: '', code: '', gradeLabel: '', termLabel: '' }); };
  return <div className="workspace-stack">
    <PageHeading eyebrow={t(locale, '班级运营', 'Class operations')} title={t(locale, '班级、名册与教师权限的核心单位', 'Classes are the core operational unit')} detail={t(locale, '班级名册来自机构学生数据库；教师访问由管理员明确分配。', 'Rosters come from the institution student database; teacher access is explicitly assigned.')} />
    <div className="workspace-grid class-layout">
      <section className="workspace-card class-sidebar-card">
        <div className="search-box"><Search size={15} /><input value={search} onChange={(e) => setSearch(e.target.value)} placeholder={t(locale, '搜索班级', 'Search classes')} /></div>
        <div className="choice-list">{filtered.map((c) => <button type="button" className={selected?.id === c.id ? 'active' : ''} key={c.id} onClick={() => setSelectedId(c.id)}><strong>{c.name}</strong><span>{c.code || '—'} · {c.studentIds.length} {t(locale, '名学生', 'students')}</span></button>)}{filtered.length === 0 ? <small>{t(locale, '没有匹配班级。', 'No matching classes.')}</small> : null}</div>
      </section>
      <section className="workspace-card">
        {selected ? <>
          <div className="section-title"><GraduationCap size={19} /><div><h3>{selected.name}</h3><p>{selected.code || t(locale, '未设置班级代码', 'No class code')} · {selected.gradeLabel || '—'} · {selected.termLabel || '—'}</p></div></div>
          {workspace.canManage ? <div className="form-grid two operational-form"><label><span>{t(locale, '班级名称', 'Class name')}</span><input value={edit.name} onChange={(e) => setEdit({ ...edit, name: e.target.value })} /></label><label><span>{t(locale, '班级代码', 'Class code')}</span><input value={edit.code} onChange={(e) => setEdit({ ...edit, code: e.target.value })} /></label><label><span>{t(locale, '年级/级别', 'Grade / level')}</span><input value={edit.gradeLabel} onChange={(e) => setEdit({ ...edit, gradeLabel: e.target.value })} /></label><label><span>{t(locale, '学期/周期', 'Term / period')}</span><input value={edit.termLabel} onChange={(e) => setEdit({ ...edit, termLabel: e.target.value })} /></label><div className="form-actions"><button type="button" className="primary-button compact" onClick={() => void run(() => api.updateClass(token, workspace.institution.id, selected.id, edit), t(locale, '班级已更新。', 'Class updated.'))}><Save size={14} />{t(locale, '保存', 'Save')}</button><button type="button" className="danger-button compact" onClick={() => { if (confirm(t(locale, `归档班级“${selected.name}”？学生记录不会删除。`, `Archive “${selected.name}”? Student records will not be deleted.`))) void run(() => api.updateClass(token, workspace.institution.id, selected.id, { status: 'archived' }), t(locale, '班级已归档。', 'Class archived.')); }}><Trash2 size={14} />{t(locale, '归档', 'Archive')}</button></div></div> : null}
          <div className="section-divider" />
          <h4>{t(locale, '班级名册', 'Class roster')} · {roster.length}</h4>
          <div className="roster-list">{roster.map((student) => <div className="roster-row" key={student.id}><div className="student-dot">{student.displayName.slice(0, 1)}</div><span><strong>{student.displayName}</strong><small>{student.studentCode || t(locale, '无学生代码', 'No student code')}</small></span>{workspace.canManage ? <button type="button" className="text-danger" onClick={() => void run(() => api.removeStudentFromClass(token, workspace.institution.id, selected.id, student.id), t(locale, '已从班级移除。', 'Removed from class.'))}>{t(locale, '移除', 'Remove')}</button> : null}</div>)}{roster.length === 0 ? <small>{t(locale, '班级暂无学生。', 'No students in this class.')}</small> : null}</div>
          {workspace.canManage && available.length ? <div className="inline-add"><select defaultValue="" onChange={(e) => { const value = e.target.value; if (value) void run(() => api.addStudentToClass(token, workspace.institution.id, selected.id, value), t(locale, '学生已加入班级。', 'Student added to class.')); e.currentTarget.value = ''; }}><option value="">{t(locale, '添加现有学生…', 'Add existing student…')}</option>{available.map((s) => <option key={s.id} value={s.id}>{s.displayName}</option>)}</select></div> : null}
        </> : <EmptyState title={t(locale, '暂无班级', 'No classes yet')} detail={workspace.canManage ? t(locale, '使用右侧/下方表单创建第一个班级。', 'Create the first class using the form.') : t(locale, '管理员尚未为你分配班级。', 'An administrator has not assigned a class to you yet.')} />}
      </section>
      {workspace.canManage ? <section className="workspace-card"><div className="section-title"><Plus size={19} /><div><h3>{t(locale, '创建班级', 'Create class')}</h3><p>{t(locale, '班级代码、级别和周期可后续修改。', 'Code, level and period can be edited later.')}</p></div></div><form className="form-grid" onSubmit={(e) => void create(e)}><label><span>{t(locale, '班级名称', 'Class name')}</span><input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} required /></label><div className="form-grid two"><label><span>{t(locale, '代码', 'Code')}</span><input value={form.code} onChange={(e) => setForm({ ...form, code: e.target.value })} /></label><label><span>{t(locale, '年级/级别', 'Grade / level')}</span><input value={form.gradeLabel} onChange={(e) => setForm({ ...form, gradeLabel: e.target.value })} /></label></div><label><span>{t(locale, '学期/周期', 'Term / period')}</span><input value={form.termLabel} onChange={(e) => setForm({ ...form, termLabel: e.target.value })} /></label><button className="primary-button" type="submit"><Plus size={15} />{t(locale, '创建班级', 'Create class')}</button></form></section> : null}
    </div>
    <Feedback text={message} />
  </div>;
}

export function StudentsView({ locale, token, workspace, onRefresh }: { locale: Locale; token: string; workspace: TeacherWorkspace; onRefresh: () => Promise<void> }) {
  const [search, setSearch] = useState('');
  const [selectedId, setSelectedId] = useState(workspace.students[0]?.id ?? '');
  const selected = workspace.students.find((s) => s.id === selectedId) ?? workspace.students[0] ?? null;
  const blank = { studentCode: '', firstName: '', lastName: '', preferredName: '', chineseName: '', classIds: [] as string[] };
  const [createForm, setCreateForm] = useState(blank);
  const [editForm, setEditForm] = useState(blank);
  const [claimCode, setClaimCode] = useState('');
  const [message, setMessage] = useState('');
  useEffect(() => {
    if (selected) setEditForm({ studentCode: selected.studentCode, firstName: selected.firstName, lastName: selected.lastName, preferredName: selected.preferredName, chineseName: selected.chineseName, classIds: selected.classes.map((c) => c.id) });
  }, [selected?.id, workspace.students]);
  const visible = workspace.students.filter((s) => `${s.displayName} ${s.chineseName} ${s.studentCode}`.toLowerCase().includes(search.toLowerCase()));
  const claims = selected ? workspace.childClaims.filter((c) => c.studentId === selected.id) : [];
  const run = async (fn: () => Promise<unknown>, ok: string) => { setMessage(''); try { await fn(); await onRefresh(); setMessage(ok); } catch (e) { setMessage(e instanceof Error ? e.message : String(e)); } };
  const toggleClass = (ids: string[], id: string) => ids.includes(id) ? ids.filter((x) => x !== id) : [...ids, id];
  return <div className="workspace-stack">
    <PageHeading eyebrow={t(locale, '学生数据库', 'Student database')} title={t(locale, '一个学生记录，可加入多个班级', 'One student record, multiple class enrollments')} detail={t(locale, '家长关系与学生数据库分离。归档学生不会删除历史课堂、成长证据或家长关系。', 'Guardian links are separate from student records. Archiving does not delete historical sessions, evidence or relationships.')} />
    <div className="search-box wide"><Search size={15} /><input value={search} onChange={(e) => setSearch(e.target.value)} placeholder={t(locale, '按姓名或学生代码搜索', 'Search by name or student code')} /></div>
    <div className="student-database-grid">{visible.map((student) => <button key={student.id} type="button" className={`student-db-card selectable ${selected?.id === student.id ? 'active' : ''}`} onClick={() => { setSelectedId(student.id); setClaimCode(''); }}><div className="student-dot large">{student.displayName.slice(0, 1)}</div><div><h3>{student.displayName}</h3><p>{student.studentCode || t(locale, '无学生代码', 'No student code')} · {student.guardianCount} {t(locale, '位家长', 'guardians')}</p><div className="chip-row">{student.classes.map((c) => <span className="chip" key={c.id}>{c.name}</span>)}{student.classes.length === 0 ? <span className="chip neutral">{t(locale, '未分班', 'No class')}</span> : null}</div></div><ChevronRight size={17} /></button>)}</div>
    {selected ? <div className="workspace-grid two">
      <section className="workspace-card"><div className="section-title"><UserRound size={19} /><div><h3>{selected.displayName}</h3><p>{selected.institutionName}</p></div></div>{workspace.canManage ? <><div className="form-grid two"><label><span>{t(locale, '中文名', 'Chinese name')}</span><input value={editForm.chineseName} onChange={(e) => setEditForm({ ...editForm, chineseName: e.target.value })} /></label><label><span>{t(locale, '常用名', 'Preferred name')}</span><input value={editForm.preferredName} onChange={(e) => setEditForm({ ...editForm, preferredName: e.target.value })} /></label><label><span>{t(locale, '英文名', 'English first name')}</span><input value={editForm.firstName} onChange={(e) => setEditForm({ ...editForm, firstName: e.target.value })} /></label><label><span>{t(locale, '英文姓', 'English last name')}</span><input value={editForm.lastName} onChange={(e) => setEditForm({ ...editForm, lastName: e.target.value })} /></label><label><span>{t(locale, '学生代码', 'Student code')}</span><input value={editForm.studentCode} onChange={(e) => setEditForm({ ...editForm, studentCode: e.target.value })} /></label></div><h4>{t(locale, '班级成员关系', 'Class enrollments')}</h4><div className="checkbox-grid">{workspace.classes.map((c) => <label key={c.id}><input type="checkbox" checked={editForm.classIds.includes(c.id)} onChange={() => setEditForm({ ...editForm, classIds: toggleClass(editForm.classIds, c.id) })} />{c.name}</label>)}</div><div className="form-actions"><button type="button" className="primary-button compact" onClick={() => void run(() => api.updateStudent(token, workspace.institution.id, selected.id, editForm), t(locale, '学生资料已保存。', 'Student record saved.'))}><Save size={14} />{t(locale, '保存资料', 'Save')}</button><button type="button" className="danger-button compact" onClick={() => { if (confirm(t(locale, `归档学生“${selected.displayName}”？历史记录会保留。`, `Archive “${selected.displayName}”? History will be retained.`))) void run(() => api.updateStudent(token, workspace.institution.id, selected.id, { status: 'archived' }), t(locale, '学生已归档。', 'Student archived.')); }}><Trash2 size={14} />{t(locale, '归档', 'Archive')}</button></div></> : <p>{t(locale, '你的教师账号可查看授权班级学生，但学生资料与家长关联由学校管理员管理。', 'Your teacher account can view students in assigned classes; student records and guardian linking are managed by administrators.')}</p>}</section>
      {workspace.canManage ? <section className="workspace-card"><div className="section-title"><Link2 size={19} /><div><h3>{t(locale, '家长关联', 'Guardian linking')}</h3><p>{t(locale, '生成一次性关联码交给对应家长。已使用/撤销/过期的码不会再次生效。', 'Issue a one-time claim code to the correct guardian. Used, revoked or expired codes cannot be reused.')}</p></div></div><div className="claim-code-box"><span>{t(locale, '家长人数', 'Linked guardians')}</span><strong>{selected.guardianCount}</strong><button type="button" onClick={() => void api.createChildClaim(token, selected.id).then((r) => { setClaimCode(r.code); return onRefresh(); }).catch((e) => setMessage(e instanceof Error ? e.message : String(e)))}><KeyRound size={14} />{t(locale, '生成新关联码', 'Generate claim code')}</button>{claimCode ? <><code>{claimCode}</code><button type="button" onClick={() => void navigator.clipboard?.writeText(claimCode)}><Copy size={13} />{t(locale, '复制', 'Copy')}</button></> : null}</div><div className="compact-list claim-history">{claims.map((claim) => <div key={claim.id}><span><strong>{activeClaim(claim) ? t(locale, '可用', 'Active') : claim.usedAt ? t(locale, '已使用', 'Used') : claim.revokedAt ? t(locale, '已撤销', 'Revoked') : t(locale, '已过期', 'Expired')}</strong><small>{t(locale, '创建', 'Created')} {timestamp(claim.createdAt)} · {t(locale, '过期', 'Expires')} {timestamp(claim.expiresAt)}</small></span>{activeClaim(claim) ? <button type="button" className="text-danger" onClick={() => void run(() => api.revokeChildClaim(token, selected.id, claim.id), t(locale, '关联码已撤销。', 'Claim code revoked.'))}>{t(locale, '撤销', 'Revoke')}</button> : null}</div>)}{claims.length === 0 ? <small>{t(locale, '尚未生成关联码。', 'No claim codes issued yet.')}</small> : null}</div></section> : null}
    </div> : null}
    {workspace.canManage ? <section className="workspace-card"><div className="section-title"><Plus size={19} /><div><h3>{t(locale, '添加学生', 'Add student')}</h3><p>{t(locale, '所有字段均可为空；系统 UUID 是唯一保证标识。建议至少填写一个便于识别的姓名。', 'All entered fields are optional; the system UUID is the guaranteed identifier. At least one recognizable name is recommended.')}</p></div></div><form className="form-grid" onSubmit={(e) => { e.preventDefault(); void run(() => api.createStudent(token, workspace.institution.id, createForm), t(locale, '学生已创建。', 'Student created.')).then(() => setCreateForm(blank)); }}><div className="form-grid two"><input value={createForm.chineseName} onChange={(e) => setCreateForm({ ...createForm, chineseName: e.target.value })} placeholder={t(locale, '中文名', 'Chinese name')} /><input value={createForm.preferredName} onChange={(e) => setCreateForm({ ...createForm, preferredName: e.target.value })} placeholder={t(locale, '常用名', 'Preferred name')} /><input value={createForm.firstName} onChange={(e) => setCreateForm({ ...createForm, firstName: e.target.value })} placeholder={t(locale, '英文名', 'English first name')} /><input value={createForm.lastName} onChange={(e) => setCreateForm({ ...createForm, lastName: e.target.value })} placeholder={t(locale, '英文姓', 'English last name')} /><input value={createForm.studentCode} onChange={(e) => setCreateForm({ ...createForm, studentCode: e.target.value })} placeholder={t(locale, '学生代码（可选）', 'Student code (optional)')} /></div><div className="checkbox-grid">{workspace.classes.map((c) => <label key={c.id}><input type="checkbox" checked={createForm.classIds.includes(c.id)} onChange={() => setCreateForm({ ...createForm, classIds: toggleClass(createForm.classIds, c.id) })} />{c.name}</label>)}</div><button className="primary-button" type="submit"><Plus size={15} />{t(locale, '创建学生', 'Create student')}</button></form></section> : null}
    <Feedback text={message} />
  </div>;
}

function makeRows(students: StudentSummary[]): AttendanceInput[] {
  return students.map((s) => ({ studentId: s.id, status: 'present', participation: 3, confidence: 3, homework: 'done', note: '' }));
}

export function SessionView({ locale, token, workspace, onRefresh }: { locale: Locale; token: string; workspace: TeacherWorkspace; onRefresh: () => Promise<void> }) {
  const [classId, setClassId] = useState(workspace.classes[0]?.id ?? '');
  const selectedClass = workspace.classes.find((c) => c.id === classId) ?? workspace.classes[0] ?? null;
  const classStudents = selectedClass ? workspace.students.filter((s) => selectedClass.studentIds.includes(s.id)) : [];
  const [date, setDate] = useState(today());
  const [topic, setTopic] = useState('');
  const [rows, setRows] = useState<AttendanceInput[]>(makeRows(classStudents));
  const [message, setMessage] = useState('');
  const sessions = workspace.sessions.filter((s) => !selectedClass || s.classId === selectedClass.id);
  useEffect(() => { setRows(makeRows(classStudents)); }, [selectedClass?.id, workspace.revision]);
  const patch = (studentId: string, next: Partial<AttendanceInput>) => setRows((items) => items.map((r) => r.studentId === studentId ? { ...r, ...next } : r));
  const loadSession = async (id: string) => {
    try {
      const detail = await api.classSession(token, id);
      setClassId(detail.classId); setDate(detail.date); setTopic(detail.topic);
      setRows(detail.rows.map(({ displayName: _displayName, ...row }) => row));
      setMessage(t(locale, '已载入历史课堂，可直接修改并再次保存。', 'Historical session loaded. Edit and save to correct it.'));
    } catch (e) { setMessage(e instanceof Error ? e.message : String(e)); }
  };
  const save = async () => {
    if (!selectedClass) return;
    setMessage('');
    try { await api.saveClassSession(token, { institutionId: workspace.institution.id, classId: selectedClass.id, date, topic, rows }); await onRefresh(); setMessage(t(locale, '课堂记录已同步。', 'Session synchronized.')); }
    catch (e) { setMessage(e instanceof Error ? e.message : String(e)); }
  };
  return <div className="workspace-stack">
    <PageHeading eyebrow={t(locale, '课堂运营', 'Classroom operations')} title={t(locale, '课堂记录与历史修正', 'Session entry and historical correction')} detail={t(locale, '同一班级同一天再次保存会更新原课堂，不会重复创建。', 'Saving the same class/date updates the original session instead of duplicating it.')} />
    <section className="workspace-card">
      <div className="session-controls"><label><span>{t(locale, '班级', 'Class')}</span><select value={selectedClass?.id ?? ''} onChange={(e) => setClassId(e.target.value)}>{workspace.classes.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}</select></label><label><span>{t(locale, '日期', 'Date')}</span><input type="date" value={date} onChange={(e) => setDate(e.target.value)} /></label><label className="grow"><span>{t(locale, '课堂主题', 'Topic')}</span><input value={topic} onChange={(e) => setTopic(e.target.value)} placeholder={t(locale, '本节课内容', 'Lesson topic')} /></label></div>
      {!selectedClass ? <EmptyState title={t(locale, '没有可用班级', 'No accessible class')} detail={t(locale, '请联系管理员分配班级。', 'Ask an administrator to assign a class.')} /> : <>
        <div className="session-toolbar"><button type="button" className="secondary-button compact" onClick={() => setRows((items) => items.map((r) => ({ ...r, status: 'present' })))}><CheckCircle2 size={14} />{t(locale, '全部出席', 'Mark all present')}</button><span>{classStudents.length} {t(locale, '名学生', 'students')}</span></div>
        <div className="session-roster"><div className="session-row-v23 session-head"><strong>{t(locale, '学生', 'Student')}</strong><span>{t(locale, '出勤', 'Attendance')}</span><span>{t(locale, '参与', 'Participation')}</span><span>{t(locale, '自信', 'Confidence')}</span><span>{t(locale, '作业', 'Homework')}</span><span>{t(locale, '备注', 'Note')}</span></div>{classStudents.map((student) => { const row = rows.find((r) => r.studentId === student.id) ?? makeRows([student])[0]; return <div className="session-row-v23" key={student.id}><strong>{student.displayName}</strong><select value={row.status} onChange={(e) => patch(student.id, { status: e.target.value as AttendanceStatus })}><option value="present">{t(locale, '出席', 'Present')}</option><option value="late">{t(locale, '迟到', 'Late')}</option><option value="absent">{t(locale, '缺席', 'Absent')}</option><option value="excused">{t(locale, '请假', 'Excused')}</option></select><select value={row.participation} onChange={(e) => patch(student.id, { participation: Number(e.target.value) })}>{[1,2,3,4,5].map((n) => <option key={n}>{n}</option>)}</select><select value={row.confidence} onChange={(e) => patch(student.id, { confidence: Number(e.target.value) })}>{[1,2,3,4,5].map((n) => <option key={n}>{n}</option>)}</select><select value={row.homework} onChange={(e) => patch(student.id, { homework: e.target.value as AttendanceInput['homework'] })}><option value="done">{t(locale, '完成', 'Done')}</option><option value="partial">{t(locale, '部分', 'Partial')}</option><option value="missing">{t(locale, '未完成', 'Missing')}</option></select><input value={row.note} onChange={(e) => patch(student.id, { note: e.target.value })} /></div>; })}</div>
        <div className="form-actions"><button type="button" className="primary-button" onClick={() => void save()}><Save size={15} />{t(locale, '保存并同步', 'Save & sync')}</button></div>
      </>}
    </section>
    <section className="workspace-card"><div className="section-title"><History size={19} /><div><h3>{t(locale, '课堂历史', 'Session history')}</h3><p>{t(locale, '选择历史课堂后可修正出勤、参与、自信、作业与备注。', 'Open a saved session to correct attendance, participation, confidence, homework or notes.')}</p></div></div><div className="compact-list">{sessions.slice(0, 30).map((s) => <div key={s.id}><span><strong>{s.date} · {s.className}</strong><small>{s.topic || t(locale, '无主题', 'No topic')} · {s.rowCount} {t(locale, '条记录', 'rows')}</small></span><button type="button" className="secondary-button compact" onClick={() => void loadSession(s.id)}>{t(locale, '打开修正', 'Open')}</button></div>)}{sessions.length === 0 ? <small>{t(locale, '暂无历史课堂。', 'No saved sessions yet.')}</small> : null}</div></section>
    <Feedback text={message} />
  </div>;
}

export function EvidenceView({ locale, token, workspace, onRefresh }: { locale: Locale; token: string; workspace: TeacherWorkspace; onRefresh: () => Promise<void> }) {
  const [search, setSearch] = useState('');
  const [studentId, setStudentId] = useState(workspace.students[0]?.id ?? '');
  const student = workspace.students.find((s) => s.id === studentId) ?? workspace.students[0] ?? null;
  const allowedClasses = student ? workspace.classes.filter((c) => c.studentIds.includes(student.id)) : [];
  const [classId, setClassId] = useState(allowedClasses[0]?.id ?? '');
  const [kind, setKind] = useState<EvidenceKind>('observation');
  const [date, setDate] = useState(today());
  const [observation, setObservation] = useState('');
  const [interpretation, setInterpretation] = useState('');
  const [selectedDimensions, setSelectedDimensions] = useState<GrowthDimensionKey[]>([]);
  const [visibility, setVisibility] = useState<Visibility>('teacher_only');
  const [publishState, setPublishState] = useState<PublishState>('draft');
  const [editing, setEditing] = useState<string | null>(null);
  const [message, setMessage] = useState('');
  const [report, setReport] = useState<StudentReport | null>(null);
  const [action, setAction] = useState({ title: '', detail: '', dueDate: '' });
  useEffect(() => { if (allowedClasses.length && !allowedClasses.some((c) => c.id === classId)) setClassId(allowedClasses[0].id); }, [studentId, workspace.revision]);
  const filtered = workspace.evidence.filter((e) => `${e.observation} ${e.interpretation} ${e.teacherName} ${e.className}`.toLowerCase().includes(search.toLowerCase()));
  const reset = () => { setEditing(null); setKind('observation'); setDate(today()); setObservation(''); setInterpretation(''); setSelectedDimensions([]); setVisibility('teacher_only'); setPublishState('draft'); };
  const openEvidence = (e: EvidenceRecord) => { setEditing(e.id); setStudentId(e.studentId); setClassId(e.classId ?? ''); setKind(e.kind); setDate(e.date); setObservation(e.observation); setInterpretation(e.interpretation); setSelectedDimensions(e.dimensions); setVisibility(e.visibility); setPublishState(e.publishState); window.scrollTo({ top: 0, behavior: 'smooth' }); };
  const save = async () => {
    if (!student || !classId || !observation.trim()) return;
    setMessage('');
    try {
      const payload = { date, kind, observation: observation.trim(), interpretation: interpretation.trim(), dimensions: selectedDimensions, visibility, publishState };
      if (editing) await api.updateEvidence(token, editing, payload);
      else await api.addEvidence(token, { institutionId: workspace.institution.id, classId, studentId: student.id, ...payload });
      await onRefresh(); reset(); setMessage(t(locale, editing ? '成长记录已更新。' : '成长记录已保存。', editing ? 'Evidence updated.' : 'Evidence saved.'));
    } catch (e) { setMessage(e instanceof Error ? e.message : String(e)); }
  };
  const toggleDimension = (d: GrowthDimensionKey) => setSelectedDimensions((items) => items.includes(d) ? items.filter((x) => x !== d) : [...items, d]);
  const loadReport = async (period: ReportPeriod) => { if (!student) return; try { setReport(await api.teacherReport(token, workspace.institution.id, student.id, period)); } catch (e) { setMessage(e instanceof Error ? e.message : String(e)); } };
  const createAction = async () => { if (!student || !classId || !action.title.trim()) return; try { await api.addParentAction(token, { institutionId: workspace.institution.id, classId, studentId: student.id, title: action.title.trim(), detail: action.detail.trim(), dueDate: action.dueDate || undefined }); setAction({ title: '', detail: '', dueDate: '' }); await onRefresh(); setMessage(t(locale, '家庭行动已同步给家长。', 'Parent action synchronized.')); } catch (e) { setMessage(e instanceof Error ? e.message : String(e)); } };
  return <div className="workspace-stack">
    <PageHeading eyebrow={t(locale, '成长工作台', 'Growth workspace')} title={t(locale, '证据 → 解读 → 发布 → 家庭行动', 'Evidence → interpretation → publish → parent action')} detail={t(locale, '成长报告只汇总真实记录数量和课堂数据，不生成虚构分数。', 'Reports summarize sourced evidence and classroom data; they do not fabricate growth scores.')} />
    <div className="workspace-grid two evidence-editor-grid">
      <section className="workspace-card"><div className="section-title"><Sparkles size={19} /><div><h3>{editing ? t(locale, '编辑成长记录', 'Edit evidence') : t(locale, '记录成长证据', 'Record evidence')}</h3><p>{t(locale, '里程碑也是证据类型，可独立显示在家长端。', 'Milestones are evidence records and appear separately for parents.')}</p></div></div><div className="form-grid"><div className="form-grid two"><label><span>{t(locale, '学生', 'Student')}</span><select value={student?.id ?? ''} onChange={(e) => setStudentId(e.target.value)} disabled={Boolean(editing)}>{workspace.students.map((s) => <option key={s.id} value={s.id}>{s.displayName}</option>)}</select></label><label><span>{t(locale, '班级', 'Class')}</span><select value={classId} onChange={(e) => setClassId(e.target.value)} disabled={Boolean(editing)}>{allowedClasses.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}</select></label><label><span>{t(locale, '日期', 'Date')}</span><input type="date" value={date} onChange={(e) => setDate(e.target.value)} /></label><label><span>{t(locale, '类型', 'Kind')}</span><select value={kind} onChange={(e) => setKind(e.target.value as EvidenceKind)}>{evidenceKinds.map((k) => <option key={k} value={k}>{k}</option>)}</select></label></div><label><span>{t(locale, '观察/事实', 'Observation / fact')}</span><textarea value={observation} onChange={(e) => setObservation(e.target.value)} rows={4} /></label><label><span>{t(locale, '教师解读', 'Teacher interpretation')}</span><textarea value={interpretation} onChange={(e) => setInterpretation(e.target.value)} rows={3} /></label><div><span className="field-label">{t(locale, '成长维度', 'Growth dimensions')}</span><div className="checkbox-grid">{dimensions.map((d) => <label key={d}><input type="checkbox" checked={selectedDimensions.includes(d)} onChange={() => toggleDimension(d)} />{dimensionLabels[d][locale]}</label>)}</div></div><div className="form-grid two"><label><span>{t(locale, '可见范围', 'Visibility')}</span><select value={visibility} onChange={(e) => setVisibility(e.target.value as Visibility)}><option value="teacher_only">teacher_only</option><option value="parent_visible">parent_visible</option><option value="report">report</option></select></label><label><span>{t(locale, '发布状态', 'Publish state')}</span><select value={publishState} onChange={(e) => setPublishState(e.target.value as PublishState)}><option value="draft">draft</option><option value="ready">ready</option><option value="published">published</option></select></label></div><div className="form-actions"><button type="button" className="primary-button" disabled={!student || !classId || !observation.trim()} onClick={() => void save()}><Save size={15} />{editing ? t(locale, '保存修改', 'Save changes') : t(locale, '保存记录', 'Save evidence')}</button>{editing ? <button type="button" className="secondary-button" onClick={reset}><X size={15} />{t(locale, '取消编辑', 'Cancel')}</button> : null}</div></div></section>
      <section className="workspace-card"><div className="section-title"><ListChecks size={19} /><div><h3>{t(locale, '家庭小行动', 'Parent action')}</h3><p>{t(locale, '给当前学生一个清晰、可完成的家庭任务。', 'Give the selected student a clear, completable home action.')}</p></div></div><div className="form-grid"><input value={action.title} onChange={(e) => setAction({ ...action, title: e.target.value })} placeholder={t(locale, '例如：本周朗读故事三次', 'e.g. Read the story aloud three times')} /><textarea rows={3} value={action.detail} onChange={(e) => setAction({ ...action, detail: e.target.value })} placeholder={t(locale, '说明（可选）', 'Details (optional)')} /><input type="date" value={action.dueDate} onChange={(e) => setAction({ ...action, dueDate: e.target.value })} /><button type="button" className="primary-button" disabled={!student || !classId || !action.title.trim()} onClick={() => void createAction()}><Plus size={15} />{t(locale, '发送到家长端', 'Send to parent')}</button></div><div className="section-divider" /><div className="section-title"><FileText size={19} /><div><h3>{t(locale, '报告预览', 'Report preview')}</h3><p>{student?.displayName ?? '—'}</p></div></div><div className="segmented report-periods">{(['week','month','term','all'] as ReportPeriod[]).map((p) => <button type="button" key={p} className={report?.period === p ? 'active' : ''} onClick={() => void loadReport(p)}>{p}</button>)}</div>{report ? <ReportBody locale={locale} report={report} compact /> : <small>{t(locale, '选择周期生成可追溯报告预览。', 'Choose a period to generate a traceable report preview.')}</small>}</section>
    </div>
    <section className="workspace-card"><div className="section-title"><Search size={19} /><div><h3>{t(locale, '成长记录库', 'Evidence library')}</h3><p>{t(locale, '点击记录可重新编辑。', 'Open a record to edit it.')}</p></div></div><div className="search-box wide"><Search size={14} /><input value={search} onChange={(e) => setSearch(e.target.value)} placeholder={t(locale, '搜索观察、解读、教师或班级', 'Search observation, interpretation, teacher or class')} /></div><div className="evidence-list">{filtered.map((e) => <div className="evidence-row" key={e.id}><div><span>{e.date} · {e.kind} · {e.className}</span><strong>{workspace.students.find((s) => s.id === e.studentId)?.displayName ?? e.studentId}</strong><p>{e.observation}</p><small>{e.teacherName} · {e.visibility} · {e.publishState}</small></div><div className="evidence-actions"><button type="button" onClick={() => openEvidence(e)}>{t(locale, '编辑', 'Edit')}</button>{e.publishState !== 'published' ? <button type="button" className="publish" onClick={() => void api.updateEvidence(token, e.id, { publishState: 'published', visibility: e.visibility === 'teacher_only' ? 'parent_visible' : e.visibility }).then(onRefresh).catch((err) => setMessage(err instanceof Error ? err.message : String(err)))}>{t(locale, '发布', 'Publish')}</button> : null}</div></div>)}{filtered.length === 0 ? <small>{t(locale, '暂无匹配记录。', 'No matching evidence.')}</small> : null}</div></section>
    <Feedback text={message} />
  </div>;
}

export function StaffView({ locale, token, workspace, onRefresh }: { locale: Locale; token: string; workspace: TeacherWorkspace; onRefresh: () => Promise<void> }) {
  const [inviteEmail, setInviteEmail] = useState('');
  const [inviteRole, setInviteRole] = useState<'teacher' | 'admin'>('teacher');
  const [inviteClasses, setInviteClasses] = useState<string[]>([]);
  const [inviteLink, setInviteLink] = useState('');
  const [audit, setAudit] = useState<AuditEvent[]>([]);
  const [message, setMessage] = useState('');
  const run = async (fn: () => Promise<unknown>, ok: string) => { setMessage(''); try { await fn(); await onRefresh(); setMessage(ok); } catch (e) { setMessage(e instanceof Error ? e.message : String(e)); } };
  if (!workspace.canManage) return <div className="workspace-stack"><PageHeading eyebrow={t(locale, '管理', 'Administration')} title={t(locale, '机构管理仅限 Owner / Admin', 'Institution administration is Owner/Admin only')} detail={t(locale, '普通教师仍可在已分配班级中完成课堂与成长记录。', 'Teachers can continue classroom and growth work in their assigned classes.')} /><EmptyState title={t(locale, '没有管理权限', 'No administration permission')} detail={t(locale, '如需管理教师、班级授权或家长关联，请联系机构管理员。', 'Contact an institution administrator for staff, class-access, or guardian-link management.')} /></div>;
  const toggleInviteClass = (id: string) => setInviteClasses((items) => items.includes(id) ? items.filter((x) => x !== id) : [...items, id]);
  const createInvite = async () => {
    try {
      const result = await api.createTeacherInvitation(token, workspace.institution.id, { role: inviteRole, email: inviteEmail.trim() || undefined, classIds: inviteClasses });
      setInviteLink(`${window.location.origin}/teacher/?invite=${encodeURIComponent(result.token)}`); setInviteEmail(''); setInviteClasses([]); await onRefresh();
    } catch (e) { setMessage(e instanceof Error ? e.message : String(e)); }
  };
  const loadAudit = async () => { try { setAudit((await api.audit(token, workspace.institution.id, 100)).events); } catch (e) { setMessage(e instanceof Error ? e.message : String(e)); } };
  return <div className="workspace-stack">
    <PageHeading eyebrow={t(locale, '学校管理', 'Institution administration')} title={t(locale, '人员、权限与审计', 'Staff, access and audit')} detail={t(locale, '所有授权都绑定机构和班级；普通教师不会因注册账号自动获得学生访问权限。', 'All authorization is institution/class scoped; registering an account never grants student access automatically.')} />
    {workspace.joinRequests.length ? <section className="workspace-card attention-card"><div className="section-title"><UserCheck size={19} /><div><h3>{t(locale, '待处理加入申请', 'Pending join requests')}</h3><p>{t(locale, '核对申请人身份后批准或拒绝。', 'Verify the applicant before approving or rejecting.')}</p></div></div><div className="compact-list">{workspace.joinRequests.map((r) => <div key={r.id}><span><strong>{r.displayName}</strong><small>{r.email} · {timestamp(r.createdAt)}</small></span><div className="row-actions"><button type="button" className="primary-button compact" onClick={() => void run(() => api.approveJoinRequest(token, workspace.institution.id, r.id), t(locale, '已批准。', 'Approved.'))}>{t(locale, '批准', 'Approve')}</button><button type="button" className="secondary-button compact" onClick={() => void run(() => api.rejectJoinRequest(token, workspace.institution.id, r.id), t(locale, '已拒绝。', 'Rejected.'))}>{t(locale, '拒绝', 'Reject')}</button></div></div>)}</div></section> : null}
    <div className="workspace-grid two">
      <section className="workspace-card"><div className="section-title"><Plus size={19} /><div><h3>{t(locale, '邀请教师', 'Invite staff')}</h3><p>{t(locale, '可在邀请时预分配班级。邮箱留空则邀请链接可交给指定教师。', 'Pre-assign classes in the invitation. Leave email blank for a transferable invite link.')}</p></div></div><div className="form-grid"><input type="email" value={inviteEmail} onChange={(e) => setInviteEmail(e.target.value)} placeholder={t(locale, '指定邮箱（可选）', 'Email lock (optional)')} /><select value={inviteRole} onChange={(e) => setInviteRole(e.target.value as 'teacher' | 'admin')}><option value="teacher">teacher</option><option value="admin">admin</option></select><div className="checkbox-grid">{workspace.classes.map((c) => <label key={c.id}><input type="checkbox" checked={inviteClasses.includes(c.id)} onChange={() => toggleInviteClass(c.id)} />{c.name}</label>)}</div><button type="button" className="primary-button" onClick={() => void createInvite()}><KeyRound size={15} />{t(locale, '生成邀请', 'Create invitation')}</button>{inviteLink ? <div className="invite-link-box"><code>{inviteLink}</code><button type="button" onClick={() => void navigator.clipboard?.writeText(inviteLink)}><Copy size={13} />{t(locale, '复制链接', 'Copy link')}</button></div> : null}</div></section>
      <section className="workspace-card"><div className="section-title"><History size={19} /><div><h3>{t(locale, '邀请记录', 'Invitation history')}</h3><p>{t(locale, '未使用且未过期的邀请可立即撤销。', 'Unused unexpired invitations can be revoked immediately.')}</p></div></div><div className="compact-list">{workspace.invitations.slice(0, 30).map((invite) => <div key={invite.id}><span><strong>{invite.email || t(locale, '未绑定邮箱', 'Unbound email')} · {invite.role}</strong><small>{invite.usedAt ? t(locale, '已使用', 'Used') : invite.revokedAt ? t(locale, '已撤销', 'Revoked') : invite.expiresAt * 1000 < Date.now() ? t(locale, '已过期', 'Expired') : t(locale, '有效', 'Active')} · {timestamp(invite.createdAt)}</small></span>{!invite.usedAt && !invite.revokedAt && invite.expiresAt * 1000 > Date.now() ? <button type="button" className="text-danger" onClick={() => void run(() => api.revokeTeacherInvitation(token, workspace.institution.id, invite.id), t(locale, '邀请已撤销。', 'Invitation revoked.'))}>{t(locale, '撤销', 'Revoke')}</button> : null}</div>)}</div></section>
    </div>
    <section className="workspace-card"><div className="section-title"><UsersRound size={19} /><div><h3>{t(locale, '教师与角色', 'Staff and roles')}</h3><p>{t(locale, 'Owner 不可在此降级；Admin/Teacher 可调整角色或停用。', 'The owner cannot be downgraded here; Admin/Teacher memberships can be changed or disabled.')}</p></div></div><div className="operational-table staff-role-table"><div className="op-table-head"><span>{t(locale, '教师', 'Staff')}</span><span>{t(locale, '角色', 'Role')}</span><span>{t(locale, '状态', 'Status')}</span><span>{t(locale, '班级数', 'Classes')}</span></div>{workspace.staff.map((staff) => <div className="op-table-row" key={staff.id}><span><strong>{staff.displayName}</strong><small>{staff.email}</small></span><select value={staff.role} disabled={staff.role === 'owner'} onChange={(e) => void run(() => api.updateMembership(token, workspace.institution.id, staff.id, { role: e.target.value as 'teacher' | 'admin' }), t(locale, '角色已更新。', 'Role updated.'))}><option value="owner" disabled>owner</option><option value="admin">admin</option><option value="teacher">teacher</option></select><select value={staff.status} disabled={staff.role === 'owner'} onChange={(e) => void run(() => api.updateMembership(token, workspace.institution.id, staff.id, { status: e.target.value as 'active' | 'disabled' }), t(locale, '状态已更新。', 'Status updated.'))}><option value="active">active</option><option value="disabled">disabled</option></select><span>{staff.classIds.length}</span></div>)}</div></section>
    <section className="workspace-card"><div className="section-title"><ShieldCheck size={19} /><div><h3>{t(locale, '教师 ↔ 班级权限', 'Teacher ↔ class access')}</h3><p>{t(locale, '勾选即授权；取消即撤销。Owner/Admin 仍拥有机构级管理权限。', 'Check to grant; uncheck to revoke. Owners/Admins retain institution-level management rights.')}</p></div></div><div className="staff-table"><div className="staff-head"><span>{t(locale, '教师', 'Staff')}</span>{workspace.classes.map((c) => <span key={c.id}>{c.name}</span>)}</div>{workspace.staff.map((staff) => <div className="staff-row" key={staff.id}><span><strong>{staff.displayName}</strong><small>{staff.role}</small></span>{workspace.classes.map((c) => <label key={c.id}><input type="checkbox" checked={staff.classIds.includes(c.id)} disabled={staff.role === 'owner' || staff.status !== 'active'} onChange={() => void run(() => staff.classIds.includes(c.id) ? api.unassignTeacher(token, workspace.institution.id, c.id, staff.id) : api.assignTeacher(token, workspace.institution.id, c.id, staff.id), t(locale, '班级权限已更新。', 'Class access updated.'))} /></label>)}</div>)}</div></section>
    <section className="workspace-card"><div className="section-title"><ClipboardList size={19} /><div><h3>{t(locale, '审计记录', 'Audit trail')}</h3><p>{t(locale, '重要账号、权限、学生、课堂与成长记录变更均由后端记录。', 'Critical account, authorization, student, session and growth mutations are recorded by the backend.')}</p></div><button type="button" className="secondary-button compact" onClick={() => void loadAudit()}><RefreshCw size={13} />{t(locale, '载入最近100条', 'Load latest 100')}</button></div><div className="audit-list">{audit.map((item) => <div key={item.id}><span><strong>{item.action}</strong><small>{item.actorName || 'system'} · {timestamp(item.createdAt)}</small></span><code>{item.objectType || '—'} · {item.objectId || '—'}</code></div>)}{audit.length === 0 ? <small>{t(locale, '点击上方按钮载入审计记录。', 'Load the audit trail using the button above.')}</small> : null}</div></section>
    <Feedback text={message} />
  </div>;
}

export function ParentHomeView({ locale, token, detail, onClaim, onRefresh }: { locale: Locale; token: string; detail: ParentChildDetail | null; onClaim: (code: string) => Promise<void>; onRefresh: () => Promise<void> }) {
  const [code, setCode] = useState(''); const [busy, setBusy] = useState(false); const [message, setMessage] = useState('');
  const markDone = async (id: string) => { try { await api.updateParentAction(token, id, { status: 'done' }); await onRefresh(); } catch (e) { setMessage(e instanceof Error ? e.message : String(e)); } };
  return <div className="workspace-stack"><PageHeading eyebrow={t(locale, '家长首页', 'Parent home')} title={detail ? detail.child.displayName : t(locale, '添加第一个孩子', 'Link your first child')} detail={detail ? `${detail.child.institutionName} · ${detail.child.classes.map((c) => c.name).join(' / ') || t(locale, '尚未分班', 'No class yet')}` : t(locale, '孩子必须先由学校建立学生记录，然后由学校生成一次性关联码。', 'The institution creates the student record first, then issues a one-time child link code.')} />{detail ? <><div className="metric-grid four"><Stat label={t(locale, '学校', 'Institution')} value={detail.child.institutionName} /><Stat label={t(locale, '成长记录', 'Published evidence')} value={detail.evidence.length} /><Stat label={t(locale, '里程碑', 'Milestones')} value={detail.milestones.length} /><Stat label={t(locale, '出勤率', 'Attendance')} value={detail.attendanceSummary.rate == null ? '—' : `${detail.attendanceSummary.rate}%`} /></div><div className="workspace-grid two"><section className="workspace-card"><div className="section-title"><ListChecks size={19} /><div><h3>{t(locale, '家庭小行动', 'Parent actions')}</h3><p>{t(locale, '由教师发布，可在完成后直接标记。', 'Published by teachers; mark complete when done.')}</p></div></div><div className="parent-action-list">{detail.parentActions.filter((a) => a.status === 'open').map((a) => <div key={a.id}><div><strong>{a.title}</strong><p>{a.detail}</p><small>{a.teacherName}{a.dueDate ? ` · ${t(locale, '截止', 'Due')} ${a.dueDate}` : ''}</small></div><button type="button" className="secondary-button compact" onClick={() => void markDone(a.id)}><Check size={13} />{t(locale, '完成', 'Done')}</button></div>)}{detail.parentActions.filter((a) => a.status === 'open').length === 0 ? <small>{t(locale, '目前没有待完成的家庭行动。', 'No open parent actions right now.')}</small> : null}</div></section><section className="workspace-card"><div className="section-title"><Sparkles size={19} /><div><h3>{t(locale, '最近成长记录', 'Recent growth evidence')}</h3><p>{t(locale, '只显示学校已发布且允许家长查看的内容。', 'Only published parent-visible institution content is shown.')}</p></div></div><div className="compact-list evidence-parent">{detail.evidence.slice(0, 5).map((e) => <div key={e.id}><span><strong>{e.observation}</strong><small>{e.date} · {e.teacherName} · {e.className}</small></span></div>)}{detail.evidence.length === 0 ? <small>{t(locale, '学校尚未发布成长记录。', 'No published evidence yet.')}</small> : null}</div></section></div></> : <EmptyState title={t(locale, '还没有关联孩子', 'No linked children yet')} detail={t(locale, '在下方输入学校提供的关联码。', 'Enter the institution-issued child link code below.')} />}<section className="workspace-card claim-child-card"><div className="section-title"><Link2 size={19} /><div><h3>{t(locale, '添加另一个孩子', 'Add another child')}</h3><p>{t(locale, '不同学校的孩子可以添加到同一个家长账号，并分别查看。', 'Children from different institutions can live in one parent account and remain separately scoped.')}</p></div></div><div className="inline-add"><input value={code} onChange={(e) => setCode(e.target.value.toUpperCase())} placeholder="KID-XXXXXXXX" /><button type="button" className="primary-button" disabled={!code || busy} onClick={() => { setBusy(true); setMessage(''); void onClaim(code).then(() => { setCode(''); setMessage(t(locale, '孩子已关联。', 'Child linked.')); }).catch((e) => setMessage(e instanceof Error ? e.message : String(e))).finally(() => setBusy(false)); }}><Plus size={15} />{t(locale, '关联孩子', 'Link child')}</button></div><Feedback text={message} /></section></div>;
}

export function ParentGrowthView({ locale, detail }: { locale: Locale; detail: ParentChildDetail | null }) {
  if (!detail) return <EmptyState title={t(locale, '暂无孩子', 'No child selected')} detail={t(locale, '先在首页关联孩子。', 'Link a child from Home first.')} />;
  return <div className="workspace-stack"><PageHeading eyebrow={t(locale, '成长', 'Growth')} title={detail.child.displayName} detail={t(locale, '成长概览基于已发布证据的数量与最近日期，不把证据数量伪装成能力分数。', 'Growth overview uses published evidence counts and latest dates; evidence volume is not presented as a fabricated ability score.')} /><div className="growth-evidence-count-grid">{dimensions.map((d) => <div className="metric-card" key={d}><span>{dimensionLabels[d][locale]}</span><strong>{detail.growthSummary[d]?.count ?? 0}</strong><small>{detail.growthSummary[d]?.latestDate ? `${t(locale, '最近', 'Latest')} ${detail.growthSummary[d].latestDate}` : t(locale, '暂无证据', 'No evidence')}</small></div>)}</div><section className="workspace-card"><div className="section-title"><Milestone size={19} /><div><h3>{t(locale, '成长里程碑', 'Growth milestones')}</h3><p>{t(locale, '由教师以 milestone 类型发布。', 'Published by teachers as milestone evidence.')}</p></div></div><div className="milestone-timeline">{detail.milestones.map((e) => <div key={e.id}><div className="milestone-dot"><Sparkles size={13} /></div><div><span>{e.date} · {e.className}</span><strong>{e.observation}</strong>{e.interpretation ? <p>{e.interpretation}</p> : null}<small>{e.teacherName}</small></div></div>)}{detail.milestones.length === 0 ? <small>{t(locale, '尚未发布里程碑。', 'No milestones published yet.')}</small> : null}</div></section><div className="parent-evidence-grid">{detail.evidence.map((e) => <article className="workspace-card" key={e.id}><div className="evidence-meta"><span>{e.date}</span><span>{e.className}</span></div><div className="chip-row"><span className="chip neutral">{e.kind}</span>{e.dimensions.map((d) => <span className="chip" key={d}>{dimensionLabels[d][locale]}</span>)}</div><h3>{e.observation}</h3>{e.interpretation ? <p>{e.interpretation}</p> : null}<small>{e.teacherName}</small></article>)}</div></div>;
}

export function ParentClassroomView({ locale, detail }: { locale: Locale; detail: ParentChildDetail | null }) {
  if (!detail) return <EmptyState title={t(locale, '暂无孩子', 'No child selected')} detail={t(locale, '先关联孩子。', 'Link a child first.')} />;
  return <div className="workspace-stack"><PageHeading eyebrow={t(locale, '课堂', 'Classroom')} title={t(locale, '课堂与出勤记录', 'Classroom & attendance')} detail={detail.child.institutionName} /><div className="metric-grid four"><Stat label={t(locale, '出席', 'Present')} value={detail.attendanceSummary.counts.present} /><Stat label={t(locale, '迟到', 'Late')} value={detail.attendanceSummary.counts.late} /><Stat label={t(locale, '缺席', 'Absent')} value={detail.attendanceSummary.counts.absent} /><Stat label={t(locale, '请假', 'Excused')} value={detail.attendanceSummary.counts.excused} /></div><section className="workspace-card"><div className="attendance-table"><div className="attendance-head operational-attendance"><span>{t(locale, '日期', 'Date')}</span><span>{t(locale, '班级 / 主题', 'Class / topic')}</span><span>{t(locale, '状态', 'Status')}</span><span>P</span><span>C</span><span>{t(locale, '作业', 'Homework')}</span></div>{detail.attendance.map((a) => <div className="attendance-line operational-attendance" key={a.sessionId}><span>{a.date}</span><span><strong>{a.className}</strong><small>{a.topic || '—'}</small></span><span className={`status-pill ${a.status}`}>{statusLabel(locale, a.status)}</span><span>{a.participation}</span><span>{a.confidence}</span><span>{a.homework}</span></div>)}{detail.attendance.length === 0 ? <EmptyState title={t(locale, '暂无课堂记录', 'No classroom records')} detail={t(locale, '教师保存课堂记录后会同步到这里。', 'Teacher session records will appear here after saving.')} /> : null}</div></section></div>;
}

function ReportBody({ locale, report, compact = false }: { locale: Locale; report: StudentReport; compact?: boolean }) {
  return <div className={compact ? 'report-body compact' : 'report-body'}><div className="report-trust"><ShieldCheck size={15} /><span>{report.methodology}</span></div><div className="metric-grid four"><Stat label={t(locale, '证据', 'Evidence')} value={report.evidenceCount} /><Stat label={t(locale, '课堂', 'Sessions')} value={report.attendance.sessionCount} /><Stat label={t(locale, '出勤率', 'Attendance')} value={report.attendance.rate == null ? '—' : `${report.attendance.rate}%`} /><Stat label={t(locale, '里程碑', 'Milestones')} value={report.milestones.length} /></div><div className="report-dimensions">{dimensions.map((d) => <div key={d}><span>{dimensionLabels[d][locale]}</span><strong>{report.dimensionEvidenceCounts[d] ?? 0}</strong></div>)}</div>{compact ? null : <><div className="workspace-grid two"><section className="report-section"><h4>{t(locale, '近期证据', 'Recent evidence')}</h4>{report.recentEvidence.slice(0, 8).map((e) => <div className="report-row" key={e.id}><strong>{e.observation}</strong><small>{e.date} · {e.className} · {e.teacherName}</small></div>)}</section><section className="report-section"><h4>{t(locale, '家庭行动', 'Parent actions')}</h4>{report.parentActions.map((a) => <div className="report-row" key={a.id}><strong>{a.title}</strong><small>{a.status}{a.dueDate ? ` · ${a.dueDate}` : ''}</small></div>)}</section></div></>}</div>;
}

export function ParentReportView({ locale, token, detail }: { locale: Locale; token: string; detail: ParentChildDetail | null }) {
  const [period, setPeriod] = useState<ReportPeriod>('term');
  const [report, setReport] = useState<StudentReport | null>(null);
  const [error, setError] = useState('');
  useEffect(() => {
    if (!detail) { setReport(null); return; }
    let cancelled = false;
    setError('');
    void api.parentReport(token, detail.child.id, period).then((result) => { if (!cancelled) setReport(result); }).catch((e) => { if (!cancelled) setError(e instanceof Error ? e.message : String(e)); });
    return () => { cancelled = true; };
  }, [detail?.child.id, period, token]);
  if (!detail) return <EmptyState title={t(locale, '暂无孩子', 'No child selected')} detail={t(locale, '先关联孩子。', 'Link a child first.')} />;
  return <div className="workspace-stack"><PageHeading eyebrow={t(locale, '成长报告', 'Growth report')} title={detail.child.displayName} detail={t(locale, '报告由可追溯的已发布成长证据和课堂记录组成。', 'Reports are composed from traceable published evidence and classroom records.')} action={<div className="segmented">{(['week','month','term','all'] as ReportPeriod[]).map((p) => <button type="button" key={p} className={period === p ? 'active' : ''} onClick={() => setPeriod(p)}>{p === 'week' ? t(locale, '本周', 'Week') : p === 'month' ? t(locale, '本月', 'Month') : p === 'term' ? t(locale, '本学期', 'Term') : t(locale, '全部', 'All')}</button>)}</div>} />{error ? <Feedback text={error} danger /> : null}{report ? <section className="workspace-card report-card"><div className="report-header"><div><span>{report.generatedAt}</span><h2>{detail.child.displayName}</h2><p>{detail.child.institutionName} · {detail.child.classes.map((c) => c.name).join(' / ')}</p></div><BarChart3 size={28} /></div><ReportBody locale={locale} report={report} /></section> : <div className="workspace-card"><div className="loading-inline"><RefreshCw size={17} />{t(locale, '正在生成报告…', 'Generating report…')}</div></div>}</div>;
}

export function ParentProfileView({
  locale, token, identity, children, selectedId, onSelect, onClaim, onRefresh, onIdentityChange,
}: {
  locale: Locale; token: string; identity: AccountIdentity; children: StudentSummary[]; selectedId: string | null; onSelect: (id: string) => void; onClaim: (code: string) => Promise<void>; onRefresh: () => Promise<void>; onIdentityChange: (identity: AccountIdentity) => void;
}) {
  const [code, setCode] = useState(''); const [message, setMessage] = useState('');
  const [displayName, setDisplayName] = useState(identity.displayName);
  const [passwords, setPasswords] = useState({ current: '', next: '' });
  const [sessions, setSessions] = useState<AccountSession[]>([]);
  useEffect(() => { setDisplayName(identity.displayName); void api.sessions(token).then((r) => setSessions(r.sessions)).catch(() => setSessions([])); }, [identity.id, identity.displayName, token]);
  const loadSessions = async () => { try { setSessions((await api.sessions(token)).sessions); } catch (e) { setMessage(e instanceof Error ? e.message : String(e)); } };
  return <div className="workspace-stack"><PageHeading eyebrow={t(locale, '我的家庭与账号', 'Family & account')} title={t(locale, '孩子、账号与设备', 'Children, account and devices')} detail={t(locale, '同一个家长账号可以关联不同机构中的多个孩子；解绑只移除家长关系，不删除学校的学生记录。', 'One parent account can link children across institutions. Unlinking removes only the guardian relationship, never the institution student record.')} />
    <div className="family-grid">{children.map((child) => <button type="button" key={child.id} className={`family-card ${selectedId === child.id ? 'active' : ''}`} onClick={() => onSelect(child.id)}><div className="student-dot large">{child.displayName.slice(0, 1)}</div><span><strong>{child.displayName}</strong><small>{child.institutionName}</small><small>{child.classes.map((c) => c.name).join(' / ') || t(locale, '尚未分班', 'No class yet')}</small></span>{selectedId === child.id ? <Check size={17} /> : null}</button>)}</div>
    <div className="workspace-grid two"><section className="workspace-card"><div className="section-title"><Link2 size={19} /><div><h3>{t(locale, '添加/解绑孩子', 'Link / unlink children')}</h3><p>{t(locale, '使用学校生成的一次性关联码。', 'Use a one-time claim code issued by the institution.')}</p></div></div><div className="inline-add"><input value={code} onChange={(e) => setCode(e.target.value.toUpperCase())} placeholder="KID-XXXXXXXX" /><button type="button" className="primary-button" disabled={!code.trim()} onClick={() => void onClaim(code.trim()).then(() => { setCode(''); setMessage(t(locale, '关联成功。', 'Linked successfully.')); }).catch((e) => setMessage(e instanceof Error ? e.message : String(e)))}><Plus size={15} />{t(locale, '关联', 'Link')}</button></div>{selectedId ? <button type="button" className="danger-button subtle" onClick={() => { if (confirm(t(locale, '确定从你的账号解绑当前孩子？学校中的学生记录不会被删除。', 'Unlink this child from your account? The institution student record will remain.'))) void api.unlinkChild(token, selectedId).then(onRefresh).catch((e) => setMessage(e instanceof Error ? e.message : String(e))); }}><Trash2 size={14} />{t(locale, '解绑当前孩子', 'Unlink current child')}</button> : null}</section>
      <section className="workspace-card"><div className="section-title"><UserRound size={19} /><div><h3>{t(locale, '账号资料', 'Account profile')}</h3><p>{identity.email}</p></div></div><div className="form-grid"><label><span>{t(locale, '显示名称', 'Display name')}</span><input value={displayName} onChange={(e) => setDisplayName(e.target.value)} /></label><button type="button" className="secondary-button" onClick={() => void api.updateProfile(token, displayName.trim()).then((r) => { onIdentityChange(r.account); setMessage(t(locale, '账号名称已更新。', 'Display name updated.')); }).catch((e) => setMessage(e instanceof Error ? e.message : String(e)))}><Save size={14} />{t(locale, '保存名称', 'Save name')}</button><div className="section-divider" /><label><span>{t(locale, '当前密码', 'Current password')}</span><input type="password" value={passwords.current} onChange={(e) => setPasswords({ ...passwords, current: e.target.value })} /></label><label><span>{t(locale, '新密码（至少10位）', 'New password (10+ characters)')}</span><input type="password" value={passwords.next} onChange={(e) => setPasswords({ ...passwords, next: e.target.value })} /></label><button type="button" className="secondary-button" disabled={!passwords.current || passwords.next.length < 10} onClick={() => void api.changePassword(token, passwords.current, passwords.next).then(() => { setPasswords({ current: '', next: '' }); setMessage(t(locale, '密码已更新。', 'Password updated.')); }).catch((e) => setMessage(e instanceof Error ? e.message : String(e)))}><LockKeyhole size={14} />{t(locale, '修改密码', 'Change password')}</button></div></section>
    </div>
    <section className="workspace-card"><div className="section-title"><ShieldCheck size={19} /><div><h3>{t(locale, '登录设备', 'Signed-in devices')}</h3><p>{t(locale, '可撤销其他浏览器/设备的会话。', 'Revoke sessions on other browsers or devices.')}</p></div><button type="button" className="secondary-button compact" onClick={() => void loadSessions()}><RefreshCw size={13} />{t(locale, '刷新', 'Refresh')}</button></div><div className="device-list">{sessions.map((session) => <div key={session.id}><span><strong>{session.current ? t(locale, '当前设备', 'Current device') : session.clientRole}</strong><small>{session.userAgent || t(locale, '未知设备', 'Unknown device')} · {session.ipAddress || '—'}</small><small>{t(locale, '最近活动', 'Last seen')} {timestamp(session.lastSeenAt)}</small></span>{!session.current ? <button type="button" className="text-danger" onClick={() => void api.revokeSession(token, session.id).then(loadSessions).catch((e) => setMessage(e instanceof Error ? e.message : String(e)))}>{t(locale, '撤销', 'Revoke')}</button> : null}</div>)}</div></section>
    <Feedback text={message} />
  </div>;
}
