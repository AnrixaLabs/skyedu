import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import App from './App';
import './styles/app.css';

const path = window.location.pathname.toLowerCase();
const role = path.startsWith('/teacher') ? 'teacher' : path.startsWith('/parent') ? 'parent' : null;
if (role) {
  const manifest = document.createElement('link');
  manifest.rel = 'manifest';
  manifest.href = role === 'parent' ? '/parent-manifest.webmanifest' : '/teacher-manifest.webmanifest';
  document.head.appendChild(manifest);
  document.title = role === 'parent'
    ? 'SkyED GrowthBridge Parent · 家长端'
    : 'SkyED GrowthBridge Teacher · 教师端';
}

if ('serviceWorker' in navigator) {
  let refreshed = false;
  navigator.serviceWorker.addEventListener('controllerchange', () => {
    if (refreshed) return;
    refreshed = true;
    window.location.reload();
  });
  window.addEventListener('load', () => {
    void navigator.serviceWorker.register('/sw.js', { scope: '/' }).then((registration) => {
      void registration.update();
    });
  });
}

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>,
);
