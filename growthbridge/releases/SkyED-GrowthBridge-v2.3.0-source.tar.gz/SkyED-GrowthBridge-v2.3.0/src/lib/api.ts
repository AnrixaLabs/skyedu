import type { AttendanceStatus, GrowthDimensionKey, Role, Visibility, PublishState, EvidenceKind } from '../types/domain';

export interface AccountIdentity {
  id: string;
  email: string;
  displayName: string;
  role: Role;
  sessionId?: string;
}

export interface AuthStatus {
  appVersion: string;
  apiVersion: string;
  registrationOpen: boolean;
  accountsCount: number;
  institutionsCount: number;
  dataModel: string;
}

export type InstitutionRole = 'owner' | 'admin' | 'teacher';

export interface InstitutionSummary {
  id: string;
  name: string;
  code: string;
  role: InstitutionRole;
  classCount: number;
  studentCount: number;
}

export interface ClassSummary {
  id: string;
  institutionId: string;
  name: string;
  code: string;
  gradeLabel: string;
  termLabel: string;
  status: 'active' | 'archived';
  studentIds: string[];
  teacherIds: string[];
}

export interface StudentSummary {
  id: string;
  institutionId: string;
  institutionName: string;
  institutionCode: string;
  studentCode: string;
  firstName: string;
  lastName: string;
  preferredName: string;
  chineseName: string;
  displayName: string;
  status: 'active' | 'archived';
  guardianCount: number;
  classes: Array<{ id: string; name: string; code: string; gradeLabel: string; termLabel: string }>;
}

export interface StaffSummary {
  id: string;
  email: string;
  displayName: string;
  role: InstitutionRole;
  status: 'active' | 'pending' | 'disabled';
  classIds: string[];
}

export interface JoinRequestSummary {
  id: string;
  teacherAccountId: string;
  displayName: string;
  email: string;
  createdAt: string;
}

export interface TeacherInvitationSummary {
  id: string;
  email: string | null;
  role: 'teacher' | 'admin';
  classIds: string[];
  createdAt: string;
  expiresAt: number;
  usedAt: string | null;
  revokedAt: string | null;
}

export interface ChildClaimSummary {
  id: string;
  studentId: string;
  createdAt: string;
  expiresAt: number;
  usedAt: string | null;
  revokedAt: string | null;
}

export interface EvidenceRecord {
  id: string;
  institutionId: string;
  classId: string | null;
  className: string;
  studentId: string;
  teacherId: string;
  teacherName: string;
  date: string;
  kind: EvidenceKind;
  observation: string;
  interpretation: string;
  dimensions: GrowthDimensionKey[];
  visibility: Visibility;
  publishState: PublishState;
  updatedAt: string;
}

export interface SessionSummary {
  id: string;
  classId: string;
  className: string;
  date: string;
  topic: string;
  updatedAt: string;
  rowCount: number;
  counts: Record<AttendanceStatus, number>;
}

export interface SessionDetail {
  id: string;
  institutionId: string;
  classId: string;
  className: string;
  date: string;
  topic: string;
  rows: Array<AttendanceInput & { displayName: string }>;
}

export interface ParentActionRecord {
  id: string;
  institutionId: string;
  classId: string | null;
  className: string;
  studentId: string;
  teacherId: string;
  teacherName: string;
  title: string;
  detail: string;
  dueDate: string | null;
  status: 'open' | 'done';
  createdAt: string;
  updatedAt: string;
}

export interface TeacherWorkspace {
  revision: string;
  institution: { id: string; name: string; code: string; role: InstitutionRole };
  canManage: boolean;
  classes: ClassSummary[];
  students: StudentSummary[];
  staff: StaffSummary[];
  joinRequests: JoinRequestSummary[];
  invitations: TeacherInvitationSummary[];
  childClaims: ChildClaimSummary[];
  evidence: EvidenceRecord[];
  sessions: SessionSummary[];
  parentActions: ParentActionRecord[];
}

export interface ParentChildrenPayload {
  revision: string;
  children: StudentSummary[];
}

export interface AttendanceRow {
  sessionId: string;
  date: string;
  classId: string;
  className: string;
  topic: string;
  status: AttendanceStatus;
  participation: number;
  confidence: number;
  homework: 'done' | 'partial' | 'missing';
  note: string;
}

export type GrowthSummary = Record<GrowthDimensionKey, { count: number; latestDate: string | null }>;

export interface ParentChildDetail {
  revision: string;
  child: StudentSummary;
  evidence: EvidenceRecord[];
  milestones: EvidenceRecord[];
  growthSummary: GrowthSummary;
  parentActions: ParentActionRecord[];
  attendance: AttendanceRow[];
  attendanceSummary: {
    counts: Record<AttendanceStatus, number>;
    rate: number | null;
  };
}

export interface AttendanceInput {
  studentId: string;
  status: AttendanceStatus;
  participation: number;
  confidence: number;
  homework: 'done' | 'partial' | 'missing';
  note: string;
}

export type ReportPeriod = 'week' | 'month' | 'term' | 'all';

export interface StudentReport {
  period: ReportPeriod;
  methodology: string;
  generatedAt: string;
  child: StudentSummary;
  evidenceCount: number;
  milestones: EvidenceRecord[];
  recentEvidence: EvidenceRecord[];
  dimensionEvidenceCounts: Record<GrowthDimensionKey, number>;
  attendance: {
    sessionCount: number;
    counts: Record<AttendanceStatus, number>;
    rate: number | null;
    averageParticipation: number | null;
    averageConfidence: number | null;
    homework: Record<'done' | 'partial' | 'missing', number>;
  };
  parentActions: ParentActionRecord[];
}

export interface AccountSession {
  id: string;
  clientRole: Role;
  createdAt: string;
  lastSeenAt: string;
  expiresAt: number;
  ipAddress: string;
  userAgent: string;
  current: boolean;
}

export interface AuditEvent {
  id: string;
  accountId: string | null;
  actorName: string;
  action: string;
  objectType: string | null;
  objectId: string | null;
  detail: Record<string, unknown>;
  createdAt: string;
}

interface ApiErrorPayload {
  error?: { code?: string; message?: string };
}

export class ApiError extends Error {
  status: number;
  code: string;

  constructor(status: number, code: string, message: string) {
    super(message);
    this.status = status;
    this.code = code;
  }
}

const tokenKey = (role: Role) => `skyed_growthbridge_${role}_token_v2_3`;
const legacyTokenKey = (role: Role) => `skyed_growthbridge_${role}_token_v2_2`;

export const getStoredToken = (role: Role) => {
  const current = localStorage.getItem(tokenKey(role));
  if (current) return current;
  const legacy = localStorage.getItem(legacyTokenKey(role));
  if (legacy) {
    localStorage.setItem(tokenKey(role), legacy);
    localStorage.removeItem(legacyTokenKey(role));
  }
  return legacy;
};
export const storeToken = (role: Role, token: string) => {
  localStorage.setItem(tokenKey(role), token);
  localStorage.removeItem(legacyTokenKey(role));
};
export const clearStoredToken = (role: Role) => {
  localStorage.removeItem(tokenKey(role));
  localStorage.removeItem(legacyTokenKey(role));
};

async function request<T>(path: string, init: RequestInit = {}, token?: string | null): Promise<T> {
  const headers = new Headers(init.headers ?? {});
  if (init.body && !headers.has('Content-Type')) headers.set('Content-Type', 'application/json');
  if (token) headers.set('Authorization', `Bearer ${token}`);
  const response = await fetch(path, { ...init, headers, cache: 'no-store' });
  const text = await response.text();
  let payload: unknown = {};
  if (text) {
    try { payload = JSON.parse(text); } catch { payload = {}; }
  }
  if (!response.ok) {
    const error = payload as ApiErrorPayload;
    throw new ApiError(response.status, error.error?.code ?? 'REQUEST_FAILED', error.error?.message ?? `Request failed (${response.status})`);
  }
  return payload as T;
}

const enc = encodeURIComponent;

export const api = {
  status: () => request<AuthStatus>('/api/v1/auth/status'),
  register: (role: Role, displayName: string, email: string, password: string) => request<{ account: AccountIdentity; token: string }>('/api/v1/auth/register', {
    method: 'POST', body: JSON.stringify({ clientRole: role, displayName, email, password }),
  }),
  login: (role: Role, email: string, password: string) => request<{ account: AccountIdentity; token: string }>('/api/v1/auth/login', {
    method: 'POST', body: JSON.stringify({ clientRole: role, email, password }),
  }),
  me: (token: string) => request<{ account: AccountIdentity }>('/api/v1/auth/me', {}, token),
  logout: (token: string) => request<{ ok: boolean }>('/api/v1/auth/logout', { method: 'POST', body: '{}' }, token),
  changePassword: (token: string, currentPassword: string, newPassword: string) => request<{ ok: boolean }>('/api/v1/auth/change-password', { method: 'POST', body: JSON.stringify({ currentPassword, newPassword }) }, token),
  updateProfile: (token: string, displayName: string) => request<{ account: AccountIdentity }>('/api/v1/auth/profile', { method: 'PATCH', body: JSON.stringify({ displayName }) }, token),
  sessions: (token: string) => request<{ sessions: AccountSession[] }>('/api/v1/auth/sessions', {}, token),
  revokeSession: (token: string, sessionId: string) => request<{ ok: boolean; sessionId: string }>(`/api/v1/auth/sessions/${enc(sessionId)}`, { method: 'DELETE', body: '{}' }, token),

  teacherInstitutions: (token: string) => request<{ institutions: InstitutionSummary[] }>('/api/v1/teacher/institutions', {}, token),
  createInstitution: (token: string, name: string) => request<InstitutionSummary>('/api/v1/teacher/institutions', { method: 'POST', body: JSON.stringify({ name }) }, token),
  updateInstitution: (token: string, institutionId: string, name: string) => request<{ id: string; name: string; code: string; role: InstitutionRole }>(`/api/v1/institutions/${enc(institutionId)}`, { method: 'PATCH', body: JSON.stringify({ name }) }, token),
  requestJoin: (token: string, schoolCode: string) => request<{ id: string; institutionId: string; institutionName: string; status: string }>('/api/v1/teacher/join-requests', { method: 'POST', body: JSON.stringify({ schoolCode }) }, token),
  acceptTeacherInvitation: (token: string, invitationToken: string) => request<{ institutionId: string; role: InstitutionRole }>('/api/v1/teacher/invitations/accept', { method: 'POST', body: JSON.stringify({ token: invitationToken }) }, token),
  teacherWorkspace: (token: string, institutionId: string) => request<TeacherWorkspace>(`/api/v1/teacher/workspace/${enc(institutionId)}`, {}, token),
  createClass: (token: string, institutionId: string, input: { name: string; code?: string; gradeLabel?: string; termLabel?: string }) => request<ClassSummary>(`/api/v1/institutions/${enc(institutionId)}/classes`, { method: 'POST', body: JSON.stringify(input) }, token),
  updateClass: (token: string, institutionId: string, classId: string, input: Partial<Pick<ClassSummary, 'name' | 'code' | 'gradeLabel' | 'termLabel' | 'status'>>) => request<ClassSummary>(`/api/v1/institutions/${enc(institutionId)}/classes/${enc(classId)}`, { method: 'PATCH', body: JSON.stringify(input) }, token),
  createStudent: (token: string, institutionId: string, input: { studentCode?: string; firstName?: string; lastName?: string; preferredName?: string; chineseName?: string; classIds?: string[] }) => request<StudentSummary>(`/api/v1/institutions/${enc(institutionId)}/students`, { method: 'POST', body: JSON.stringify(input) }, token),
  updateStudent: (token: string, institutionId: string, studentId: string, input: { studentCode?: string; firstName?: string; lastName?: string; preferredName?: string; chineseName?: string; classIds?: string[]; status?: 'active' | 'archived' }) => request<StudentSummary>(`/api/v1/institutions/${enc(institutionId)}/students/${enc(studentId)}`, { method: 'PATCH', body: JSON.stringify(input) }, token),
  addStudentToClass: (token: string, institutionId: string, classId: string, studentId: string) => request<{ ok: boolean }>(`/api/v1/institutions/${enc(institutionId)}/classes/${enc(classId)}/students`, { method: 'POST', body: JSON.stringify({ studentId }) }, token),
  removeStudentFromClass: (token: string, institutionId: string, classId: string, studentId: string) => request<{ ok: boolean }>(`/api/v1/institutions/${enc(institutionId)}/classes/${enc(classId)}/students/${enc(studentId)}`, { method: 'DELETE', body: '{}' }, token),
  createTeacherInvitation: (token: string, institutionId: string, input: { role: 'teacher' | 'admin'; email?: string; classIds: string[] }) => request<{ id: string; token: string; role: string; email: string | null; classIds: string[]; expiresAt: number }>(`/api/v1/institutions/${enc(institutionId)}/teacher-invitations`, { method: 'POST', body: JSON.stringify(input) }, token),
  revokeTeacherInvitation: (token: string, institutionId: string, invitationId: string) => request<{ ok: boolean }>(`/api/v1/institutions/${enc(institutionId)}/teacher-invitations/${enc(invitationId)}`, { method: 'DELETE', body: '{}' }, token),
  approveJoinRequest: (token: string, institutionId: string, requestId: string) => request<{ id: string; status: string; teacherAccountId: string }>(`/api/v1/institutions/${enc(institutionId)}/join-requests/${enc(requestId)}/approve`, { method: 'POST', body: '{}' }, token),
  rejectJoinRequest: (token: string, institutionId: string, requestId: string) => request<{ id: string; status: string; teacherAccountId: string }>(`/api/v1/institutions/${enc(institutionId)}/join-requests/${enc(requestId)}/reject`, { method: 'POST', body: '{}' }, token),
  updateMembership: (token: string, institutionId: string, accountId: string, input: { role?: 'teacher' | 'admin'; status?: 'active' | 'disabled' }) => request<{ accountId: string; role: string; status: string }>(`/api/v1/institutions/${enc(institutionId)}/members/${enc(accountId)}`, { method: 'PATCH', body: JSON.stringify(input) }, token),
  assignTeacher: (token: string, institutionId: string, classId: string, teacherAccountId: string) => request<{ ok: boolean }>(`/api/v1/institutions/${enc(institutionId)}/teacher-assignments`, { method: 'POST', body: JSON.stringify({ classId, teacherAccountId }) }, token),
  unassignTeacher: (token: string, institutionId: string, classId: string, teacherAccountId: string) => request<{ ok: boolean }>(`/api/v1/institutions/${enc(institutionId)}/teacher-assignments`, { method: 'DELETE', body: JSON.stringify({ classId, teacherAccountId }) }, token),
  createChildClaim: (token: string, studentId: string) => request<{ id: string; code: string; studentId: string; expiresAt: number }>(`/api/v1/students/${enc(studentId)}/claim-code`, { method: 'POST', body: '{}' }, token),
  revokeChildClaim: (token: string, studentId: string, claimId: string) => request<{ ok: boolean }>(`/api/v1/students/${enc(studentId)}/claim-code/${enc(claimId)}`, { method: 'DELETE', body: '{}' }, token),
  audit: (token: string, institutionId: string, limit = 100) => request<{ events: AuditEvent[] }>(`/api/v1/institutions/${enc(institutionId)}/audit?limit=${limit}`, {}, token),

  parentChildren: (token: string) => request<ParentChildrenPayload>('/api/v1/parent/children', {}, token),
  parentChild: (token: string, studentId: string) => request<ParentChildDetail>(`/api/v1/parent/child/${enc(studentId)}`, {}, token),
  parentReport: (token: string, studentId: string, period: ReportPeriod) => request<StudentReport>(`/api/v1/parent/child/${enc(studentId)}/report?period=${enc(period)}`, {}, token),
  teacherReport: (token: string, institutionId: string, studentId: string, period: ReportPeriod) => request<StudentReport>(`/api/v1/teacher/student/${enc(studentId)}/report?institutionId=${enc(institutionId)}&period=${enc(period)}`, {}, token),
  claimChild: (token: string, code: string) => request<StudentSummary>('/api/v1/parent/claim-child', { method: 'POST', body: JSON.stringify({ code }) }, token),
  unlinkChild: (token: string, studentId: string) => request<{ ok: boolean }>(`/api/v1/parent/children/${enc(studentId)}`, { method: 'DELETE', body: '{}' }, token),

  addEvidence: (token: string, input: { institutionId: string; classId: string; studentId: string; date?: string; kind?: EvidenceKind; observation: string; interpretation: string; dimensions: GrowthDimensionKey[]; visibility: Visibility; publishState?: PublishState }) => request<EvidenceRecord>('/api/v1/evidence', { method: 'POST', body: JSON.stringify(input) }, token),
  updateEvidence: (token: string, evidenceId: string, input: Partial<{ date: string; kind: EvidenceKind; observation: string; interpretation: string; dimensions: GrowthDimensionKey[]; visibility: Visibility; publishState: PublishState }>) => request<EvidenceRecord>(`/api/v1/evidence/${enc(evidenceId)}`, { method: 'PATCH', body: JSON.stringify(input) }, token),
  addParentAction: (token: string, input: { institutionId: string; classId: string; studentId: string; title: string; detail?: string; dueDate?: string }) => request<ParentActionRecord>('/api/v1/parent-actions', { method: 'POST', body: JSON.stringify(input) }, token),
  updateParentAction: (token: string, actionId: string, input: Partial<{ title: string; detail: string; dueDate: string; status: 'open' | 'done' }>) => request<ParentActionRecord>(`/api/v1/parent-actions/${enc(actionId)}`, { method: 'PATCH', body: JSON.stringify(input) }, token),

  sessionsForClass: (token: string, institutionId: string, classId?: string) => request<{ sessions: SessionSummary[] }>(`/api/v1/class-sessions?institutionId=${enc(institutionId)}${classId ? `&classId=${enc(classId)}` : ''}`, {}, token),
  classSession: (token: string, sessionId: string) => request<SessionDetail>(`/api/v1/class-sessions/${enc(sessionId)}`, {}, token),
  saveClassSession: (token: string, input: { institutionId: string; classId: string; date: string; topic: string; rows: AttendanceInput[] }) => request<{ id: string; classId: string; date: string; rowsSaved: number }>('/api/v1/class-sessions', { method: 'POST', body: JSON.stringify(input) }, token),
};
