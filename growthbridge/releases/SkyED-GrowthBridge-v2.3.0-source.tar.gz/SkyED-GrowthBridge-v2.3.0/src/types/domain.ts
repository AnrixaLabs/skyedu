export type Locale = 'zh' | 'en';
export type Role = 'parent' | 'teacher';
export type Period = 'week' | 'month' | 'term';
export type Trend = 'up' | 'steady' | 'down';
export type AttentionLevel = 'normal' | 'watch' | 'follow_up';
export type PublishState = 'draft' | 'ready' | 'published';
export type Visibility = 'teacher_only' | 'parent_visible' | 'report';
export type AttendanceStatus = 'present' | 'late' | 'absent' | 'excused';
export type EvidenceKind = 'observation' | 'assessment' | 'attendance' | 'homework' | 'milestone';

export type GrowthDimensionKey =
  | 'language'
  | 'knowledge'
  | 'participation'
  | 'confidence'
  | 'habits'
  | 'independence';

export interface LocalizedText {
  zh: string;
  en: string;
}

export interface Student {
  id: string;
  name: LocalizedText;
  initials: string;
  grade: LocalizedText;
  group: LocalizedText;
  stage: LocalizedText;
  avatarTone: 'blue' | 'mint' | 'gold' | 'peach';
  attention: AttentionLevel;
  latestUpdate: LocalizedText;
  latestUpdateAt: string;
}

export interface GrowthDimension {
  key: GrowthDimensionKey;
  label: LocalizedText;
  score: number;
  delta: number;
  trend: Trend;
  summary: LocalizedText;
  evidenceIds: string[];
}

export interface EvidenceItem {
  id: string;
  studentId: string;
  date: string;
  kind: EvidenceKind;
  title: LocalizedText;
  detail: LocalizedText;
  interpretation: LocalizedText;
  dimensions: GrowthDimensionKey[];
  visibility: Visibility;
  publishState: PublishState;
  source: LocalizedText;
}

export interface Milestone {
  id: string;
  studentId: string;
  date: string;
  title: LocalizedText;
  detail: LocalizedText;
  dimensions: GrowthDimensionKey[];
  icon: 'spark' | 'book' | 'mic' | 'team';
}

export interface ParentAction {
  id: string;
  studentId: string;
  due?: string;
  title: LocalizedText;
  detail: LocalizedText;
  status: 'open' | 'done';
  effort: LocalizedText;
}

export interface LessonSnapshot {
  id: string;
  studentId: string;
  date: string;
  topic: LocalizedText;
  attendance: AttendanceStatus;
  participation: number;
  confidence: number;
  homework: 'done' | 'partial' | 'missing';
  note: LocalizedText;
}

export interface MessageItem {
  id: string;
  studentId: string;
  date: string;
  type: 'teacher_note' | 'school_notice' | 'report_ready';
  title: LocalizedText;
  body: LocalizedText;
  unread?: boolean;
}

export interface TeacherQueueItem {
  id: string;
  studentId: string;
  reason: LocalizedText;
  priority: 'medium' | 'high';
  since: string;
}

export interface ClassStudentState {
  studentId: string;
  attendance: AttendanceStatus;
  participation: number;
  confidence: number;
  homework: 'done' | 'partial' | 'missing';
  note: string;
}

export interface DraftEvidenceForm {
  studentId: string;
  observation: string;
  interpretation: string;
  dimensions: GrowthDimensionKey[];
  visibility: Visibility;
}
