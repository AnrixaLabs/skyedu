import { useCallback, useEffect, useMemo, useState, type ReactNode } from 'react';
import type { Locale, Role } from './types/domain';
import { AppShell, type ParentPage, type TeacherPage } from './components/AppShell';
import { AuthScreen, ClientChooser, ConnectionError } from './components/AuthViews';
import {
  ClassesView,
  EvidenceView,
  InstitutionHome,
  ParentClassroomView,
  ParentGrowthView,
  ParentHomeView,
  ParentProfileView,
  ParentReportView,
  SessionView,
  StaffView,
  StudentsView,
  TeacherOnboarding,
} from './components/WorkspaceViews';
import {
  api,
  ApiError,
  clearStoredToken,
  getStoredToken,
  storeToken,
  type AccountIdentity,
  type InstitutionSummary,
  type ParentChildDetail,
  type StudentSummary,
  type TeacherWorkspace,
} from './lib/api';

const TEACHER_CONTEXT_KEY = 'skyed_growthbridge_teacher_institution_v2_3';
const PARENT_CONTEXT_KEY = 'skyed_growthbridge_parent_child_v2_3';
const LEGACY_TEACHER_CONTEXT_KEY = 'skyed_growthbridge_teacher_institution_v2_2';
const LEGACY_PARENT_CONTEXT_KEY = 'skyed_growthbridge_parent_child_v2_2';

function routeRole(): Role | null {
  const path = window.location.pathname.toLowerCase();
  if (path.startsWith('/parent')) return 'parent';
  if (path.startsWith('/teacher')) return 'teacher';
  return null;
}

function readMigratedContext(currentKey: string, legacyKey: string) {
  const current = localStorage.getItem(currentKey);
  if (current) return current;
  const legacy = localStorage.getItem(legacyKey);
  if (legacy) {
    localStorage.setItem(currentKey, legacy);
    localStorage.removeItem(legacyKey);
  }
  return legacy;
}

function errorText(error: unknown, locale: Locale): string {
  if (error instanceof ApiError) {
    const known: Record<string, { zh: string; en: string }> = {
      LOGIN_FAILED: { zh: '邮箱或密码不正确。', en: 'Email or password is incorrect.' },
      ROLE_CLIENT_MISMATCH: { zh: '此账号属于另一个客户端。', en: 'This account belongs to the other client.' },
      EMAIL_EXISTS: { zh: '此邮箱已经注册。', en: 'This email is already registered.' },
      PASSWORD_TOO_SHORT: { zh: '密码至少需要10位。', en: 'Password must contain at least 10 characters.' },
      LOGIN_LOCKED: { zh: '登录失败次数过多，请稍后再试。', en: 'Too many failed sign-in attempts. Try again later.' },
      RATE_LIMITED: { zh: '操作过于频繁，请稍后再试。', en: 'Too many operations. Please try again shortly.' },
      SCHOOL_CODE_NOT_FOUND: { zh: '未找到此学校代码。', en: 'Institution code was not found.' },
      CHILD_CODE_INVALID: { zh: '孩子关联码无效、已过期、已撤销或已使用。', en: 'Child link code is invalid, expired, revoked, or already used.' },
      TEACHER_INVITE_INVALID: { zh: '教师邀请无效、已过期、已撤销或已使用。', en: 'Teacher invitation is invalid, expired, revoked, or already used.' },
      TEACHER_INVITE_EMAIL_MISMATCH: { zh: '此邀请已绑定其他邮箱。', en: 'This invitation is locked to another email address.' },
      INSTITUTION_FORBIDDEN: { zh: '你没有此机构的访问权限。', en: 'You do not have access to this institution.' },
      INSTITUTION_ROLE_FORBIDDEN: { zh: '你的学校角色没有此操作权限。', en: 'Your institution role cannot perform this operation.' },
      CLASS_ACCESS_FORBIDDEN: { zh: '你没有此班级的访问权限。', en: 'You do not have access to this class.' },
      STUDENT_SCOPE_FORBIDDEN: { zh: '此学生不在你的授权班级范围内。', en: 'This student is outside your assigned class scope.' },
      CHILD_SCOPE_FORBIDDEN: { zh: '此孩子未关联到你的家长账号。', en: 'This child is not linked to your parent account.' },
      CURRENT_PASSWORD_INVALID: { zh: '当前密码不正确。', en: 'Current password is incorrect.' },
      SESSION_NOT_FOUND: { zh: '该登录会话不存在或已失效。', en: 'The session no longer exists.' },
    };
    return known[error.code]?.[locale] ?? error.message;
  }
  return error instanceof Error ? error.message : String(error);
}

export default function App() {
  const role = routeRole();
  const [locale, setLocale] = useState<Locale>(() => localStorage.getItem('skyed_growthbridge_locale') === 'en' ? 'en' : 'zh');
  const [identity, setIdentity] = useState<AccountIdentity | null>(null);
  const [token, setToken] = useState<string | null>(null);
  const [loading, setLoading] = useState(Boolean(role));
  const [busy, setBusy] = useState(false);
  const [authError, setAuthError] = useState<string | null>(null);
  const [connectionError, setConnectionError] = useState<string | null>(null);
  const [parentPage, setParentPage] = useState<ParentPage>('home');
  const [teacherPage, setTeacherPage] = useState<TeacherPage>('home');
  const [institutions, setInstitutions] = useState<InstitutionSummary[]>([]);
  const [institutionId, setInstitutionId] = useState<string | null>(null);
  const [workspace, setWorkspace] = useState<TeacherWorkspace | null>(null);
  const [children, setChildren] = useState<StudentSummary[]>([]);
  const [childId, setChildId] = useState<string | null>(null);
  const [childDetail, setChildDetail] = useState<ParentChildDetail | null>(null);
  const invitationToken = useMemo(() => new URLSearchParams(window.location.search).get('invite'), []);

  const toggleLocale = () => setLocale((current) => {
    const next = current === 'zh' ? 'en' : 'zh';
    localStorage.setItem('skyed_growthbridge_locale', next);
    return next;
  });

  const loadTeacher = useCallback(async (activeToken: string, preferredId?: string | null) => {
    const result = await api.teacherInstitutions(activeToken);
    setInstitutions(result.institutions);
    const stored = readMigratedContext(TEACHER_CONTEXT_KEY, LEGACY_TEACHER_CONTEXT_KEY);
    const nextId = preferredId && result.institutions.some((x) => x.id === preferredId)
      ? preferredId
      : stored && result.institutions.some((x) => x.id === stored)
        ? stored
        : result.institutions[0]?.id ?? null;
    setInstitutionId(nextId);
    if (nextId) {
      localStorage.setItem(TEACHER_CONTEXT_KEY, nextId);
      setWorkspace(await api.teacherWorkspace(activeToken, nextId));
    } else {
      setWorkspace(null);
    }
    setConnectionError(null);
  }, []);

  const loadParent = useCallback(async (activeToken: string, preferredChildId?: string | null) => {
    const result = await api.parentChildren(activeToken);
    setChildren(result.children);
    const stored = readMigratedContext(PARENT_CONTEXT_KEY, LEGACY_PARENT_CONTEXT_KEY);
    const nextId = preferredChildId && result.children.some((x) => x.id === preferredChildId)
      ? preferredChildId
      : stored && result.children.some((x) => x.id === stored)
        ? stored
        : result.children[0]?.id ?? null;
    setChildId(nextId);
    if (nextId) {
      localStorage.setItem(PARENT_CONTEXT_KEY, nextId);
      setChildDetail(await api.parentChild(activeToken, nextId));
    } else {
      setChildDetail(null);
    }
    setConnectionError(null);
  }, []);

  const loadRoleData = useCallback(async (activeToken: string) => {
    if (role === 'teacher') await loadTeacher(activeToken, institutionId);
    else if (role === 'parent') await loadParent(activeToken, childId);
  }, [childId, institutionId, loadParent, loadTeacher, role]);

  const acceptPendingTeacherInvite = useCallback(async (activeToken: string) => {
    if (role !== 'teacher' || !invitationToken) return;
    await api.acceptTeacherInvitation(activeToken, invitationToken);
    window.history.replaceState({}, '', '/teacher/');
  }, [invitationToken, role]);

  const initialize = useCallback(async () => {
    if (!role) return;
    setLoading(true); setConnectionError(null); setAuthError(null);
    try {
      const status = await api.status();
      if (status.appVersion !== '2.3.0') {
        throw new ApiError(503, 'VERSION_MISMATCH', `Expected GrowthBridge 2.3.0, got ${status.appVersion}`);
      }
      const existing = getStoredToken(role);
      if (!existing) { setIdentity(null); setToken(null); return; }
      try {
        const me = await api.me(existing);
        if (me.account.role !== role) throw new ApiError(403, 'ROLE_CLIENT_MISMATCH', 'Role mismatch');
        setIdentity(me.account); setToken(existing);
        if (role === 'teacher' && invitationToken) await acceptPendingTeacherInvite(existing);
        if (role === 'teacher') await loadTeacher(existing);
        else await loadParent(existing);
      } catch (error) {
        if (error instanceof ApiError && error.status >= 500) throw error;
        clearStoredToken(role);
        setIdentity(null); setToken(null); setWorkspace(null); setChildren([]); setChildDetail(null);
      }
    } catch (error) {
      setConnectionError(errorText(error, locale));
    } finally {
      setLoading(false);
    }
  }, [acceptPendingTeacherInvite, invitationToken, loadParent, loadTeacher, locale, role]);

  useEffect(() => { void initialize(); }, [initialize]);

  useEffect(() => {
    if (!identity || !token) return;
    const tick = () => {
      if (document.visibilityState !== 'visible') return;
      void loadRoleData(token).catch((error) => setConnectionError(errorText(error, locale)));
    };
    const id = window.setInterval(tick, 15000);
    window.addEventListener('focus', tick);
    document.addEventListener('visibilitychange', tick);
    return () => { window.clearInterval(id); window.removeEventListener('focus', tick); document.removeEventListener('visibilitychange', tick); };
  }, [identity, loadRoleData, locale, token]);

  if (!role) return <ClientChooser locale={locale} onLocaleToggle={toggleLocale} />;
  if (loading) return <div className="connection-state"><div className="loading-orb" /><h2>SkyED GrowthBridge</h2><p>{locale === 'zh' ? '正在连接…' : 'Connecting…'}</p></div>;
  if (connectionError && !identity) return <ConnectionError locale={locale} detail={connectionError} onRetry={() => void initialize()} />;

  const completeAuth = async (account: AccountIdentity, nextToken: string) => {
    if (account.role !== role) throw new ApiError(403, 'ROLE_CLIENT_MISMATCH', 'Role/client mismatch');
    storeToken(role, nextToken);
    setIdentity(account); setToken(nextToken); setAuthError(null);
    if (role === 'teacher' && invitationToken) await acceptPendingTeacherInvite(nextToken);
    window.history.replaceState({}, '', role === 'parent' ? '/parent/' : '/teacher/');
    if (role === 'teacher') await loadTeacher(nextToken);
    else await loadParent(nextToken);
  };

  if (!identity || !token) {
    return <AuthScreen
      role={role}
      locale={locale}
      invitationToken={invitationToken}
      busy={busy}
      error={authError}
      onLocaleToggle={toggleLocale}
      onLogin={async (email, password) => {
        setBusy(true); setAuthError(null);
        try { const result = await api.login(role, email, password); await completeAuth(result.account, result.token); }
        catch (error) { setAuthError(errorText(error, locale)); }
        finally { setBusy(false); }
      }}
      onRegister={async (displayName, email, password) => {
        setBusy(true); setAuthError(null);
        try { const result = await api.register(role, displayName, email, password); await completeAuth(result.account, result.token); }
        catch (error) { setAuthError(errorText(error, locale)); }
        finally { setBusy(false); }
      }}
    />;
  }

  const logout = async () => {
    try { await api.logout(token); } catch { /* local logout remains authoritative for this device */ }
    clearStoredToken(role);
    setIdentity(null); setToken(null); setWorkspace(null); setInstitutions([]); setChildren([]); setChildDetail(null);
  };
  const refreshTeacher = async (preferred?: string | null) => { await loadTeacher(token, preferred ?? institutionId); };
  const refreshParent = async (preferred?: string | null) => { await loadParent(token, preferred ?? childId); };
  const selectInstitution = async (id: string) => { setInstitutionId(id); localStorage.setItem(TEACHER_CONTEXT_KEY, id); setWorkspace(await api.teacherWorkspace(token, id)); };
  const selectChild = async (id: string) => { setChildId(id); localStorage.setItem(PARENT_CONTEXT_KEY, id); setChildDetail(await api.parentChild(token, id)); };

  let content: ReactNode;
  if (role === 'teacher') {
    if (!workspace) {
      content = <TeacherOnboarding
        locale={locale}
        pendingInvite={invitationToken}
        onCreateInstitution={async (name) => { const created = await api.createInstitution(token, name); await refreshTeacher(created.id); }}
        onRequestJoin={async (code) => { const result = await api.requestJoin(token, code); return locale === 'zh' ? `已向 ${result.institutionName} 发送加入申请。` : `Join request sent to ${result.institutionName}.`; }}
        onAcceptInvitation={async (invite) => { const result = await api.acceptTeacherInvitation(token, invite); await refreshTeacher(result.institutionId); }}
      />;
    } else if (teacherPage === 'home') content = <InstitutionHome locale={locale} token={token} workspace={workspace} institutions={institutions} onSelectInstitution={(id) => void selectInstitution(id)} onRefresh={refreshTeacher} />;
    else if (teacherPage === 'classes') content = <ClassesView locale={locale} token={token} workspace={workspace} onRefresh={refreshTeacher} />;
    else if (teacherPage === 'students') content = <StudentsView locale={locale} token={token} workspace={workspace} onRefresh={refreshTeacher} />;
    else if (teacherPage === 'session') content = <SessionView locale={locale} token={token} workspace={workspace} onRefresh={refreshTeacher} />;
    else if (teacherPage === 'evidence') content = <EvidenceView locale={locale} token={token} workspace={workspace} onRefresh={refreshTeacher} />;
    else content = <StaffView locale={locale} token={token} workspace={workspace} onRefresh={refreshTeacher} />;
  } else {
    const claim = async (code: string) => { const child = await api.claimChild(token, code); await refreshParent(child.id); };
    if (parentPage === 'home') content = <ParentHomeView locale={locale} token={token} detail={childDetail} onClaim={claim} onRefresh={refreshParent} />;
    else if (parentPage === 'growth') content = <ParentGrowthView locale={locale} detail={childDetail} />;
    else if (parentPage === 'classroom') content = <ParentClassroomView locale={locale} detail={childDetail} />;
    else if (parentPage === 'reports') content = <ParentReportView locale={locale} token={token} detail={childDetail} />;
    else content = <ParentProfileView locale={locale} token={token} identity={identity} children={children} selectedId={childId} onSelect={(id) => void selectChild(id)} onClaim={claim} onRefresh={refreshParent} onIdentityChange={setIdentity} />;
  }

  const contextTitle = role === 'teacher' ? workspace?.institution.name : childDetail?.child.displayName;
  const contextSubtitle = role === 'teacher'
    ? workspace ? `${workspace.institution.code} · ${workspace.institution.role}` : (locale === 'zh' ? '尚未加入机构' : 'No institution yet')
    : childDetail ? `${childDetail.child.institutionName} · ${childDetail.child.classes.map((c) => c.name).join(' / ')}` : (locale === 'zh' ? '尚未关联孩子' : 'No linked child');
  const canSwitchContext = role === 'teacher' ? institutions.length > 1 : children.length > 1;
  const cycleContext = () => {
    if (role === 'teacher' && institutions.length > 1) {
      const current = Math.max(0, institutions.findIndex((x) => x.id === institutionId));
      void selectInstitution(institutions[(current + 1) % institutions.length].id);
    } else if (role === 'parent' && children.length > 1) {
      const current = Math.max(0, children.findIndex((x) => x.id === childId));
      void selectChild(children[(current + 1) % children.length].id);
    }
  };

  return <AppShell
    locale={locale}
    role={role}
    identity={identity}
    parentPage={parentPage}
    teacherPage={teacherPage}
    contextTitle={contextTitle}
    contextSubtitle={contextSubtitle}
    canSwitchContext={canSwitchContext}
    onContextSwitch={cycleContext}
    onLocaleToggle={toggleLocale}
    onParentNavigate={setParentPage}
    onTeacherNavigate={setTeacherPage}
    onLogout={() => void logout()}
  >
    {connectionError ? <div className="sync-warning">{locale === 'zh' ? '同步暂时中断：' : 'Sync temporarily interrupted: '}{connectionError}</div> : null}
    {content}
  </AppShell>;
}
