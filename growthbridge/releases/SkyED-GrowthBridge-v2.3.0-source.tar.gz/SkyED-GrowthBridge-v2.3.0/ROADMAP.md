# SkyED GrowthBridge Roadmap

## v2.3.0 — Operational Product Release

Scope is operationalization of the v2.2 architecture, not a new backend design.

### Teacher
- [x] institution switcher and institution settings
- [x] class create/edit/archive
- [x] class roster management
- [x] student create/edit/archive and multi-class enrollment
- [x] child claim issue/history/revoke
- [x] session history and correction
- [x] attendance/participation/confidence/homework entry
- [x] evidence edit/publish workflow
- [x] milestone evidence
- [x] parent actions
- [x] teacher report preview
- [x] join approve/reject
- [x] invitations + revoke + class pre-assignment
- [x] staff role/status management
- [x] teacher/class permission matrix
- [x] institution audit viewer

### Parent
- [x] cross-institution child switching
- [x] published evidence
- [x] milestone timeline
- [x] source-backed dimension evidence counts
- [x] classroom/attendance history
- [x] parent actions with synchronized completion
- [x] week/month/term/all report
- [x] child unlink
- [x] account profile/password
- [x] signed-in device/session viewer and revoke

### Mobile/PWA
- [x] separate Parent and Teacher manifests/start URLs
- [x] shared API synchronization
- [x] API excluded from service-worker cache
- [x] service-worker update check and controller-change reload

### Production operations
- [x] mutation rate limit
- [x] additive migration only
- [x] database backup before promotion
- [x] database integrity checks
- [x] core-row preservation gate
- [x] immutable release + atomic activation
- [x] rollback-capable deployment controller

## Post-v2.3 candidates

These are intentionally not architectural prerequisites for v2.3:
- verified email/phone recovery after selecting an external delivery provider;
- push notifications after selecting China/global push infrastructure;
- richer report export/printing;
- bulk student import;
- object storage for photos/attachments;
- PostgreSQL migration when scale requires horizontal API deployment or higher write concurrency;
- optional API-based integration with ClassFlow using stable external identifiers.
