# SkyED GrowthBridge v2.3 Deployment

Target: `https://growth.skyed.org`

Protected paths:
- `/var/www/skyed.org`
- `/opt/classflow`

Application layout:

```text
/opt/skyed-growthbridge/
  current -> releases/<immutable-v2.3-release>
  releases/
  data/growthbridge.db
  backups/
```

The persistent database is never placed inside an immutable release directory.

The supported release path is the generated self-extracting PowerShell launcher. It automatically extracts verified embedded payloads to a temporary Windows directory, uploads them with one SCP operation, and executes one remote deployment controller through SSH.

The remote deployment controller:
1. verifies source SHA-256 and runtime prerequisites;
2. records protected-path pre-state;
3. extracts/builds an immutable successor release;
4. runs backend multi-tenant and operational integration suites;
5. runs `npm install` and the real `tsc -b && vite build`;
6. validates both PWA manifests and service worker in `dist`;
7. performs pre-deploy database integrity check and SQLite backup with integrity verification;
8. atomically switches `current`;
9. restarts the API, allowing additive v2.3 migration;
10. checks post-migration database integrity and core row preservation;
11. installs/reloads the GrowthBridge-only Nginx configuration;
12. waits for the new Nginx worker generation before probing;
13. validates local HTTP and HTTPS app/API routing;
14. checks protected paths are unchanged;
15. reports a fail-closed final state.

Do not manually copy files into `current`, edit ClassFlow/Main-site Nginx blocks, or reset the production database for a v2.3 deployment.
