# SkyED GrowthBridge v2.3 Validation

## Local source validation

Required:
- Python compilation of backend/server.py and both test suites;
- v2.2 multi-tenant regression suite;
- v2.3 operational workflow suite;
- TypeScript source/type validation;
- PWA manifest/service-worker static checks;
- deterministic source archive/hash checks.

Validated backend gates:

```text
BACKEND_MULTI_TENANT_INTEGRATION_GATE=PASS
CROSS_INSTITUTION_PARENT_MODEL_GATE=PASS
TEACHER_CLASS_SCOPE_GATE=PASS
STUDENT_CREATE_ATOMICITY_GATE=PASS
EVIDENCE_OWNERSHIP_GATE=PASS
MEMBERSHIP_DOWNGRADE_GUARD_GATE=PASS
SCHOOL_OPERATION_WORKFLOW_GATE=PASS
CLASS_ROSTER_WORKFLOW_GATE=PASS
SESSION_HISTORY_CORRECTION_GATE=PASS
PARENT_CHILD_LINK_WORKFLOW_GATE=PASS
PARENT_ACTION_SYNC_GATE=PASS
MILESTONE_REPORT_GATE=PASS
INVITATION_REVOCATION_GATE=PASS
JOIN_REQUEST_REJECTION_GATE=PASS
STAFF_ROLE_POLICY_GATE=PASS
MULTI_DEVICE_SESSION_GATE=PASS
AUDIT_VIEWER_GATE=PASS
```

The final production Vite build is performed on the ECS because the local execution environment does not have a usable npm registry connection. Promotion is fail-closed if `npm install`, TypeScript, or Vite build fails.

## Production promotion gates

The deployment controller must additionally prove:

```text
DATABASE_PREDEPLOY_INTEGRITY_GATE=PASS
DATABASE_BACKUP_INTEGRITY_GATE=PASS
DATABASE_POSTMIGRATION_INTEGRITY_GATE=PASS
DATA_MIGRATION_PRESERVATION_GATE=PASS
BACKEND_OPERATIONAL_DEPLOYMENT_TEST_GATE=PASS
MOBILE_PWA_DIST_GATE=PASS
API_SERVICE_HEALTH_GATE=PASS
LOCAL_HTTP_APP_SHELL_GATE=PASS
LOCAL_HTTP_API_GATE=PASS
LOCAL_HTTPS_APP_SHELL_GATE=PASS
LOCAL_HTTPS_API_GATE=PASS
PROTECTED_PATH_MUTATION_GATE=PASS
FINAL_GATE=PASS state=DEPLOYED_TLS_OPERATIONAL_V2_3
```

Do not describe v2.3 as production-deployed until these runtime gates have actually been observed on the ECS.
