# SkyED GrowthBridge 2.1 Architecture

## Client separation

- `/parent/` — Parent Client / 家长端
- `/teacher/` — Teacher Client / 教师端
- `/` — public client chooser only
- `/api/v1/` — shared authoritative API

There is no front-end role switch. The API validates the account role for every protected operation.

## Identity

- Teacher and parent accounts share one identity store but have fixed roles.
- The first deployment can bootstrap exactly one initial teacher account, gated by a deployment-generated one-time setup code stored outside the release tree and deleted immediately after successful bootstrap.
- Further accounts are created by one-time invitations.
- Parent invitations must be linked to at least one student before activation.
- Invitation tokens and session tokens are stored only as SHA-256 hashes.
- Passwords use PBKDF2-HMAC-SHA256 with per-account random salt and 310,000 iterations.
- Sessions are independent per device and can coexist across devices.

## Synchronization

All web/mobile clients read and mutate the same API and SQLite database. API responses are never service-worker cached. The parent and teacher PWAs cache only the application shell/static assets; live school data remains network authoritative.

Teacher mutations implemented in 2.1:
- classroom session save;
- evidence creation;
- evidence publish-state changes;
- account invitations.

Parent mutations implemented in 2.1:
- home-action completion toggle.

The client refreshes synchronized data after every mutation, on focus/visibility restoration, and periodically while open.

## Parent authorization

A parent account can only retrieve students explicitly present in `guardian_links`. Parent snapshots exclude:
- other students;
- teacher-only evidence;
- draft/ready evidence;
- teacher attention queue.

## Teacher authorization

Teacher accounts can access the teacher client and teacher API mutations. GrowthBridge remains independent from ClassFlow; no ClassFlow database is read or modified.

## Persistence

Production database:

`/opt/skyed-growthbridge/data/growthbridge.db`

The database lives outside immutable releases so application rollbacks never roll back or delete account/data state.


## Initial bootstrap gate

A fresh production database has no accounts. The deployment controller creates `/opt/skyed-growthbridge/data/bootstrap.key` with mode `0600`, prints the setup code once per deployment run while bootstrap remains open, and starts the API with that key path. `/api/v1/auth/bootstrap` requires the code and uses a transaction that succeeds only while the account table is empty. The key file is deleted after the first teacher account is committed.

This prevents public self-registration while still allowing deterministic first-account provisioning.
